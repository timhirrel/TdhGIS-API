# The function Set_RecordsNav_Cfuncs must be called before using the classes in this file
# This file contain the class TRecordsNav_py, a base class for managing lists

from ctypes import *
import os
import sys

from .TdhCommon_Cfuncs import *

def Set_RecordsNav_Cfuncs ():
# This function must be called before using any of the classes in this file  
  Set_RecordsNav_Cfuncs2 ()

class TRecordsNav_py:    
# This class provides the functionality for populating and navigating many of the data structures used in TDH API's   
# Instances of this class are not created by the API user.
# Instances of descendants of this class are returned by other API functions
# An instance of this class is called a navigator. Typicially, the underlying structure is a linked list
# The objects managed by a navigator either have key value for sorting or are queue or stack objects 
# The documentation refers to the first parameter after self as the 1st param
    def __init__(self, cParam): #1st param is a c++ instance of a TRecordsNav0
       self.cPtr = cParam
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      return objParam;
    def AddRec (self, objParam, keyParam, replaceFlag) :
      # Add object (1st param) using the specified key value (2nd param).
      # If the key value matches any existing object the existing object is replaced only if the 3rd param is true.
      # If the object is successfully added, sets the object pointer to the added object and returns true.
      return TdhCommon.RecordsNav_pyStr_AddRec (self.cPtr, self._C_obj(objParam), C_Str(keyParam), replaceFlag)
    def DeleteAll (self) :
      #deletes all objects (instances) in the navigator
      return TdhCommon.RecordsNav_pyStr_DeleteAll (self.cPtr)
    def DeleteOne (self, keyParam, keepParam = True) :
      #find object with key = 1st param and remove from list, delete object if 2nd param = false
      return TdhCommon.RecordsNav_pyStr_DeleteOne (self.cPtr, keyParam, keepParam);
    def DeleteCount(self, pos, delcount) :
      # deletes the number of objects (2nd parameter) starting at the position of 1st parameter
      return TdhCommon.RecordsNav_pyStr_DeleteCount (self.cPtr, pos, delcount)
    def GetFirst (self) :
      #returns the first object (or NULl) in the navigator
      return self._Py_Obj(TdhCommon.RecordsNav_pyStr_GetFirst (self.cPtr))
    def GetNext (self, objParam) :
      #returns the object (or NULL) following the 1st param
      return self._Py_Obj(TdhCommon.RecordsNav_pyStr_GetNext (self.cPtr, self._C_obj(objParam)))
    def GetLast (self) :
      #returns the last object (or NULl) in the navigator
      return self._Py_Obj(TdhCommon.RecordsNav_pyStr_GetLast(self.cPtr))
    def GetPrev (self, objParam) :
      #returns the object (or NULL) preceding the 1st param
      return self._Py_Obj(TdhCommon.RecordsNav_pyStr_GetNext(self.cPtr, self._C_obj(objParam)))
    def GetRec (self, keyParam) :      
      #if found, returns object with a key value matching the 1st param. Otherwise, returns NULL
      return self._Py_Obj(TdhCommon.RecordsNav_pyStr_GetRec(self.cPtr, keyParam))
    def GetItem (self, pos) :
      #return object pointer in position = 1st param
      return self._Py_Obj(TdhCommon.RecordsNav_pyStr_GetItem(self.cPtr, pos))
    def get_Count (self) :
      #returns the number of objects in the navigator
      return TdhCommon.RecordsNav_pyStr_get_Count(self.cPtr)
    def DefaultRec (self) :
      #returns the default object
      return TdhCommon.RecordsNav_pyStr_DefaultRec(self.cPtr)
    def set_DefaultRec (self, objParam ) :
      #sets the default object for the navigator
      TdhCommon.RecordsNav_pyStr_set_DefaultRec(self.cPtr, self._C_obj(objParam))
    def DataExists (self) :
      return TdhCommon.RecordsNav_pyStr_DataExists(self.cPtr)
    
# the following group of functions utilize an internal object pointer for navigating the list
    def GotoFirst (self) :
      # if the navigator has at least one object, sets the object pointer to the first object and returns true
      # otherwise, returns false
      return TdhCommon.RecordsNav_pyStr_GotoFirst(self.cPtr)
    def GotoLast (self) :
      # if the navigator has at least one object, sets the object pointer to the last object and returns true
      # otherwise, returns false
      return TdhCommon.RecordsNav_pyStr_GotoLast(self.cPtr)
    def GotoNext (self) :
      # if the object pointer is not at the last object, sets the object pointer to the next object and returns true
      # otherwise, returns false
      return TdhCommon.RecordsNav_pyStr_GotoNext(self.cPtr)
    def GotoPrev (self) :
      # if the object pointer is not at the last object, sets the object pointer to the next object and returns true
      # otherwise, returns false
      return TdhCommon.RecordsNav_pyStr_GotoPrev(self.cPtr)
    def GotoRec (self, keyParam) :
      # if such and object exists, sets the object pointer to the object whose key value matches the 1st parameter and returns true
      # otherwise, returns false and the object pointer is not changed
      return TdhCommon.RecordsNav_pyStr_GotoRec(self.cPtr, keyParam)
    def GotoNear (self, keyParam) :
      # sets the object pointer to the object whose key value is closest to but not more than the 1st parameter.
      # returns false only if no objects exist
      return TdhCommon.RecordsNav_pyStr_GotoNear(self.cPtr, keyParam)
    def AtFirst (self) :
      # returns true if the object pointer is set to the first object
      return TdhCommon.RecordsNav_pyStr_AtFirst(self.cPtr)
    def AtLast (self) :
      # return true if the object pointer is set to the last object
      return TdhCommon.RecordsNav_pyStr_AtLast(self.cPtr)
    def get_RecNum (self) :
      # returns the position of the current object
      return TdhCommon.RecordsNav_pyStr_get_RecNum(self.cPtr)
    def GetKey (self) :
      # returns the key value of the current object
      return TdhCommon.RecordsNav_pyStr_GetKey(self.cPtr)
    def KeyComp (self, keyParam) :
      #returns the key comparison result for the current object vs. the 1st parameter
      return TdhCommon.RecordsNav_pyStr_KeyComp(self.cPtr, keyParam)
    def  SetKey (self, keyParam, replaceFlag = False) :
      # sets the key value of the current object and inserts or moves the object within the container.
      # if there is an existing object with the same key and the 2nd parameter is true, the exiting object is deleted; otherwise the change is rejected
      # returns true if is the key is set
      return TdhCommon.RecordsNav_pyStr_SetKey(self.cPtr, keyParam, replaceFlag)
    def SetOrGetKey (self, keyParam) :
      # sets the key value of the current object and inserts or moves the object within the container.
      # if there is an existing object with the same key that object becomes the current object
      # returns the current object
      return self._Py_Obj(TdhCommon.RecordsNav_pyStr_SetOrGetKey(self.cPtr, keyParam))
    def GetData (self) :
      #returns the object pointer. If no valid object is available, returns DefaultRec().
      return self._Py_Obj(TdhCommon.RecordsNav_pyStr_GetData(self.cPtr))
    def SetData (self, objParam) :
      # if the 1st param belongs to the navigator, set the object pointer to 1st param and return true
      # otherwise, return false
      return TdhCommon.RecordsNav_pyStr_SetData (self.cPtr, self._C_obj(objParam))
    def GetPosition (self, objParam) :
      #returns the position of the object pointer
      return TdhCommon.RecordsNav_pyStr_GetPosition(self.cPtr, self._C_obj(objParam()))
    def GotoPosition (self, pos) :
      #set the object pointer
      return TdhCommon.RecordsNav_pyStr_GotoPosition (self.cPtr, pos)
    def NewData_nokey (self, objParam) :
      # sets current current object to 1st parameter. must be followed by a call to SetKey to add to container
      return TdhCommon.RecordsNav_pyStr_NewData_nokey(self.cPtr, self._C_obj(objParam)())
    def KeyToStr (self) :
      #returns a string representation of the key for the current object
      return TdhCommon.RecordsNav_pyStr_KeyToStr(self.cPtr)

    def KeyError (self) :
      #indicates whether n key conflict resulted from the previous SetKey operation
      return TdhCommon.RecordsNav_pyStr_KeyError(self.cPtr)
    def KeyUsed (self, keyParam) :
      # returns true if the 1st param is used as a key within the mavogator
      return TdhCommon.RecordsNav_pyStr_KeyUsed(self.cPtr, keyParam)
    def GetNextAvailableKey (self, strParam) :
      # for use with string keys
      # returns the lowest value unused key with the specified prefix (1st param)
      return TdhCommon.RecordsNav_pyStr_GetNextAvailableKey(self.cPtr, strParam)
    def SetIDs (self) :
      #set the id for all objects accessed by the navigator
      TdhCommon.RecordsNav_pyStr_SetIDs (self.cPtr);

#functions for queues and stacks
    def Push (self, objParam) :
      #Adds object to a Queue or Stack.
      #If the object is successfully added, sets the object pointer to the added object and returns true.
      return TdhCommon.RecordsNav_queue.Push(self.cPtr, self._C_obj(objParam)())
    def Pop (self) :
      #removes the first object from the navigator and returns it (or NULL)    
      return self._Py_Obj(TdhCommon.RecordsNav_queue.Pop(self.cPtr))
    def Insert (self, objParam, pos) :
      #adds the 1st param in the 2nd param position
      return TdhCommon.RecordsNav_queue.Insert (self.cPtr, self._C_obj(objParam), pos)
    def InsertNav (self, navParam, pos) :
      #inserts the objects contained in the 1st param into this navigator at the 2nd param position
      #the 1st param is emptied
      return TdhCommon.RecordsNav_queue.InsertNav (self.cPtr, self._C_obj(navParam), pos)


