# The function Set_CadPrimitives_Cfuncs must be called before using the classes in this file
# This file contains classes providing basic functionality for vector geometry based applications

from ctypes import *
import os
import sys

from ..TdhCommon_py.RecordsNav import *

def Set_CadPrimitives_Cfuncs () :
# This function must be called before using the classes contained in this file
# Specifies the parameters needed to access the API's C++ libraries
# This code is not normally of concern the the API user
  Set_PointXY_Cfuncs()
  Set_CadRect_Cfuncs()
  Set_Vertex_Cfuncs()
  Set_MultiLine_Cfuncs()
  Set_CadOptions_Cfuncs()

class TPointXY_py:
# This class provides basic functionality for an x,y point
# including the ability to share the point among diffent objects    
    def __init__(self, cParam = None):
       # cParam is not used when an API user creates an instance of this class
       if (cParam == None) :
          self.cPtr = TdhCommon.Create_PointXY_py (0, 0)
       self.cPtr = cParam
    def setX (self, xParam):
        # sets the x value
       TdhCommon.PointXY_py_setX(self.cPtr, xParam)
    def setY (self, yParam):
        # sets the y value
       TdhCommon.PointXY_py_setY(self.cPtr, yParam)
    def getX (self):
       # gets the x value
       return TdhCommon.PointXY_py_getX(self.cPtr)
    def getY (self):
       # gets the y value
       TdhCommon.PointXY_py_getY(self.cPtr)
    def SetXY (self, xParam, yParam):
       #sets the x and y values
       TdhCommon.PointXY_py_SetXY(self.cPtr, xParam, yParam)
    def CopyXY (self, ptParam):
       #copies the x and y vales from the 1st param
       TdhCommon.PointXY_py_CopyXY(self.cPtr, ptParam)
    def IsShareable (self):
       #returns true if the point can be shared
       return TdhCommon.PointXY_py_IsShareable(self.cPtr)
    def IsShared (self):
       #returns true if the point is shared
       return TdhCommon.PointXY_py_IsShared(self.cPtr)
    def OkToDelte (self):
       #returns true if it is ok to delete the point (i.e. the point is not being used)
       return TdhCommon.PointXY_py_okToDelte(self.cPtr)
    def ShareCode (self):
       #if the point is shared and the share codes are set, returns a unique code. Otherwise, returns 0
       return TdhCommon.PointXY_py_ShareCode(self.cPtr)


class TCadRect_py:
   # basic functionality for axis-aligned rectangles
   def __init__(self, cParam = None):
      # cParam is not used when an API user creates an instance of this class
      if (cParam == None):
        cParam = TdhCommon.Create_CadRect_py ()
      self.cPtr = cParam
   def MinPt (self):
      # returns a TPointXY_py containing the lowest x and y values for the rectangle 
      return TPointXY_py(TdhCommon.CadRect_py_MinPt(self.cPtr))
   def MaxPt (self):
      # returns a TPointXY_py containing the highest x and y values for the rectangle 
      return TPointXY_py(TdhCommon.CadRect_py_MaxPt(self.cPtr))
   def SetPoints (self, xParam1, yParam1, xParam2,  yParam2): 
     #sets the rectangle by specifying 2 opposing corners
     TdhCommon.CadRect_py_SetPoints (self.cPtr, xParam1, yParam1, xParam2,  yParam2) 
   def Height(self):
     #returns the y dimension
     return TdhCommon.CadRect_py_Height (self.cPtr) 
   def Width(self):
     #returns the x dimension
     return TdhCommon.CadRect_py_Width (self.cPtr) 
   def MaxX(self):
      #returns the highest x value
      return TdhCommon.CadRect_py_MaxX (self.cPtr) 
   def MinX(self):
      #returns the lowest x value
      return TdhCommon.CadRect_py_MinX (self.cPtr) 
   def MaxY(self):
      #returns the highest y value
      return TdhCommon.CadRect_py_MaxY (self.cPtr) 
   def MinY(self):
      #returns the lowest y value
      return TdhCommon.CadRect_py_MinY (self.cPtr) 
   def Expand(self, xParam, yParam):
      #the extents are expanded, if necessary, to include the 1st and 2nd params
      return TdhCommon.CadRect_py_Expand (self.cPtr, xParam, yParam) 
   def ExtentsValid(self):
      #returns true if the distance between the defining points is greater than TCadOptions::get_DistTolerance
      return TdhCommon.CadRect_py_ExtentsValid (self.cPtr);
   def ContainsPt(self, xParam, yParam, tolerance):
      #returns true if the extents plus the tolerance (2nd param) contain the 1st param.
      #a 2nd param value < 0 indicates than an api specified default should be used
      return TdhCommon.CadRect_py_ContainsPt (self.cPtr, xParam, yParam, tolerance)
   def ContainsRect(self, pt1, pt2, tolerance):
      #returns true if the extents plus the tolerance (2nd param) contains any part of the 1st param.
      #a 2nd param value < 0 indicates than an api specified default should be used
      return TdhCommon.CadRect_py_ContainsRect (self.cPtr, pt1.getX(), pt1.getY(), pt2.getX(), pt2.getY(), tolerance)
   def InfinExtents(self):
      #returns true if the extents are infinite, i.e. it will always contain everything else
      return TdhCommon.CadRect_py_InfinExtents (self.cPtr) 
   def MidPoint(self, ptParam):  
      #returns the midpoint of the rectangle       
      TdhCommon.CadRect_py_MidPoint (self.cPtr, ptParam.cPtr) 
   def CalcArea(self):
      #returns the area of the rectangle
      return TdhCommon.CadRect_py_CalcArea (self.cPtr)
   def NearestDist(self, ptParam):
      #returns the minimum distance from the pt (1st param) to the rect
      return TdhCommon.CadRect_py_NearestDist (self.cPtr, ptParam.getX(),  ptParam.getY())


class TVertex_py:
   # a class used for lists of TPointXY data in multi point lines
   # an instance should be created only by a TMultiLine function
   def __init__ (self, cParam):
      self.cPtr = cParam
   def GetKey (self):
     #returns the key value for a TVertex_py
     return TdhCommon.Vertex_py_GetKey(self.cPtr);
   def getX (self):
      #returns the x value for this vertex
      return TdhCommon.Vertex_py_getX(self.cPtr);
   def getY (self):
      #returns the y value for this vertex
      return TdhCommon.Vertex_py_getY(self.cPtr);
   def setX (self, valParam):
      #sets the x value for this vertex
      TdhCommon.Vertex_py_setX(self.cPtr, valParam);
   def setY (self,  valParam):
      #sets the y value for this vertex
      TdhCommon.Vertex_py_setY(valParam, self.cPtr);
   def SetXY (self, xParam, yParam):
      #sets both the x and y valu  es for this vertex
      TdhCommon.Vertex_py_SetXY(self.cPtr, xParam, yParam);
   def setPt (self, ptParam, ownParam):
      # sets the TPointxY used by the vertex, replacing the existing TPointXY
      # the 2nd param specifies whether the TPointXY is owned by the vertex
      return TdhCommon.Vertex_py_setPt(self.cPtr, ptParam.dPtr, ownParam);
   def getPt (self):
      #returns the TPointXY used by the vertex
      return TPointXY_py(TdhCommon.Vertex_py_getPt(self.cPtr))
   def Share (self, ptParam):
      #if the 1st param is a shared TPointXY_py, it will not be changed, otherwise, it will be changed to a shared TPointXY_py using the same xy data
      #this vertex will use the shared TPointXY_py resulting from the above statement
     TdhCommon.Vertex_py_Share(self.cPtr, ptParam.cPtr);
   def UnShare (self):
      #if the TPointXY_py used by this vertex is shared, it will be replaced with a new, unshared TPointXY_py
      TdhCommon.Vertex_py_UnShare(self.cPtr);
   def IsShared (self):
      #return true if the TPointXY0 is shared
      TdhCommon.Vertex_py_IsShared(self.cPtr);

class TVertexNav_py (TRecordsNav_py) :
    # This class provides a navigator of a TVerex_py list
    def __init__(self, cParam = None): 
       # 1st param is a C++ instance of a TVertexNav
        if (cParam == None):
            cParam = TdhCommon.Create_VertexNav_py()
        super().__init__(cParam)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      vertex = TVertex_py (objParam)
      return vertex


class TMultiLine_py:
  # This class provides the functionality for creating and using multi point (vertices) lines
  def __init__(self, cParam = None):
      # cParam is not used when an API user creates an instance of this class
      if (cParam == None):
        cParam = TdhCommon.Create_MultiLine_py (None, True)
      self.cPtr = cParam
      self.TMultiLineProc = TdhCommon.get_TMultiLineProc()
  def PtNav (self):
    #returns the TVertexNav_py for the multiline
    return TVertexNav_py(TdhCommon.MultiLine_py_PtNav (self.cPtr, self.TMultiLineProc))
  def Closed (self):
    #returns true if the multiline closes, i.e. the last pt connects to the first pt
    return TdhCommon.MultiLine_py_Closed(self.cPtr, self.TMultiLineProc)
  def set_Closed (self, closedFlag):  
    #set true if the multiline closes, i.e. the last pt connects to the first pt
    TdhCommon.MultiLine_py_set_Closed (self.cPtr, self.TMultiLineProc, closedFlag)
  def Create_Vertex (self, ptParam, ownFlag):
    #returns a new TVertex_xy using the TPointXY_py in the 1st param
    #if the 2nd param is true, the TVertex_py instance takes ownership of the TPointXY_py instance
    return TVertex_py(TdhCommon.MultiLine_py_Create_Vertex(self.cPtr, self.TMultiLineProc, ptParam.cPtr, ownFlag))
  def AddVertex (self, vertexParam):
    #add the TVertex_py specified in the 1st param to the MultiLine
    return TdhCommon.MultiLine_py_AddVertex (self.cPtr, self.TMultiLineProc, vertexParam)
  def AddXY (self, xParam, yParam):
    #add a vertex using the x,y data in the params; return the vertex or NULL if not sucessfule
    return TVertex_py(TdhCommon.MultiLine_py_AddXY (self.cPtr, self.TMultiLineProc, xParam, yParam))
  def AddPt (self, ptParam, ownParam):
    # calls Create_Vertex using the the 2 params and then AddVertex using the new vertex
    # returns the vertex or NULL if not sucessfule
    return TVertex_py(TdhCommon.MultiLine_py_AddPt (self.cPtr, self.TMultiLineProc, ptParam, ownParam))
  def AddPt_First (self, xParam, yParam, delFlag):
    # adds a vertex in the first position. if 3rd param is true, all other vertexes are deleted.
    # returns the vertex
    return TVertex_py(TdhCommon.MultiLine_py_AddPt_First (self.cPtr, self.TMultiLineProc, xParam, yParam, delFlag))
  def AddPt_shared (self, ptParam):
    #add a vertex using the shared TPointXY0 in the 1st param (see TVertex0::Share) 
    # returns the vertex or NULL if not sucessfule
    return TVertex_py(TdhCommon.MultiLine_py_AddPt_shared (self.cPtr, self.TMultiLineProc, ptParam))
  def CopyPt (self, ptParam, shareFlag):
    # for the current vertex in PtNav(),
    # if the 2nd param is true, copy the 1st param as a shared pt  (see TVertex0::Share)
    # if the 2nd param is false, copy the xy data from the 1st parm
    # returns the TPointXY_py for the current vertex
    return TPointXY_py(TdhCommon.MultiLine_py_CopyPt (self.cPtr, self.TMultiLineProc, ptParam, shareFlag))
  def CopyPts (self, lineSource, pos, numPts, shareFlag) :
    # if the 1st param is NULL, a new TMulitLine is created and becomes the target
    # pts are added to the 1st param using data from this PtNav
    # 2nd param is staring at the position within PtNav
    # 3rd param is the number of pts from PtNav
    # 4th param specifies whether the pts are shared, as follows:
      # 0 - pts are never shared, only xy data is used
      # 1 - pt is shared with target if the source pt is shared
      # 2 - all pts are shared
    # returns the target TMultiLine0  
    return TdhCommon.MultiLine_py_CopyPts (self.cPtr, self.TMultiLineProc, lineSource, pos, numPts, shareFlag)
  def CopyPtVals (self, lineSource):
    # for up to the number of pts in this or the number of pts in the 1st param
    # the value of a pt in this copied the pt in the corresponding position of the 1st param
    return TdhCommon.MultiLine_py_CopyPtVals (self.cPtr, self.TMultiLineProc, lineSource);
  def InsertPt (self, xParam, yParam, pos):
    #using the xy data from the 1st param insert a vertex at position specified by 2nd param
    #return true if sucessful
    return TdhCommon.MultiLine_py_InsertPt (self.cPtr, self.TMultiLineProc, xParam, yParam, pos);
  def InsertPts (self, navParam, pos):
    # the verices contained the 1st param are inserted into PtNav starting as position specified by 2nd param
    # 1st param is emptied. return true if sucessful
    return TdhCommon.MultiLine_py_InsertPts (self.cPtr, self.TMultiLineProc, navParam, pos)
  def AddendMultiLine (self, navParam):
    #transfer points from navParam to end of this line, navParam will lose all points
    TdhCommon.MultiLine_py_AddendMultiLine (self.cPtr, self.TMultiLineProc, navParam)
  def PrependMultiLine (self, navParam):
    #transfer points from param to beginning of this line, param will lose all points
    TdhCommon.MultiLine_py_PrependMultiLine (self.cPtr, self.TMultiLineProc, navParam)
  def ReversePts (self):
    #reverse the order of vertices in this TMultiLine
    TdhCommon.MultiLine_py_ReversePts (self.cPtr, self.TMultiLineProc)
  def set_Point (self, pos, xParam, yParam):
    #for the pt at position 1st param, set the xy value equal to 2nd and 3rd params
    TdhCommon.MultiLine_py_set_Point (self.cPtr, self.TMultiLineProc, pos, xParam, yParam);
  def get_Point(self, pos):
    #returns TPointXY_py at position 1st param of PtNav
    return TPointXY_py(TdhCommon.MultiLine_py_get_Point(self.cPtr, self.TMultiLineProc, pos))
  def ResetExtents (self):
    #sets extentsvalid as false, called automatically when the pts change
    TdhCommon.MultiLine_py_ResetExtents (self.cPtr, self.TMultiLineProc)
  def ExtentsValid (self):
    #if extents have been marked invalid, calculates new extents and returns true if the extents exceed near zero in both dimensions
    return TdhCommon.MultiLine_py_ExtentsValid (self.cPtr, self.TMultiLineProc)
  def GetExtents (self):
    #calls ExtentsValid() and returns a reference to a TCadRect0 containing the extents for the multiline.
    return TCadRect_py(TdhCommon.MultiLine_py_GetExtents (self.cPtr, self.TMultiLineProc))
  def CleanVertices (self, tolerance):
    #deletes pt when distance from previous pt is < tolerance. returns number of verticies deleted
    return TdhCommon.MultiLine_py_CleanVertices (self.cPtr, self.TMultiLineProc, tolerance);
  def UnSharePt (self, pos):
    #unshare TPointXY_py at position 1st param in PtNav
    TdhCommon.MultiLine_py_UnSharePt (self.cPtr, self.TMultiLineProc, pos)
  def CalcLength (self):
    #returns the length of the  multiline.  if closed, include segment from last pt to first pt
    return TdhCommon.MultiLine_py_CalcLength (self.cPtr, self.TMultiLineProc)
  def CalcMidPt (self, ptParam):
    #returns the midpoint of the multiline, i.e. equal distance along multiline from 1st pt to last pt.
    #if closed, include segment from last pt to first pt
    return TPointXY_py(TdhCommon.MultiLine_py_CalcMidPt (self.cPtr, self.TMultiLineProc, ptParam))  
  def NearestVertex (self, xParam, yParam):
    # returns the vertex on the multiline closest to 1st param
    return TVertex_py(TdhCommon.MultiLine_py_NearestVertex (self.cPtr, self.TMultiLineProc, xParam, yParam))
  def NearestPt (self, xParam, yParam, ptOut):
    # returns the point on the multiline closest to 1st param
    return TPointXY_py (TdhCommon.MultiLine_py_NearestPt (self.cPtr, self.TMultiLineProc, xParam, yParam, ptOut)) 
  def CurrVertex (self):
    # returns PtNav current vertex
    return TVertex_py(TdhCommon.MultiLine_py_CurrVertex (self.cPtr, self.TMultiLineProc))
  def CurrPt (self, ptOut):
    # returns the xy data used by the current vertex
    return TPointXY_py(TdhCommon.MultiLine_py_CurrPt (self.cPtr, self.TMultiLineProc, ptOut))
  def NextPt (self, ptParam = None):
    # returns the next vertex after the 1st param
    # if 1st param is NULL, use CurrVertex()
    # if 1st param is last vertex and Closed(), return first vertex
    return TVertex_py(TdhCommon.MultiLine_py_NextPt (self.cPtr, self.TMultiLineProc, ptParam))
  def PrevPt (self, ptParam = None):
    # returns the next vertex after the 1st param
    # if 1st param is NULL, use CurrVertex()
    # if 1st param is last vertex and Closed(), return first vertex
    return TVertex_py(TdhCommon.MultiLine_py_PrevPt (self.cPtr, self.TMultiLineProc, ptParam))
  def GotoVertex (self, ptParam):
    # sets the current vertex to the one using the 1st param (TPointXY_py), if such a vertex belongs to the multiline
    # returns true if sucessful
    return TdhCommon.MultiLine_py_GotoVertex (self.cPtr, self.TMultiLineProc, ptParam.cPtr)
  def MovePt (self, xParam,  yParam):
    # set the xy values for current vertex to the 1st and 2nd param
    # returns true if sucessful
    return TdhCommon.MultiLine_py_MovePt (self.cPtr, self.TMultiLineProc, xParam, yParam)
  def DeleteVertex (self, ptParam):
    # deletes the 1st param (TVertex_py) from the PtNav
    # return true if sucessful
    return TdhCommon.MultiLine_py_DeleteVertex (self.cPtr, self.TMultiLineProc, ptParam);
  def DeleteCurrent (self):
    # delete the current vertex
    # return true if sucessful
    return TdhCommon.MultiLine_py_DeleteCurrent (self.cPtr, self.TMultiLineProc)


class TCadOptions_py:
# sets options used in geometry calculations
# by default, Tdh geometry is unit agnostic, whatever units the input data refers to are the units output by calculations
# however, if the input data represent longitude/latitude, then the desired output units should be specified using the setDistUnit functions below
    def __init__(self):
       self.cPtr = TdhCommon.Create_CadOptions_py()
    def set_LonLat (self, lonlatFlag) :
      # sets whether geometry is specified using longitude/latitude (affects calculation of distance and area)
      TdhCommon.CadOptions_py_set_LonLat(self.cPtr, lonlatFlag)
    def get_LonLat (self) :
      #returns whether geometry is specified using longitude/latitude
      return TdhCommon.CadOptions_py_get_LonLat(self.cPtr)
    def setDistUnitsStr (self, strParam) :
      #specify units as either "meters" or "feet"
      TdhCommon.CadOptions_py_setDistUnitsStr (self.cPtr, strParam)
    def setDistUnits (self, unitsParam) :
      #specify units as one of the DistanceUnit enum
      return TdhCommon.CadOptions_py_setDistUnits(self.cPtr, unitsParam)
    def getDistUnits (self, strParam) :
      #if the 1st param is "", return the current distance units; otherwise, return the unit associated with the string
      return TdhCommon.CadOptions_py_getDistUnits(self.cPtr, strParam)
    def getDistStr (self) :
      #returns the current distance units as a string
      return TdhCommon.CadOptions_py_getDistStr(self.cPtr)
    def DistTolerance (self, tolerance) :
      # sets the distance below which 2 points are considered equal; default is 1e-5 or 1e-8 for long/lat
      TdhCommon.CadOptions_py_set_DistTolerance(self.cPtr, tolerance)
    def get_DistTolerance (self) :
      #returns the current distance tolerance
      return TdhCommon.CadOptions_py_get_DistTolerance(self.cPtr)


