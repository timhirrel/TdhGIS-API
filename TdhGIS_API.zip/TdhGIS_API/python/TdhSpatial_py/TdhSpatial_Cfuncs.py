# This file contains code not normally of concern to the API user

from ctypes import *
import os
import sys
import platform

from ..TdhGIS_API_universal import *

if (platform.system() == "Linux") :
  TdhSpatial = CDLL(libDir+"libTdhSpatial_py.so")
if (platform.system() == "Windows") :
  TdhSpatial = cdll.LoadLibrary(libDir+"TdhSpatial_Py.dll") 

def Set_PtData_Cfuncs ():
  TdhSpatial.Create_PtData_py.restype = c_void_p
#  TdhSpatial.Create_PtData_py.argtypes = [c_void_p]
  TdhSpatial.Create_PtNav_py.restype = c_void_p
#  TdhSpatial.PtData_py_PyPtr.restype = c_char_p
#  TdhSpatial.PtData_py_PyPtr.argtypes = [c_void_p]
  TdhSpatial.PtData_py_ID.restype = c_char_p
  TdhSpatial.PtData_py_ID.argtypes = [c_void_p]
  TdhSpatial.PtData_py_set_ID.argtypes = [c_void_p, c_char_p]
  TdhSpatial.PtData_py_Pt.restype = c_void_p
  TdhSpatial.PtData_py_Pt.argtypes = [c_void_p]
  TdhSpatial.PtData_py_Value.restype = c_double
  TdhSpatial.PtData_py_Value.argtypes = [c_void_p]
  TdhSpatial.PtData_py_set_Value.argtypes = [c_void_p, c_double]
  TdhSpatial.PtData_py_setY.argtypes = [c_void_p, c_double]
  TdhSpatial.PtData_py_setX.argtypes = [c_void_p, c_double]
  TdhSpatial.PtData_py_getY.restype = c_double
  TdhSpatial.PtData_py_getY.argtypes = [c_void_p]
  TdhSpatial.PtData_py_getX.restype = c_double
  TdhSpatial.PtData_py_getX.argtypes = [c_void_p]
  TdhSpatial.PtData_py_SetXY.argtypes = [c_void_p, c_double, c_double]
  TdhSpatial.PtData_py_Copy.restype = c_void_p
  TdhSpatial.PtData_py_Copy.argtypes = [c_void_p, c_void_p]
  TdhSpatial.PtData_py_incr_Value.argtypes = [c_void_p, c_double]
  TdhSpatial.PtData_py_AllocatedTo.restype = c_char_p
  TdhSpatial.PtData_py_AllocatedTo.argtypes = [c_void_p]
  TdhSpatial.PtData_py_set_AllocatedTo.argtypes = [c_void_p, c_char_p]
  TdhSpatial.PtData_py_Allocated.restype = c_bool
  TdhSpatial.PtData_py_Allocated.argtypes = [c_void_p]
  TdhSpatial.PtData_py_set_Allocated.argtypes = [c_void_p, c_bool]
  TdhSpatial.PtData_py_Weight.restype = c_double
  TdhSpatial.PtData_py_Weight.argtypes = [c_void_p]
  TdhSpatial.PtData_py_set_Weight.argtypes = [c_void_p, c_double]
  TdhSpatial.PtData_py_incr_Weight.argtypes = [c_void_p, c_double]

def Set_PtFuncs_Cfuncs ():
  TdhSpatial.Create_PtFuncs_py.restype = c_void_p
  TdhSpatial.PtFuncs_py_FindNearPt.restype = c_void_p
  TdhSpatial.PtFuncs_py_FindNearPt.argtypes = [c_void_p, c_void_p, c_void_p]
  TdhSpatial.PtFuncs_py_ReducePts.argtypes = [c_void_p, c_void_p, c_double]
  TdhSpatial.PtFuncs_py_CombinePts.argtypes = [c_void_p, c_void_p, c_void_p, c_void_p]

def Set_GisPolygon_Cfuncs ():
  TdhSpatial.Create_GisPolygon_py.restype = c_void_p
  TdhSpatial.Create_GisPolygon_py.argtypes = [c_void_p, c_bool]
    # see C++ documentation for parameter information, use None and True as default
  TdhSpatial.Create_GisMultiLine_py.restype = c_void_p
  TdhSpatial.Create_GisMultiLine_py.argtypes = [c_void_p, c_bool]
  TdhSpatial.get_TMultiLine_fromPoly_Proc. restype = c_void_p
  TdhSpatial.Create_PolyNav_py.restype = c_void_p
  TdhSpatial.GisPolygon_py_PtNavCW.restype = c_void_p
  TdhSpatial.GisPolygon_py_PtNavCW.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_PtNav.restype = c_void_p
  TdhSpatial.GisPolygon_py_PtNav.argtypes = [c_void_p]
#  TdhSpatial.GisPolygon_py_CalcLength.restype = c_double
#  TdhSpatial.GisPolygon_py_CalcLength.argtypes = [c_void_p]

  TdhSpatial.Create_ExcludPolyNav_py.argtypes = [c_void_p]
  TdhSpatial.Copy_Polygons_py.argtypes = [c_void_p, c_void_p]
  TdhSpatial.GisPolygon_py_DataType.restype = c_int
  TdhSpatial.GisPolygon_py_DataType.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_PolyID.restype = c_char_p
  TdhSpatial.GisPolygon_py_PolyID.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_set_PolyID.argtypes = [c_void_p, c_char_p]
  TdhSpatial.GisPolygon_py_PtNavCW.restype = c_void_p
  TdhSpatial.GisPolygon_py_PtNavCW.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_ExcludePolys.restype = c_void_p
  TdhSpatial.GisPolygon_py_ExcludePolys.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_Reset.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_DeletePts.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_GetExtents.restype = c_void_p
  TdhSpatial.GisPolygon_py_GetExtents.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_SetCW.argtypes = [c_void_p, c_bool]
  TdhSpatial.GisPolygon_py_ResetCW.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_CWSet.restype = c_bool
  TdhSpatial.GisPolygon_py_CWSet.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_IsCW.restype = c_bool
  TdhSpatial.GisPolygon_py_IsCW.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_AddExcludePoly.argtypes = [c_void_p, c_void_p, c_char_p]
  TdhSpatial.GisPolygon_py_Copy.restype = c_void_p
  TdhSpatial.GisPolygon_py_Copy.argtypes = [c_void_p, c_void_p]
  TdhSpatial.GisPolygon_py_CopyParams.argtypes = [c_void_p, c_void_p]
  TdhSpatial.GisPolygon_py_CalcCentroid.restype = c_bool
  TdhSpatial.GisPolygon_py_CalcCentroid.argtypes = [c_void_p, c_void_p]
  TdhSpatial.GisPolygon_py_set_Centroid.argtypes = [c_void_p, c_double, c_double]
  TdhSpatial.GisPolygon_py_CalcArea.restype = c_double
  TdhSpatial.GisPolygon_py_CalcArea.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_set_Area.argtypes = [c_void_p, c_double]
  TdhSpatial.GisPolygon_py_CalcPerimeter.restype = c_double
  TdhSpatial.GisPolygon_py_CalcPerimeter.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_set_Perimeter.argtypes = [c_void_p, c_double]
  TdhSpatial.GisPolygon_py_ReCalc.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_ContainsPt.restype = c_bool
  TdhSpatial.GisPolygon_py_ContainsPt.argtypes = [c_void_p, c_double, c_double]
  TdhSpatial.GisPolygon_py_ContainsPoly.restype = c_bool
  TdhSpatial.GisPolygon_py_ContainsPoly.argtypes = [c_void_p, c_double, c_char]
  TdhSpatial.GisPolygon_py_Value.restype = c_double
  TdhSpatial.GisPolygon_py_Value.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_set_Value.argtypes = [c_void_p, c_double]
  TdhSpatial.GisPolygon_py_incr_Value.argtypes = [c_void_p, c_double]
  TdhSpatial.GisPolygon_py_incr_Value.argtypes = [c_void_p, c_double]
  TdhSpatial.GisPolygon_py_Parent.restype = c_char_p
  TdhSpatial.GisPolygon_py_Parent.argtypes = [c_void_p, c_int]
  TdhSpatial.GisPolygon_py_set_Parent.argtypes = [c_void_p, c_char_p, c_int]
  TdhSpatial.GisPolygon_py_AllocateFactor.restype = c_double
  TdhSpatial.GisPolygon_py_AllocateFactor.argtypes = [c_void_p, c_int]
  TdhSpatial.GisPolygon_py_set_AllocateFactor.argtypes = [c_void_p, c_double, c_int]
  TdhSpatial.GisPolygon_py_Color.restype = c_uint
  TdhSpatial.GisPolygon_py_Color.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_set_Color.argtypes = [c_void_p, c_uint]
  TdhSpatial.GisPolygon_py_ColorFlag.restype = c_bool
  TdhSpatial.GisPolygon_py_ColorFlag.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_set_ColorFlag.argtypes = [c_void_p, c_bool]
  TdhSpatial.GisPolygon_py_Width.restype = c_float
  TdhSpatial.GisPolygon_py_Width.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_set_Width.argtypes = [c_void_p, c_float]
  TdhSpatial.GisPolygon_py_Major.restype = c_char
  TdhSpatial.GisPolygon_py_Major.argtypes = [c_void_p]
  TdhSpatial.GisPolygon_py_set_Major.argtypes = [c_void_p, c_char]
  TdhSpatial.Create_PolyNav_py.restype = c_void_p
  TdhSpatial.Create_ExcludPolyNav_py.restype = c_void_p
  TdhSpatial.Create_ExcludPolyNav_py.argtypes = [c_void_p]


def Set_Thiessen_Cfuncs ():
  TdhSpatial.Create_Thiessen_py.restype = c_void_p
  TdhSpatial.Delete_Thiessen_py.argtypes = [c_void_p]
  TdhSpatial.Thiessen_py_PolyNav.restype = c_void_p
  TdhSpatial.Thiessen_py_PolyNav.argtypes = [c_void_p]
  TdhSpatial.Thiessen_py_AddPtData.argtypes = [c_void_p, c_void_p, c_bool]
  TdhSpatial.Thiessen_py_AddPtList.argtypes = [c_void_p, c_void_p, c_bool]
  TdhSpatial.Thiessen_py_MakePolygons.argtypes = [c_void_p, c_void_p, c_bool]
  TdhSpatial.Thiessen_py_AutoBoundary.restype = c_void_p
  TdhSpatial.Thiessen_py_AutoBoundary.argtypes = [c_void_p, c_void_p]
  TdhSpatial.Thiessen_py_Reset.argtypes = [c_void_p]
  TdhSpatial.Thiessen_py_HasData.restype = c_bool
  TdhSpatial.Thiessen_py_HasData.argtypes = [c_void_p]

def Set_Contours_Cfuncs ():
  TdhSpatial.Create_Contour_py.restype = c_void_p
  TdhSpatial.Contour_py_MakeContours.argtypes = [c_void_p, c_void_p, c_double, c_void_p, c_uint, c_bool]
  TdhSpatial.Contour_py_ContourNav.restype = c_void_p
  TdhSpatial.Contour_py_ContourNav.argtypes = [c_void_p]
  TdhSpatial.Contour_py_set_MajorStep.argtypes = [c_void_p, c_int]
  TdhSpatial.Contour_py_set_MinSet.argtypes = [c_void_p, c_bool]
  TdhSpatial.Contour_py_set_MaxSet.argtypes = [c_void_p, c_bool]
  TdhSpatial.Contour_py_set_Minimum.argtypes = [c_void_p, c_double]
  TdhSpatial.Contour_py_set_Maximum.argtypes = [c_void_p, c_double]

def Set_ContourPoly_Cfuncs ():
  TdhSpatial.Create_ContourPoly_py.restype = c_void_p
  TdhSpatial.ContourPoly_py_MakeContourPolygons.argtypes = [c_void_p, c_void_p, c_void_p, c_double, c_bool]
  TdhSpatial.ContourPoly_py_PolyNav.restype = c_void_p
  TdhSpatial.ContourPoly_py_PolyNav.argtypes = [c_void_p]

def Set_PolyIntersect_Cfuncs ():
  TdhSpatial.PolyIntersect_py_PolyNav.restype = c_void_p
  TdhSpatial.PolyIntersect_py_PolyNav.argtypes = [c_void_p]
  TdhSpatial.PolyIntersect_py_Execute.restype = c_bool
  TdhSpatial.PolyIntersect_py_Execute.argtypes = [c_void_p, c_void_p, c_void_p, c_bool]
  TdhSpatial.PolyIntersect_py_ExecutePolyListToPoly.argtypes = [c_void_p, c_void_p, c_void_p, c_bool]
  TdhSpatial.PolyIntersect_py_ExecutePolyListToPolyList.argtypes = [c_void_p, c_void_p, c_void_p, c_bool]
  TdhSpatial.PolyIntersect_py_AllocatePtsToPolyList.argtypes = [c_void_p, c_void_p, c_void_p, c_bool]
  TdhSpatial.PolyIntersect_py_AllocatePolyListToPolyList.argtypes = [c_void_p, c_void_p, c_void_p, c_bool]
#one of the following functions should be used to get the parameter for createing a TPolyIntersect instance
  TdhSpatial.Create_PolyIntersect_py.restype = c_void_p
  TdhSpatial.Create_PolyMerge_py.restype = c_void_p
  TdhSpatial.Create_PolySubtract_py.restype = c_void_p
  TdhSpatial.Create_PolyTrim_py.restype = c_void_p
  TdhSpatial.Create_PolySplit_py.restype = c_void_p

def Set_Dissolve_Cfuncs ():
  TdhSpatial.Create_Dissolve_py.restype = c_void_p
  TdhSpatial.Dissolve_py_NewPolys.restype = c_void_p
  TdhSpatial.Dissolve_py_NewPolys.argtypes = [c_void_p]
  TdhSpatial.Dissolve_py_Dissolve.restype = c_bool
  TdhSpatial.Dissolve_py_Dissolve.argtypes = [c_void_p, c_void_p]

