# The function Set_SpatialIntf_Cfuncs must be called before using the classes in this file
# This file contains classes providing 2D spatial analysis functionality

from ctypes import *
import os
import sys

from ..TdhCommon_py.RecordsNav import *
from ..TdhCommon_py.CadPrimitives import *
from ..TdhSpatial_py.TdhSpatial_Cfuncs import *


def Set_SpatialIntf_Cfuncs ():
# this function must be called before the use of any of the classes in this file
    Set_PtData_Cfuncs()
    Set_PtFuncs_Cfuncs()
    Set_GisPolygon_Cfuncs()
    Set_Thiessen_Cfuncs()
    Set_Contours_Cfuncs()
    Set_ContourPoly_Cfuncs()
    Set_PolyIntersect_Cfuncs()
    Set_Dissolve_Cfuncs()


class TPtData_py:
    # This class associates an ID. a value and a weight to Point data
    # and allows the data to be included in a Tdh list
    # It also stores the polygon to which the object has been allocated
    def __init__(self, cParam = None):
        # cParam is not used when an API user creates an instance of this class
        if cParam == None:
            cParam = TdhSpatial.Create_PtData_py()
        self.cPtr = cParam
    def _C_Obj (self) :
        return self.cPtr    
    def ID (self) :
        # returns the ID for the TPtdata
        return TdhSpatial.PtData_py_ID (self.cPtr)
    def  set_ID (self, strParam) :
        # sets the ID for the TPtdata
        TdhSpatial.PtData_py_set_ID (self.cPtr, C_Str(strParam))
    def Pt (self) :
        # returns the TPointXY associated the TPtData
        return TPointXY_py(TdhSpatial.PtData_py_Pt(self.cPtr))
    def Value (self) :
        # returns a user defined value
        return TdhSpatial.PtData_py_Value(self.cPtr)
    def set_Value (self, valParam) :
        # sets a user defined value
        TdhSpatial.PtData_py_set_Value(self.cPtr, valParam)
    def incr_Value (self, valParam) :
        # increment the user defined value
        TdhSpatial.PtData_py_incr_Value(self.cPtr, valParam)
    def setX (self, xParam) :
        #sets the x value associated with the TPtData
        TdhSpatial.PtData_py_setX(self.cPtr, xParam)
    def  setY (self, yParam) :
        #sets the y value associated with the TPtData
        TdhSpatial.PtData_py_setY (self.cPtr, yParam)
    def getX (self) :
        #returns the x value associated with the TPtData
        return TdhSpatial.PtData_py_getX(self.cPtr)
    def getY (self) :
        #returns the y value associated with the TPtData
        return TdhSpatial.PtData_py_getY(self.cPtr)
    def SetXY (self,  xParam, yParam) :
        # sets the x and y values associated with the TPtData
        TdhSpatial.PtData_py_SetXY(self.cPtr, xParam, yParam)
    def Copy (self, ptParam = None) :
        # copies this data to the 1st param (TPtData_py), creates and returns a new TPtData0 if 1st param is NULL
        return TPtData_py(TdhSpatial.PtData_py_Copy(self.cPtr, ptParam.cPtr))
    def AllocatedTo (self) :
        # returns the id of the polygon to which this has been allocated
        return TdhSpatial.PtData_py_AllocatedTo(self.cPtr)
    def  set_AllocatedTo (self, strParam) :
        # save the id of the polygon to which this has been allocated
        return TdhSpatial.PtData_py_set_AllocatedTo(self.cPtr, C_Str(strParam))
    def Allocated (self) :
        # returns true if this has been allocated to a polygon
        return TdhSpatial.PtData_py_Allocated(self.cPtr)
    def set_Allocated (self, boolParam) :
        # set to true if this has been allocated to a polygon
        TdhSpatial.PtData_py_set_Allocated(self.cPtr, boolParam)
    def Weight (self) :
        # returns the weight of this for functionality using weighting
        return TdhSpatial.PtData_py_Weight(self.cPtr)
    def set_Weight (self, valParam) :
        # sets the weight of this for functionality using weighting
        TdhSpatial.PtData_py_set_Weight(self.cPtr, valParam)
    def  incr_Weight (self, valParam) :
        # increments the weight of this for functionality using weighting
        TdhSpatial.PtData_py_incr_Weight(self.cPtr, valParam)

class TPtDataNav_py (TRecordsNav_py) :
    # This class provides a navigator of a TPtData_py list
    def __init__(self, cParam = None): 
        # 1st param is a C++ instance of a TPtDataNav
        if (cParam == None):
            cParam = TdhSpatial.Create_PtNav_py()
        super().__init__(cParam)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      pt = TPtData_py(objParam)
      return pt


class TPtFuncs_py:
    # a class for processing TPtData
    def __init__(self):
        self.cPtr = TdhSpatial.Create_PtFuncs()
    def FindNearPt (self, ptData, ptNav) :
        # return thes TPtData in the 2nd param (TPtNav_py) nearest to the 1st param (TPointXY_py)
        return TdhSpatial.PtFuncs.FindNearPt (self.cPtr, ptData, ptNav)
    def ReducePts(self, ptNav, valParam) :
        # eliminates pts in 1st param (TPtNav_py) that are within 2nd param distance of an adjacent pt
        # averaging the TPtData_py values
       TdhSpatial.PtFuncs.ReducePts(self.cPtr, ptNav, valParam)
    def CombinePts (self, ptData1, ptData2, ptNav) :
        # computes the average of 2 points (1st and 2nd params), both belonging to the 3rd param (TPtNav_py)
        # modifies the 1st point to equal the average and deletes the 2nd point
        # weights the averaging such that a combined pt has a higher weighting when combined again.
        TdhSpatial.PtFuncs.CombinePts (self.cPtr, ptData1, ptData2, ptNav)


class TGisPolygon_base_py (TMultiLine_py):
    # instances of this class are not normally created by the API user, create TGisPolygon_py instances instead
    # a class for adding polygon functionality to TMultiLine_py
    # an instance can be either a GisPolygon (closed) or a GisMultiLine (not closed)
    # Unlike a TMultiLine_py, these objects have an ID and can belong to a TRecordsNav_py
    def __init__(self, cParam):
        super().__init__(cParam)
        self.TMultiLineProc = TdhSpatial.get_TMultiLine_fromPoly_Proc()
    def DataType (self) :
        # returns either dtGisPolygon (1) or dtGisMultiLine (2)
        return TdhSpatial.GisPolygon_py_DataType (self.cPtr)
    def PolyID (self) :
        # returns the polygon ID
        return TdhSpatial.GisPolygon_py_PolyID (self.cPtr)
    def set_PolyID (self, strParam) :
        #set the polygon ID
        TdhSpatial.GisPolygon_py_set_PolyID(self.cPtr, C_Str(strParam))
    def Reset (self, exclFlag = True) :
        # delete all pts, set all data to default values
        # if 1st param is true, exclusion polys will be deleted
        TdhSpatial.GisPolygon_py_Reset(self.cPtr, exclFlag)
    def SetCW (self, val) :
        #determine whether the pts are in clockwise order and set internal variable
        TdhSpatial.GisPolygon_py_SetCW(self.cPtr, val)
    def ResetCW (self) :
        #reset flag that tells whether clockwise variable has been set
        TdhSpatial.GisPolygon_py_ResetCW(self.cPtr)
    def CWSet (self) :
        #return flag  that tells whether clockwise variable has been set
        return TdhSpatial.GisPolygon_py_CWSet(self.cPtr)
    def IsCW (self) :
        #return variable that tells whether pts are clockwise
        return TdhSpatial.GisPolygon_py_IsCW(self.cPtr)
    def CopyParams (self, targetParam) :
        #copy polygon data to 1st param
        TdhSpatial.GisPolygon_py_CopyParams(self.cPtr, targetParam)
    def CalcCentroid (self, ptParam) :
        #set the 1st param (TPointXY_py) to the centroid for the polygon, return true if successful
        return TdhSpatial.GisPolygon_py_CalcCentroid(self.cPtr, ptParam.cPtr)
    def set_Centroid(self, xParam, yParam) :
        #set the centroid, resets if pts change
        TdhSpatial.GisPolygon_py_set_Centroid(self.cPtr, xParam, yParam);
    def CalcArea (self) :
        #returns the area of the polygon. substracts the area of any exclusion polygon
        return TdhSpatial.GisPolygon_py_CalcArea(self.cPtr)
    def set_Area (self, valParam) :
        #set the area, resets if pts change
        TdhSpatial.GisPolygon_py_set_Area(self.cPtr, valParam);
    def CalcPerimeter (self) :
        #return the perimeter of the polygon, including the perimeter of any exclusion polygon
        return TdhSpatial.GisPolygon_py_CalcPerimeter(self.cPtr);
    def set_Perimeter(self,  valParam) :
        #set the perimeter, resets if pts change
        TdhSpatial.GisPolygon_py_set_Perimeter(self.cPtr, valParam)
    def ReCalc (self) :
        # recalculates area and perimeter of polygon
        TdhSpatial.GisPolygon_py_ReCalc(self.cPtr)
    def ContainsPt (self, xParam, yParam) :
        # returns true if 1st param is contained within the polygon
        return TdhSpatial.GisPolygon_py_ContainsPt(self.cPtr, xParam, yParam)
    def ContainsPoly (self, navParam, inclFlag) :
        # returns true if this polygon contains points in the 1st parameter, based on the 2nd param value:
        # 0 - if any point in the 1st param is contained in this poly
        # 1 - if all points in the 1st param are contained in this poly
        # 2 - if the first point in the 1st param is contained in this poly
        return TdhSpatial.GisPolygon_py_ContainsPoly(self.cPtr, navParam, inclFlag)
    def Value (self) :
        # returns a user defined value for polygon
        return TdhSpatial.GisPolygon_py_Value(self.cPtr);
    def set_Value (self, valParam) :
        #set user defined value for polygon
        TdhSpatial.GisPolygon_py_set_Value(self.cPtr, valParam)
    def incr_Value (self, valParam) :
        #increment user defined value for polygon
        TdhSpatial.GisPolygon_py_incr_Value(self.cPtr, valParam)
    def set_Parent (self, strParam, posParam) :
        #set parent polygon, 1 or 2 (2nd param), (e.g. id of polygon from which this polygon wwa created by interesection)
        TdhSpatial.GisPolygon_py_set_Parent(self.cPtr, C_Str(strParam), posParam)
    def Parent (self, posParam) :
        #return parent polygon, 1 or 2 (1st param), (e.g. id of polygon from which this polygon was created by interesection)
        return TdhSpatial.GisPolygon_py_Parent(self.cPtr, posParam)
    def set_AllocateFactor (self, valParam, posParam) :
        #set the proportion of parent polygon, 1 or 2 (2nd param), allocated to this polygon
        TdhSpatial.GisPolygon_py_set_AllocateFactor(self.cPtr, valParam, posParam)
    def AllocateFactor (self, posParam) :
        #returns the proportion of parent polygon, 1 or 2 (2nd param), allocated to this polygon
        return TdhSpatial.GisPolygon_py_AllocateFactor(self.cPtr, posParam)
    def set_Color (self, colorParam) :
        #set color for polygon
        TdhSpatial.GisPolygon_py_set_Color(self.cPtr, colorParam)
    def Color (self) :
        #return color for polygon
        return TdhSpatial.GisPolygon_py_Color(self.cPtr)
    def set_ColorFlag (self, flagParam) :
        # set flag that indicate whether color should be used (e.g. polygan should be painted)
        TdhSpatial.GisPolygon_py_set_ColorFlag (self.cPtr, flagParam)
    def  ColorFlag (self) :
        # returns flag that indicate whether color should be used
        return TdhSpatial.GisPolygon_py_ColorFlag(self.cPtr)
    def set_Width (self, widthParam) :
        #set width for polygon
        TdhSpatial.GisPolygon_py_set_Width(self.cPtr, widthParam)
    def Width (self) :
        #return width for polygon  virtual double Value () = 0; #return user defined value for polygon
        return TdhSpatial.GisPolygon_py_Width(self.cPtr);
    def set_Major (self,  flagParam) :
        #set flag indicating whehter this is a major contour
        TdhSpatial.GisPolygon_py_set_Major(self.cPtr, flagParam)
    def Major (self) :
        # returns flag indicating whehter this is a major contour
        return TdhSpatial.GisPolygon_py_Major (self.cPtr);

class TPolyNav_base_py (TRecordsNav_py) :
    # instances of this class are not normally created by the API user, create TPolyNav_py instances instead
    def __init__ (self, cParam):
        super().__init__(cParam)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      poly = TGisPolygon_base_py (objParam)
      return poly

class TGisPolygon_py (TGisPolygon_base_py):
    # This class adds Exclusion polygons
    def __init__(self, cParam = None):
        if cParam == None:
            cParam = TdhSpatial.Create_GisPolygon_py (None, True)
        super().__init__(cParam)
    def ExcludePolys (self) :
        #use this to navigate the exclusion polygons of a given polygon
        return TPolyNav_base_py(TdhSpatial.GisPolygon_py_ExcludePolys(self.cPtr))
    def AddExcludePoly (self, exclParam, idParam) :
        #add an exclusion polygon, i.e. a hole
        TdhSpatial.GisPolygon_py_AddExcludePoly(self.cPtr, exclParam, idParam)
    def Copy (self, targetParam = None) :
        #copy this polygon and return result. copy to 1st param if not NULL; otherwise,copy to new polygon
        if targetParam == None :
          targetParam = TGisPolygon_py
        TdhSpatial.GisPolygon_py_Copy(self.cPtr, targetParam.Ptr)
        return targetParam

class TPolyNav_py (TPolyNav_base_py) :
    # This class provides a navigator of a TGisPolygon_py list
    def __init__ (self, cParam = None):
      # cParam is not used when an API user creates an instance of this class
      if cParam == None :
        cParam = TdhSpatial.Create_PolyNav_py ()
      super().__init__(cParam)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      poly = TGisPolygon_py (objParam)
      return poly

class TGisMultiLine_py (TGisPolygon_base_py):
    # This class adds Exclusion polygons
    def __init__(self, cParam = None):
        if cParam == None:
            cParam = TdhSpatial.Create_GisMultiLine_py()
        super().__init__(cParam)

class TLineNav_py (TPolyNav_base_py) :
    # This class provides a navigator of a TGisMultiLine_py list
    def __init__ (self, cParam = None):
      # cParam is not used when an API user creates an instance of this class
      if cParam == None :
        cParam = TdhSpatial.Create_PolyNav_py ()
      super().__init__(cParam)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      poly = TGisMultiLine_py (objParam)
      return poly


class TThiessen_py:
# provides the functionality for creating thiessen polygons from pt data
# this class does not take possession of the pt data passed to it.
    def __init__(self, cParam = None):
        # cParam is not used when an API user creates an instance of this class
        if cParam == None:
            cParam = TdhSpatial.Create_Thiessen_py ()
        self.cPtr = cParam
    def PolyNav (self) :
        # returns a navigator for the TGisPolygon_py's generated using MakePolygons
        polyNav = TPolyNav_py (TdhSpatial.Thiessen_py_PolyNav (self.cPtr))
        return polyNav
    def AddPtData (self, ptParam) :
        #add a single pt to the pt list
        TdhSpatial.Thiessen_py_AddPtData(self.cPtr, ptParam)
    def AddPtList (self, navParam, resetFlag) :
        # add an entire pt list.
        # if 2nd param is true, reset pt list, otherwise add to existing pts
        TdhSpatial.Thiessen_py_AddPtList(self.cPtr, navParam.cPtr, resetFlag)
    def MakePolygons (self, polyParam, resetFlag=False) :
        # make polygons from the current pt list, using the 1st parameter as a boundary.
        # if 2nd param is true, add polygons to existing polygons, otherwise, start with reset of polygon list.
        TdhSpatial.Thiessen_py_MakePolygons(self.cPtr, polyParam.cPtr, resetFlag)
    def AutoBoundary(self, polyParam=None) :
        # create and return the minimum polygon containing all the pts in the pt list.
        # if the 1st param is not NULL, that TGisPolygon_py will contain the result
        if polyParam == None:
          polyParam = TGisPolygon_py()
        TdhSpatial.Thiessen_py_AutoBoundary(self.cPtr, polyParam.cPtr)
        return polyParam
    def Reset (self) :
        #empty the pt list.
        return TdhSpatial.Thiessen_py_Reset(self.cPtr)
    def HasData (self) :
        # returns true is the pt list has at least one pt, otherwise returns false.
        return TdhSpatial.Thiessen_py_HasData(self.cPtr);


class TContours_py:
    def __init__(self, cParam = None):
        # cParam is not used when an API user creates an instance of this class
        if cParam == None:
            cParam = TdhSpatial.Create_Contour_py ()
        self.cPtr = cParam
    def MakeContours (self, navParam, intvParam, boundary, colorCode, resetFlag) :
        #creates contour lines that can be accessed using ContourNav()
        #1st param is pt data for contonrs (these TPtData0 instances must have values set)
        #2nd param is is the contour interval
        #3rd param is the boundary polygon for the contours. If NULL, an auto boundary is used.
        #4th param is the color for the contours
        #5th param, if true, adds new contours to any existing contours (in ContourNav())
        TdhSpatial.Contour_py_MakeContours(self.cPtr, navParam.cPtr, intvParam, boundary, colorCode, resetFlag)
    def ContourNav (self) :
        #returns a navigator for the TGisMultiLine_py's created using MakeContours()
        return TLineNav_py(TdhSpatial.Contour_py_ContourNav(self.cPtr))
    def set_MajorStep (self, val) :
        #set the number of inertvals betwwen major contours
        TdhSpatial.Contour_py_set_MajorStep(self.cPtr, val)
    def set_MinSet (self, val) :
        #set flag indicating if minimum value applies
        TdhSpatial.Contour_py_set_MinSet(self.cPtr, val)
    def set_MaxSet (self, val) :
        #set flag indicating if maximum value applies
        TdhSpatial.Contour_py_set_MaxSet(self.cPtr, val)
    def set_Minimum (self, val) :
        #set the minimum value for a contour line
        TdhSpatial.Contour_py_set_Minimum(self.cPtr, val)
    def set_Maximum (self, val) :
        #set the maximum value for a contour line
        TdhSpatial.Contour_py_set_Maximum(self.cPtr, val)


class TContourPoly_py:
# a class for creating contour polygons (i.e. polygons defined by the area greater or less than a specified value)
    def __init__(self, cParam = None):
        # cParam is not used when an API user creates an instance of this class
        if cParam == None:
            cParam = TdhSpatial.Create_ContourPoly_py ()
        self.cPtr = cParam
    def MakeContourPolygons (self, navParam, boundary, val, valFlag) :
        # create polygons defined by the area greater or less than the 3rd param
        # 1st param contains the pts on which the contours are calculated
        # 2nd param contains the boundary polygon for the contours
        # 4th param indicates whether the result will be less (true) or greater than (false) the 3rd param
        TdhSpatial.ContourPoly_py_MakeContourPolygons(self.cPtr, navParam, boundary, val, valFlag)
    def PolyNav (self) :
        # returns a navigator for the TGisPolygon_py's generated using MakeContourPolygons
        return TPolyNav_py(TdhSpatial.ContourPoly_py_PolyNav (self.cPtr))
  

class TPolyIntersect_py:
# a class for performing polygon intersection operations
    def __init__(self, cParam = None):
       if (cParam == None):
           cParam = TdhSpatial.Create_PolyIntersect_py()
       self.cPtr = cParam
    def PolyNav (self) :
        # returns a TPolyNav_py containing the execution results
        return TPolyNav_py(TdhSpatial.PolyIntersect_py_PolyNav (self.cPtr))
    def Execute (self, poly1, poly2, resetFlag) :
        # performs an operation based on 2 single polygons (params 1 and 2)
        # the result is one or more polygons representing the intersection of the 2 input polygons
        # the Parent (1 or 2) function of the result polygons will return the id of the input polygon
        # the AllocateFactor (1 or 2) function of the result polygons will return the proportion of the area of the parent polygon covered by the result polygon
        # the 3rd param determines whether the results navigator is emptied at the beginning of the operation
        return TdhSpatial.PolyIntersect_py_Execute(self.cPtr, poly1, poly2, resetFlag)
    def ExecutePolyListToPoly (self, navParam, polyParam, resetFlag) :
        # performs an operations based on a polygon navigator (1st param) and a single polygon (2nd param)
        # the 3rd param determines whether the results navigator is emptied at the beginning of the operation
        TdhSpatial.PolyIntersect_py_ExecutePolyListToPoly(self.cPtr, navParam, polyParam, resetFlag)
    def ExecutePolyListToPolyList (self, nav1, nav2, resetFlag) :
        # performs an operation based on 2 polygon navigaotors (1st and 2nd params)
        # the 3rd param determines whether the results navigator is emptied at the beginning of the operation
        TdhSpatial.PolyIntersect_py_ExecutePolyListToPolyList (self.cPtr, nav1, nav2, resetFlag)
    def AllocatePtsToPolyList (self, ptNav, polyNav, resetFlag) :
        #allocates the pts in a TPtNav_py (1st param) to the polygons in a TPolyNav_py (2nd param)
        #the results can be found using AllocatedTo() in TPtData
        #the values of the pts will be added to the value of the polygons to which they are allocated
        #if the 3rd param is true, the values of the polygons will be set to 0 at the start
        TdhSpatial.PolyIntersect_py_AllocatePtsToPolyList(self.cPtr, ptNav, polyNav, resetFlag)
    def AllocatePolyListToPolyList (self, nav1, nav2, resetFlag) :
        # adds a portion of the values of the polygons in a TPolyNav_py (1st param) 
        # to the polygons in aanother TPolyNav_py (2nd param),  based on proportional areas
        # if the 3rd param is true, the values of the 2nd param polygons will be set to 0 at the start
        TdhSpatial.PolyIntersect_py_AllocatePolyListToPolyList (self.cPtr, nav1, nav2, resetFlag)

class TPolyMerge_py (TPolyIntersect_py):
# a class for performing polygon merge operations
# see documentation for TPolyIntersection_py
    def __init__(self, cParam = None):
       if (cParam == None):
         cParam = TdhSpatial.Create_PolyMerge_py()
       super().__init__(cParam)

class TPolySubract_py (TPolyIntersect_py):
# a class for performing polygon subtract operations
# see documentation for TPolyIntersection_py
    def __init__(self, cParam = None):
       if (cParam == None):
         cParam = TdhSpatial.Create_PolySubtract_py()
       super().__init__(cParam)

class TPolyTrim_py (TPolyIntersect_py):
# a class for performing multiline trim operations
# see documentation for TPolyIntersection_py
# for this class the 1st param of the execute functions are TGisMultiLines
# and the results TGisMultiLines that have been trimmed within the specified polygons (2nd param)
    def __init__(self, cParam = None):
       if (cParam == None):
         cParam = TdhSpatial.Create_PolyTrim_py()
       super().__init__(cParam)

class TPolySplit_py (TPolyIntersect_py):
# a class for performing polygon split operations
# see documentation for TPolyIntersection_py
# for this class the 2nd param of the execute functions are TGisMultiLines
# and the results TGisPolygons that have been split by specified TGisMultiLines (2nd param)
    def __init__(self, cParam = None):
       if (cParam == None):
         cParam = TdhSpatial.Create_PolySplit_py()
       super().__init__(cParam)


class TDissolve_py:
    def __init__(self):
       self.cPtr = TdhSpatial.Create_Dissolve_py ()
    def NewPolys (self)  :
        # a TPolyNav containing the results of the  dissolve
        return TdhSpatial.Dissolve_py_NewPolys(self.cPtr)
    def Dissolve (self, navParam) :
        #performs a dissolve on the polygons in the 1st param
        # all the polygons with matching values will be merged
        # such that there will be no overlapping or shared borders of polygons with the same value
        return TdhSpatial.Dissolve_py_Dissolve(self.cPtr, navParam)


