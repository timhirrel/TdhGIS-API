from ctypes import *
import os
import sys

import platform

if (platform.system() == "Linux") :
  libDir = "./bin/linux/"
if (platform.system() == "Windows") :
  libDir = "./bin/msvc/"

dataDir = "./TdhGIS_API_demo_Data" #set this to the location of the TdhGIS_API_demo Data directory
