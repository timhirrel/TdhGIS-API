# This file demonstrates the capability to store and retrieve
# data used within the TdhGIS API using a TdhGIS (sqlite) database
# This class requires the Sqlite library in addition to the TdhCommon and TdhSpatial libraries
# The dataDir variable must be set to the location of a Data directory, as included with the TdhGIS API package

from ..TdhGIS_API_demo_py.TdhSpatial_API_demo import *
from ..TdhGIS_API_py.TdhGIS_API import *
from ..TdhGIS_API_universal import *


class TTdhGIS_api_demo_py:
# this class demonstrates the ability to write to and read from a TdhGIS (sqlite) database

    def __init__(self):
        self.gisAPI = TTdhGIS_API_py()
        self.spatialAPI = TTdhSpatial_api_demo_py()
  
    def Main (self, dirParam) :
    # dirParam should specify the path to a TdhGIS database file    
        self.dataDir = dirParam
        self.WritePolyGroup ()
        self.ReadPolyGroup ()

    def WritePolyGroup (self) :
    # this function reads a set of x,y points
    # creates theissen polygons from the points
    # saves the polygons to a TdhGIS database    
        ptNav = self.spatialAPI.GetPts ()
        polyNav = self.spatialAPI.MakeThiessens(ptNav); # create thiessen polygosn from the the points in ptNav
        polyGroup = Create_PolyGroup (polyNav, False) #create a polygon group using the thies polygon navigator
        polyGroup.set_id("polygons_export") # name the polygon group
        self.gisAPI.set_PolyGroup (polyGroup) # set gisAPI PolyGroup to the new group
        self.gisAPI.WriteGroup (self.dataDir, dtGisPolygon) # write the polygon group to the TdhGIS database
        self.gisAPI.set_PolyGroup (None) # set gisAPI PolyGroup to the default

    def ReadPolyGroup (self) :
    # this function reads a group of polygons from a TdhGIS database
    # writes the polygons to console        
        self.gisAPI.ReadGroup(self.dataDir, dtGisPolygon, "polygons_export", True) # read the polygon group that was previously written to the TdhGIS database
        self.spatialAPI.WritePolygons (self.gisAPI.PolyGroup().PolyNav()) # output the polygons to console

Set_TdhGIS_API_Cfuncs()

# uncomment the following lines to run this demo independently
#gisAPI = TTdhGIS_api_demo_py()
#gisAPI.Main(dataDir)
