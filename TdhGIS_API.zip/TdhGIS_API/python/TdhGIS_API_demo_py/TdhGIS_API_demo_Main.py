# This package includes the following 3 demo classes
# The classes are intended to be used within a console app
# These demo classes can be run independently, per the instructions in the files in which they are contained

# The first class demonstrates some capabilities for performing spatial operations
# i.e. making thiessen polygons from a set of points and making contours from a set of points
# This class requires 2 supporting libraries, TdhCommon and TdhSpatial
# This class is contained in the file TdhSpatial_API_demo.py
from ..TdhGIS_API_demo_py.TdhSpatial_API_demo import *


# The second class demonstrates the capability to store and retrieve
# TdhGIS data using as Sqlite database
# This class requires the Sqlite library in addition to the TdhCommon and TdhSpatial libraries
# A dataDir variable must be set to the location of Data directory included with the TdhGIS API package
# This class is contained in the file TdhGIS_API_demo.py
#from ..TdhGIS_API_demo_py.TdhGIS_API_demo import *

# The third class demonstrates the capability to store and retrieve
# GIS data of various formats using the GDAL/OGR libraries and the TdhOGR_API library
# The GDAL package must be available. The TdhCairo and TdhPath libraries must be available
# A dataDir variable must be set to the location of Data directory included with the TdhGIS API package
# This class is contained in the file TdhOGR_API_demo.py
#from ..TdhGIS_API_demo_py.TdhOGR_API_demo import *


from ..TdhGIS_API_universal import * #universal variables (libDir and dataDir)

def main() :
  spatialAPI = TTdhSpatial_api_demo_py()
  spatialAPI.Main()
#  gisAPI = TTdhGIS_api_demo_py()
#  gisAPI.Main(dataDir)
#  ogrAPI = TTdhOGR_api_demo_py()
#  ogrAPI.Main(dataDir);


main()
