# This file demonstrates some capabilities for performing spatial operations
# i.e. making thiessen polygons from a set of points and making contours from a set of points# This class requires 2 supporting libraries, TdhCommon and TdhSpatial

from ..TdhCommon_py.RecordsNav import *
from ..TdhCommon_py.CadPrimitives import *
from ..TdhSpatial_py.TdhSpatial_Intf import *


pts = [
# The point data to be used in the demo    
  [10,40,10],
  [20,60,23],
  [37,58,22],
  [40,40,32],
  [30,20,16]
]

def Set_Cfuncs () :
    # set up connections to C++ functions        
    Set_RecordsNav_Cfuncs()
    Set_CadPrimitives_Cfuncs()
    Set_SpatialIntf_Cfuncs()
    
class TTdhSpatial_api_demo_py:
# a class that contains the demo functionality
    def GetPts (self) : 
    # copy x,y data from the array pts into a TPtNav structure using the default TPointXY
        ptNav = TPtDataNav_py ()
        for i in range (0, len(pts)) : 
            ptData = TPtData_py()
            ptNav.AddRec(ptData, str(i), False)
            ptData.setX(pts[i][0])
            ptData.setY(pts[i][1])
            ptData.set_Value(pts[i][2])
        return ptNav

    def WriteVertexNav (self, vertexNav) : 
    # output polygon points to console
        print("  Points: ",  vertexNav.get_Count())
        goFlag = vertexNav.GotoFirst()
        while (goFlag) :
            pt = vertexNav.GetData()
            print (f"    {pt.getX():.2f}, {pt.getY():.2f}")
            goFlag = vertexNav.GotoNext()

    def WriteOnePoly (self, poly) : 
    # output one polygon to console
        print ("Polygon: ", poly.PolyID().decode())
        print (f"  Area: {poly.CalcArea():.2f}")
        print (f"  Perimeter: {poly.CalcPerimeter():.2f}")
        print (f"  Value: {poly.Value():.2f}")
        self.WriteVertexNav(poly.PtNav())

    def WritePolygons (self, polyNav) : 
    # output a collection of polygons to console
        goFlag = polyNav.GotoFirst()
        while (goFlag) :
            self.WriteOnePoly (polyNav.GetData())
            goFlag = polyNav.GotoNext()

    def MakeThiessens (self, ptNav) : 
    # create thiessen polygons from the points in ptNav
        thies = TThiessen_py ()
        thies.AddPtList (ptNav, True)  #thies is set to use ptNav, removing any previous points
        boundary = thies.AutoBoundary()
        thies.MakePolygons (boundary) #makes thiessen polygons using the specified boundary
        return thies.PolyNav()
        
    def WriteOneContour (self, line) : 
    # write one contour line to console
        print (f"Contour Value:  {line.Value():.2f}")
        majorStr = "no"
        if (line.Major()) :
            majorStr = "yes"
        print ("  Major: " + majorStr)
        self.WriteVertexNav(line.PtNav())

    def WriteContours (self, contourNav) : 
    # write a collection of contour lines to console
        goFlag = contourNav.GotoFirst()
        while (goFlag) :
            self.WriteOneContour (contourNav.GetData())
            goFlag = contourNav.GotoNext()

    def MakeContours (self, ptNav) : 
    # create contour lines and output to console
        contour = TContours_py()
        contour.set_MajorStep(20);
        contour.MakeContours (ptNav, 5, None, colorBlack, False); # contour lines are created from the points in ptNav using a contour interval of 5
        return contour.ContourNav()         

    def ReadPolygon (self) : #create a polygon using the default TPointXY for x,y data
        newPoly = TGisPolygon_py()
        for i in range (0, len(pts)) : 
            newPoly.AddXY(pts[i][0], pts[i][1]) # x,y data is copied into the default TPointXY class
        return newPoly

    def Main (self):
    # read a set of points
    # use the points to create and output thiessen polygons    
        testPoly = self.ReadPolygon()
        testPoly.set_Value(10)
        testPoly.set_PolyID("test3")
        self.WriteOnePoly(testPoly)

        ptNav = self.GetPts()
        polyNav = self.MakeThiessens (ptNav)
        self.WritePolygons(polyNav);
        contourNav = self.MakeContours (ptNav)
        self.WriteContours(contourNav) # output the contours to console

Set_Cfuncs()

# uncomment the following lines to run this demo independently
#spatialAPI = TTdhSpatial_api_demo_py()
#spatialAPI.Main()
