# this file demonstrates the ability to write and read data using various GIS formats

from ..TdhGIS_API_demo_py.TdhSpatial_API_demo import *
from ..TdhGIS_API_py.TdhGIS_API import *
from ..TdhOGR_API_py.TdhOGR_API import *
from ..TdhGIS_API_universal import *


class TTdhOGR_api_demo_py:
    # this class demonstrates the exchange of data with various GIS formats
    def __init__(self):
        self.ogrAPI = TTdhOGR_API_py ()
        self.spatialAPI = TTdhSpatial_api_demo_py()
        self.cadOptions = TCadOptions_py()
  
    def Main(self, dirParam) :
        # call functions demonstrating various data exchanges
        self.dataDir = dirParam
        self.GetOGRdata_shp() 
        self.ExportPolys_shp() 
        self.GetOGRdata_osm() 
        self.ExportPolys_gis() 
    
    def GetOGRdata_shp (self) :
        # import into the TdhGIS API polygon data from a shapefile
        self.ogrAPI.SetDriverStr("ESRI Shapefile")
        if self.ogrAPI.ReadTdhData (ftOther, self.dataDir + "/Polygons.shp", dtGisPolygon, True): #read the polygons from a shapefile into the default polygon group
          self.spatialAPI.WritePolygons(self.ogrAPI.PolyGroup().PolyNav()) #output the polygons to console

    def ExportPolys_shp (self) :
        # export from the TdhGIS API polygon data to a shapefile
        self.ogrAPI.PolyGroup().PolyNav().DeleteAll()
        self.ogrAPI.PolyGroup().set_id("Test1")
        self.ogrAPI.PolyGroup().AddPoly(self.spatialAPI.ReadPolygon(), "1") # add a polygon to the default polygon group
        self.ogrAPI.SetDriverStr("ESRI Shapefile")
        self.ogrAPI.WriteTdhData (ftOther, self.dataDir + "/API.shp", dtGisPolygon) # write the default polygon group to a shapefile

    def GetOGRdata_osm (self) :
        # import into the TdhGIS API polygon data from an OpenStreetMap file
        self.ogrAPI.add_TagRequired("landuse, meadow", True) # the tags used for OSM data import
        self.ogrAPI.set_OsmSource("Ways")
        save_LonLat = self.cadOptions.get_LonLat();
        self.cadOptions.set_LonLat(True)  # notify API that geometry data is long/lat so that area calculation is correct
        if self.ogrAPI.ReadTdhData (ftOSM, self.dataDir + "/JuneLake.osm", dtGisPolygon, True) : # import data from an OSM data file
          self.spatialAPI.WritePolygons(self.ogrAPI.PolyGroup().PolyNav()) # output the polygons to console
        self.ogrAPI.PolyGroup().set_id("June Lake Meadows")
        self.cadOptions.set_LonLat(save_LonLat)

    def ExportPolys_gis (self) :
        # write the data in Polygon() to a TdhGIS database
        # while transforming the coordinates
        self.ogrAPI.set_SourceCRS("+proj=longlat +ellps=WGS84 +datum=WGS84");
        self.ogrAPI.set_TargetCRS("+proj=aea +lat_1=29.5 +lat_2=45.5 +lat_0=37.5 +lon_0=-96 +x_0=0 +y_0=0 +ellps=GRS80 +datum=NAD83 +units=m +no_defs ");
        self.ogrAPI.set_TransformFlag(True);
        self.ogrAPI.WriteTdhData (ftTdhGIS, self.dataDir, dtGisPolygon) # write the default polygon group to a TdhGIS database
        self.ogrAPI.set_TransformFlag(False);

Set_TdhOGR_API_Cfuncs()

# uncomment the following lines to run this demo independently
# ogrAPI = TTdhOGR_api_demo_py()
# ogrAPI.Main(dataDir)
