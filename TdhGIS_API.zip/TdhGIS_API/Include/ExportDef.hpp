//provided the definitions needed for exporting from MS Windows dll's

#ifndef EXPORTDEF_HPP_INCLUDED
#define EXPORTDEF_HPP_INCLUDED

#include <stdlib.h>
#define EXTERNC extern "C"

#ifdef _WIN32
#ifndef tdh_Windows
  #define tdh_Windows
#endif
#endif // _WIN32

#ifdef tdh_Windows
#define EXPORTPROC __declspec(dllexport)
#else
#define EXPORTPROC
#endif

#ifdef TDHCOMMON_EXPORTS
  #define EXPORT_common __declspec(dllexport)
#else
  #ifdef tdh_Windows
    #define EXPORT_common __declspec(dllimport)
  #else
    #define EXPORT_common
  #endif // tdh_Windows
#endif

enum keycomp_result {crKeysEqual, crExKeyLess, crNewKeyLess, crInvalid};
//enum NavOpts {navFirst, navLast, navNext, navPrev, navFind, navRandom, navNew, navNear, navNoNotify, navDelete, navChangeKey};



#endif // EXPORTDEF_HPP_INCLUDED
