/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/

#ifndef TdhSpatialInf_Header
#define TdhSpatialInf_Header

// This header provides access to the functionality in the TdhSpatial library


#include "CadPrimitives0.h"
#include "StringDef.hpp"
#include "RecordsNav0.h"


#ifdef TDHSPATIAL_EXPORTS
  #define EXPORT_spatial __declspec(dllexport)
#else
  #ifdef tdh_Windows
    #define EXPORT_spatial __declspec(dllimport)
  #else
    #define EXPORT_spatial
  #endif
#endif


enum GisDataTypes {dtUnknown = -1, dtGisPt, dtGisPolygon, dtGisMultiLine, dtContourLine, dtExcludePolys, dtGisNetwork};

class EXPORTPROC TPtData0 {
//defines a GIS point type used in TdhSpatial
protected:
public:
  virtual ~TPtData0 () {}
  virtual tdhString ID () = 0;
  virtual void set_ID (tdhString) = 0; //if instance belongs to a TPtGroup, ID can only be changed by using TPtGroup::PtNav()->SetKey()
  virtual TPointPtr Pt () = 0;
  virtual TPointXY PtVal () = 0;
  virtual double Value () = 0; //return a user define value
  virtual void set_Value (double) = 0; //set a user defined value
  virtual void setX (double) = 0;
  virtual void setY (double) = 0;
  virtual double getX () = 0;
  virtual double getY () = 0;
  virtual void SetXY (double, double) = 0;
  virtual TPtData0 *Copy (TPtData0* = NULL) = 0; //copies this to the 1st param, creates and returns a new TPtData0 if 1st param is NULL
  virtual void incr_Value (double) = 0; //increment this value
  virtual tdhString AllocatedTo () = 0; //return the id of the polygon to which this has been allocated
  virtual void set_AllocatedTo (tdhString) = 0; //save the id of the polygon to which this has been allocated
  virtual bool Allocated () = 0; //return true if this has been allocated to a polygon
  virtual void set_Allocated (bool) = 0; //set to true if this has been allocated to a polygon
  virtual double Weight () = 0; //returns the weight of this for functionality using weighting
  virtual void set_Weight (double) = 0; //sets the weight of this for functionality using weighting
  virtual void incr_Weight (double) = 0; //increments the weight of this for functionality using weighting
  };

TPtData0 EXPORTPROC *Create_PtData (TPointPtr = NULL, bool = false); // creates and returns an instance of TPtData0

typedef TRecordsNav0 <TPtData0, tdhString> TPtNav;
extern TPtNav EXPORTPROC *Create_PtNav (); // // creates abd returns an instance of TPtNav

class EXPORTPROC TPtFuncs0 {
// a class for manipulating TPtNavs
protected:
public:
  virtual ~TPtFuncs0() {}
  virtual TPtData0* FindNearPt (TPtData0*, TPtNav*) = 0; //return the TPtData in the 2nd param nearest to the 1st param
  virtual void ReducePts(TPtNav*, double) = 0; // eliminates pts in 1st param that are within 2nd param distance of an adjacent pt, averaging the values
  virtual void CombinePts (TPtData0*, TPtData0*, TPtNav*) = 0;
    // computes the average of 2 points (1st and 2nd params), both belonging to the 3rd param
    // modifies the 1st point to equal the average and deletes the 2nd point
    // weights the averaging such that a combined pt has a higher weighting when combined again.
  };
TPtFuncs0 EXPORTPROC *Create_PtFuncs();



class TVertex_cw; //a data structure defined and used within TdhSpatial, derived from TVertex0
typedef TRecordsNav0 <TVertex_cw, TVertex_cw*> TVertexNav_cw;

class TGisPolygon0; //defined below
class TGisPolygon; //defined and used within TdhSpatial, implements TGisPolygon0
typedef TRecordsNav0 <TGisPolygon0, tdhString> TPolyNav;

class EXPORTPROC TGisPolygon0 : virtual public TMultiLine0 {
// an abstract class for implementing polygon functionality
protected:
  virtual bool HasRayPt () = 0; //return variable the tells whether the polgon has a ray pt
  virtual void SetRayPt (bool) = 0; //set variable the tells whether the polgon has a ray pt
public:
  virtual ~TGisPolygon0() {}
  virtual TGisPolygon *GisPolygon () = 0;
  virtual tdhString PolyID () = 0;
  virtual void set_PolyID (tdhString) = 0;
//  virtual TVertexNav *PtNav() = 0;
  virtual TVertexNav_cw *PtNavCW() = 0;
  virtual TPolyNav *ExcludePolys () = 0; //use this to navigate the exclusion polygons of a given polygon
  virtual void Reset (bool) = 0; //delete all pts, set all data to default values; if 1st param is true, exclusion polys will be deleted
  virtual void DeletePts () = 0; //delete all pts for polygon
  virtual TCadRect0 *GetExtents () = 0; //returns the extents of the polygon

  virtual void SetCW (bool val) = 0; //determine whether the pts are in clockwise order and set cw variable
  virtual void ResetCW () = 0; //reset flag that tells whether clockwise variable has been set
  virtual bool CWSet() = 0; //return flag  that tells whether clockwise variable has been set
  virtual bool IsCW () = 0; //return variable that tells whether pts are clockwise

  virtual void AddExcludePoly (TGisPolygon0*, tdhString="") = 0; //add an exclusion polygon, i.e. a hole
  virtual TGisPolygon0 *Copy(TGisPolygon0* = NULL) = 0; //copy this polygon and return result. copy to 1st param if not NULL; otherwise,copy to new polygon
  virtual void CopyParams (TGisPolygon0*) = 0; //copy polygon variable to 1st param
  virtual bool CalcCentroid (TPointPtr) = 0; //return the centroid for the polygon
  virtual void set_Centroid(TPtParam) = 0; //set the centroid, will be resets if pts change
  virtual double CalcArea() = 0; //returns the area of the polygon. substracts the area of any exclusion polygon
  virtual void set_Area (double) = 0; //set the area, resets if pts change
  virtual double CalcPerimeter() = 0; //return the perimeter of the polygon, including the perimeter of any exclusion polygon
  virtual void set_Perimeter(double) = 0; //set the perimeter, resets if pts change
  virtual void ReCalc () = 0; // recalculates area and perimeter of polygon
  virtual bool ContainsPt (TPtParam) = 0; // returns true if 1st param is contained within the polygon
  virtual bool ContainsPoly (TVertexNav*, bool=true) = 0; //returns true if the parameter poly is entirely within this poly

  virtual double Value () = 0; //return a user define value for polygon
  virtual void set_Value (double) = 0; //set user defined value for polygon
  virtual void incr_Value (double) = 0;  //increment user defined value for polygon
  virtual void set_Parent (tdhString, int) = 0; //set parent polygon, 1 or 2 (2nd param), (e.g. id of polygon from which this polygon wwa created by interesection)
  virtual tdhString Parent (int) = 0; //return parent polygon, 1 or 2 (1st param), (e.g. id of polygon from which this polygon was created by interesection)
  virtual void set_AllocateFactor (double, int) = 0; //set the proportion of parent polygon, 1 or 2 (2nd param), allocated to this polygon
  virtual double AllocateFactor (int) = 0; //return the proportion of parent polygon, 1 or 2 (2nd param), allocated to this polygon

  virtual void set_Color (unsigned int) = 0; //set color for polygon
  virtual unsigned int Color () = 0; //return color for polygon
  virtual void set_ColorFlag (bool) = 0; // set flag that indicate whether color should be used (e.g. polygan should be painted)
  virtual bool ColorFlag () = 0; // return flag that indicate whehter color should be used
  virtual void set_Width (float) = 0; //set width for polygon
  virtual float Width () = 0; //return width for polygon  virtual double Value () = 0; //return user defined value for polygon
  virtual void set_Major (char) = 0; //set flag indicating whehter this is a major contour
  virtual char Major () = 0; //return flag indicating whehter this is a major contour
  };

TGisPolygon0 EXPORTPROC *Create_GisPolygon (TVertexNav_cw* = NULL, bool ownParam = true);
  // return an implementation of TGisPolygon0
  // if the 1st param is not NULL, it will be used as the TVertexNav for the polygon; otherwise, a TVertexNav will be created.
  // if the 2nd param is true, a non NULL 1st param will be owned by the polygon (i.e. it will be delete when the polygon is deleted)

typedef TGisPolygon0 TGisMultiLine0;

TPolyNav EXPORTPROC *Create_PolyNav (); //create and return a TPolyNav

TPolyNav EXPORTPROC *Create_ExcludPolyNav (TPolyNav*); //use this to navigate the exclusion polygons of the current polygon for the navigator passed as 1st param

void EXPORTPROC Copy_Polygons (TPolyNav *source, TPolyNav *target); // copy polygons in 1st param to 2nd param

typedef TGisPolygon0 TGisMultiLine;


class EXPORTPROC TThiessen0 {
// provides the functionality for creating thiessen polygons from pt data
// this class does not take possession of the pt data passed to it.
protected:
public:
  TThiessen0 () {}
  virtual ~TThiessen0 () {}
  virtual TPolyNav *PolyNav() = 0;
    // a navigator containing the generated polygons
  virtual void AddPtData (TPtData0*) = 0;
    //add a single pt to the pt list
  virtual void AddPtList (TPtNav*, bool) = 0;
    // add an entire pt list.
    // if 2nd param is true, reset pt list, otherwise add to existing pts
  virtual void MakePolygons (TGisPolygon0*, bool =false) = 0;
    // make polygons from the current pt list, using the 1st parameter as a boundary.
    // if 2nd param is true, add polygons to existing polygons, otherwise, start with reset of polygon list.
  virtual TGisPolygon0 *AutoBoundary(TGisPolygon0* = NULL)  = 0;
    //create and return the minimum polygon containing all the pts in the pt list.
    // if the 1st param is not NULL, that pointer will contain the result..
  virtual void Reset() = 0;
    //empty the pt list.
  virtual bool HasData () = 0;
    // returns true is the pt list has at least one pt, otherwise returns false.
  };

TThiessen0 EXPORTPROC *Create_Thiessen (TMessenger0* = NULL); //create and return an instance of TThiessen0


typedef TGisPolygon0 TGisContour0; // currently, there is no difference between TGisPolygon0 and TGisContour0, but that may change in the future
typedef TRecordsNav0 <TGisContour0, tdhString>  TContourNav;


TGisContour0 EXPORTPROC *Create_GisContour (); //create and return an instance of TGisContour0

class EXPORTPROC TContour0 {
// a class for creating contour lines from a TPtNav
public:
  virtual ~TContour0 () {}
  virtual void MakeContours (TPtNav*, double intvParam, TGisPolygon0 *boundary, unsigned colorCode, bool) = 0;
    //creates contour lines that can be accessed using ContourNav()
    //1st param is pt data for contonrs (these TPtData0 instances must have values set)
    //2nd param is is the contour interval
    //3rd param is the boundary polygon for the contours. If NULL, an auto boundary is used.
    //4th param is the color for the contours
    //5th param, if true, adds new contours to any existing contours (in ContourNav())
  virtual TPolyNav *ContourNav () = 0; //access contour lines created using MakeContours()
  virtual void set_MajorStep (int val) = 0; //set the number of inertvals betwwen major contours
  virtual void set_MinSet (bool val) = 0; //set flag indicating if minimum value applies
  virtual void set_MaxSet (bool val) = 0; //set flag indicating if maximum value applies
  virtual void set_Minimum (double val) = 0; //set the minimum value for a contour line
  virtual void set_Maximum (double val) = 0; //set the maximum value for a contour line
  };

TContour0 EXPORTPROC *Create_Contour (); //create and return an instance of TContour0

class EXPORTPROC TContourPoly0 {
// a class for creating contour polygons (i.e. polygons defined by the area greater or less than a specified value)
public:
  virtual void MakeContourPolygons (TPtNav*, TGisPolygon0*, double, bool) = 0;
    // create polygons defined by the area greater or less than the 3rd param
    // 1st param contains the pts on which the contours are calculated
    // 2nd param contains the boundary polygon for the contours
    // 4th param indicates whether the result will be less (true) or greater than (false) the 3rd param
  virtual TPolyNav *PolyNav () = 0;
    // return a TPolyNav containing the results from MakeContoursPolygons()
  };

TContourPoly0 EXPORTPROC *Create_ContourPoly (); //create and return an instance of TContourPoly0

class TShowTriangulate0 {
// a class allowing user defined actions at each iteration of the polygon triangulation process
public:
  virtual TMessenger0 *Messages () {return NoMessProc();} //override this function to handle messages from the api
  virtual void DisplayPoly (TGisPolygon0*, int) = 0;
    // this function will be called at the end of each iteration of the polygon triangulation process
    // 1st param is a remaining polygon after an an iteration of triangulation
    // 2nd param is the iteration number
  virtual void Refresh () = 0; //called after triangulation has been completed
  };

void EXPORTPROC ShowTriangulation (TGisPolygon0*, TShowTriangulate0*);
  // perform a triangulation process using a user defined TShowTriangulation class (2nd param)
  // 1st param is polygon to be triangulated


class EXPORTPROC TPolyIntersect0 {
// a class for performing spatial operations:
//   - based on polygon intersections, the type of operation depends on the implementation
//   - based on allocating pts or polygons to a different set of polygons
public:
  virtual ~TPolyIntersect0 () {}
  virtual TPolyNav *PolyNav () = 0; // return a navigator container the results of the operation
  virtual bool Execute (TGisPolygon0*, TGisPolygon0*, bool =true) = 0;
    //performs an operation based on 2 single polygons
    //the result is one or more polygons representing the intersection of the 2 input polygons
    //the Parent (1 or 2) function of the result polygons will return the id of the input polygon
    //the AllocateFactor (1 or 2) function of the result polygons will return the proportion of the area of the parent polygon covered by the result polygon
    //the 3rd param determines whether the results navigator is emptied at the beginning of the operation
  virtual void ExecutePolyListToPoly (TPolyNav*, TGisPolygon0*, bool =true) = 0;
    //performs an operations based on a polygon navigator and a single polygon
    //the 3rd param determines whether the results navigator is emptied at the beginning of the operation
  virtual void ExecutePolyListToPolyList (TPolyNav*, TPolyNav*, bool =true) = 0;
    //performs an operation based on 2 polygon navigaotors
    //the 3rd param determines whether the results navigator is emptied at the beginning of the operation
  virtual void AllocatePtsToPolyList (TPtNav*, TPolyNav*, bool =true) = 0;
    //allocates the pts in the 1st param to the polygons in the 2nd param
    //the results can be found using AllocatedTo() in TPtData
    //the values of the pts will be added to the value of the polygons to which they are allocated
    //if the 3rd param is true, the values of the polygons will be set to 0 at the start
  virtual void AllocatePolyListToPolyList (TPolyNav*, TPolyNav*, bool =true) = 0;
    //adds a portion of the values of the polygons in the 1st param to the polygons in the 2nd param, based on proportional areas
    //if the 3rd param is true, the values of the 2nd param polygons will be set to 0 at the start
  };

TPolyIntersect0 EXPORTPROC *Create_PolyIntersect();
  // returns an implementation of TPolyIntersect0 that performs polygon intersection operations

TPolyIntersect0 EXPORTPROC *Create_PolyMerge();
  // returns an implementation of TPolyIntersect0 that performs polygon merge operations

TPolyIntersect0 EXPORTPROC *Create_PolySubtract();
  // returns an implementation of TPolyIntersect0 that performs polygon subtraction operations (the 2nd param is subtracted from the 1st param)

TPolyIntersect0 EXPORTPROC *Create_PolyTrim();
  // returns an implementation of TPolyIntersect0 that trims a multiline (1st param) to fit within a polygon (2nd param)

TPolyIntersect0 EXPORTPROC *Create_PolySplit();
  // returns an implementation of TPolyIntersect0 that splits a polygon (1st param) along a multiline (2nd param)

#endif // TdhSpatialHeader


