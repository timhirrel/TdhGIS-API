#ifndef TdhGisApiDemo_Header
#define TdhGisApiDemo_Header

#include "TdhSpatial_Intf.h"

//The following 3 classes demonstrate some capabilities within the TdhGIS API
//The classes are intended to be used within a console app
//The required supporting libraries increase with each class

// The first class demonstrates some capabilities for performing spatial operations
// i.e. making thiessen polygons from a set of points and making contours from a set of points
// This class requires only 2 supporting libraries, TdhCommon and TdhSpatial

class TTdhSpatial_api_demo {
protected:
  TCadOptions *cadOptions;
public:
  TTdhSpatial_api_demo();
  virtual ~TTdhSpatial_api_demo();
  virtual void Main();
  virtual TPtNav *GetPts ();
  virtual void WriteVertexNav (TVertexNav*);
  virtual void WriteOnePoly (TGisPolygon0*);
  virtual void WritePolygons (TPolyNav*);
  virtual void MakeThiessens (TThiessen0*, TPtNav*);
  virtual void WriteOneContour (TGisContour0 *line);
  virtual void WriteContours (TContourNav*);
  virtual void WriteThiessens (TPtNav*);
  virtual void MakeContours (TPtNav*);
  virtual TGisPolygon0 *MakePolygon ();
  virtual TGisPolygon0 *ReadPolygon ();
  virtual TCadOptions *CadOptions() {return cadOptions;}
  };

// The second class demonstrates the capability to store and retrieve
// data used within the TdhGIS API using a TdhGIS database
// This class requires the Sqlite library in addition to the TdhCommon and TdhSpatial libraries
#include "TdhGIS_API.h"

class TTdhGIS_api_demo {
protected:
  TTdhGIS_API0 *gisAPI;
  TTdhSpatial_api_demo *spatialAPI;
  tdhString dataDir;
public:
  TTdhGIS_api_demo ();
  virtual ~TTdhGIS_api_demo ();
  virtual void Main (tdhString);
  virtual void ReadPolyGroup();
  virtual void WritePolyGroup();
  };

// The third class demonstrates the capability to store and retrieve
// data used within the TdhGIS API using the GDAL/OGR libraries
// This class also requires the TdhPath and TdhCairo libraries
#include "TdhOGR_API.h"

class TTdhOGR_api_demo {
protected:
  TTdhOGR_API0 *ogrAPI;
  TTdhSpatial_api_demo *spatialAPI;
  tdhString dataDir;
public:
  TTdhOGR_api_demo ();
  virtual ~TTdhOGR_api_demo ();
  virtual void Main (tdhString);
  virtual void GetOGRdata_shp ();
  virtual void GetOGRdata_osm ();
  virtual void ExportPolys_shp ();
  virtual void ExportPolys_gis ();
  virtual TCadOptions *CadOptions() {return spatialAPI->CadOptions();}
  };

#endif // TdhGisApiDemo_Header
