/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/


// Provides the most basic functionality for vector graphics

#ifndef CadPrimitives0_Header
#define CadPrimitives0_Header

#include "ExportDef.hpp"
#include "RecordsNav0.h"

const unsigned int colorWhite = 0xffffffff;
const unsigned int colorBlack = 0xff000000;
const unsigned int colorGrey = 0xff7f7f7f;
const unsigned int colorLightGrey = 0xffaaaaaa;

class TPointXY0;
typedef TPointXY0& TPtParam;

typedef TPointXY0* TPointPtr;

class EXPORTPROC TPointXY0 {
// an abstract class for providing access to x,y coordinates
// provides shell functions for x,y coordinates to be shared by different entities.
protected:
  virtual void Decr_refcount () {}
  virtual void Incr_refcount () {}
  virtual short RefCount () {return 0;}
  virtual void set_ShareCode (unsigned long) {}
  friend class TSharedPt;
public:
  TPointXY0 ();
  virtual ~TPointXY0 ();
  void operator = (TPointXY0&);
  virtual void setX (double) = 0;
  virtual void setY (double) = 0;
  virtual double getX () = 0;
  virtual double getY () = 0;
  virtual void SetXY (double xParam, double yParam) {setX(xParam); setY(yParam);}
  virtual void CopyXY (TPointPtr ptParam) {SetXY(ptParam->getX(), ptParam->getY());}
  virtual void CopyXY (TPtParam ptParam) {SetXY(ptParam.getX(), ptParam.getY());}
  virtual bool IsShareable () {return false;}
  virtual bool IsShared () {return false;}
  virtual bool okToDelete () {return true;}
  virtual unsigned long ShareCode () {return 0;}
  };


class EXPORTPROC TPointXY : public TPointXY0 {
// an implementation class for x,y coordinates
// this class is used if no other implementation class is specified in TDH's geometric functions
// this class does not implement coordinate sharing
protected:
  double x, y;
public:
  TPointXY ();
  TPointXY(double, double);
  TPointXY (TPtParam);
  TPointXY (TPointPtr);
  virtual bool okToDelete ();
  void operator = (TPointXY);
  void operator = (TPtParam);
  virtual void setX (double val) {x = val;}
  virtual void setY (double val) {y = val;}
  virtual double getX () {return x;}
  virtual double getY () {return y;}
  };

class EXPORTPROC TPointXY_share : public TPointXY {
// an extension of class TPointXY that implements coordinate sharing
// this class is used for coordinate sharing if no other class is specified
protected:
  unsigned long shareCode;
  unsigned short refcount;
  virtual void Decr_refcount ();
  virtual void Incr_refcount ();
  virtual short RefCount () {return refcount;}
  virtual void set_ShareCode (unsigned long val) {shareCode = val;}
  virtual bool okToDelete ();
public:
  TPointXY_share ();
  TPointXY_share (TPtParam);
  virtual ~TPointXY_share ();
  virtual bool IsShareable () {return true;}
  virtual bool IsShared(); //returns true if the point is shared
  virtual unsigned long ShareCode () {return shareCode;} // a value used for I/O of shared points
  };

class TCadRect0 {
// an abstract class for rectangle functions
// these rectangles are always in line with the coordinate system
public:
  virtual TPointPtr MinPt() = 0; //returns the lowest x,y values
  virtual TPointPtr MaxPt() = 0; //return the highest x,y values
  virtual void SetPoints (TPtParam, TPtParam) = 0; //sets the rectangle by specifying 2 opposing corners
  virtual double Height() = 0; //returns the y dimension
  virtual double Width() = 0; //return the x dimension
  virtual double MaxX () = 0; //return the highest x value
  virtual double MaxY () = 0; //return the highest y value
  virtual double MinX () = 0; //return the lowest x value
  virtual double MinY () = 0; //return the lowest y value
  virtual bool Expand (TPtParam) = 0; //the extents are expanded, if necessary, to include the 1st param
  virtual bool ContainsPt (TPtParam, double = -1) = 0;
    //returns true if the extents plus the tolerance (2nd param) contain the 1st param.
    //a 2nd param value < 0 indicates than an api specified default should be used
  virtual bool ContainsRect (TCadRect0*, double = -1) = 0;
    //returns true if the extents plus the tolerance (2nd param) contains any part of the 1st param.
    //a 2nd param value < 0 indicates than an api specified default should be used
  virtual bool InfinExtents () = 0; //returns true if the extents are infinite, i.e. it will always contain everything else
  virtual void MidPoint (TPointPtr) = 0; //returns the midpoint of the rectangle
  virtual double CalcArea() = 0; //returns the area of the rectaangle
  };

class TVertex0 {
// an abstract class used for for list of TPointXY0 data in multi point lines
// by default, a TVertex0 will use a TPointXY, but may use other derivations of TPointXY0, as explained below
public:
  virtual double getX() = 0; //return the x value for this vertex
  virtual double getY() = 0; //return the y value for this vertex
  virtual void setX (double) = 0; //sett the x value for this vertex
  virtual void setY (double) = 0; //set the y value for this vertex
  virtual void SetXY (double, double) = 0; //set both the x and y values for this vertex
  virtual void SetXY (TPtParam) = 0; // set the x and y values equal thosed contained in the first parameter
  virtual bool setPt (TPointPtr, bool) = 0;
    // sets the TPointPtr used by the vertex, overriding the default TPointXY
    // the 2nd param specifies whether the TPointPtr is owned by the vertex
  virtual TPointPtr getPt () = 0; //returns the TPointPtr used by the vertex
  virtual TPointXY getPtVal() = 0; // return the x,y values in the form of a TPointXY
  virtual TPointPtr *getPtAddr () = 0; //return the address of the TPointPtr used by the vertex
//the following 3 functions to be overridden if sharing is allowed
  virtual void Share (TPointPtr*) {}
    //if the 1st param is a shared TPointXY0, it will not be changed, otherwise, it will be changed to a shared TPointXY0 using the same xy data
    //this vertex will use the shared TPointXY0 resulting from the above statement
  virtual void UnShare () {} //if the TPointXY0 is shared, it will be replaced with a new, unshared TPointXY0
  virtual bool IsShared () {return false;} //return true if the TPointXY0 is shared
  };

class EXPORTPROC TPtCreator {
//this class facilitates the use of custom TPointXY0 data types within the api
//by creating a derived class that overrides these functions
//and passing an instance of the derived class using set_PtCreator in TMultiLine0 and TPtGroup
public:
  virtual ~TPtCreator () {}
  virtual TPointPtr Create_Pt () {return new TPointXY;} //override this function to use a TPointXY0 other than TPointXY for TVertex
  virtual bool OwnPt () {return true;} //override this function to specify whether the point is owned by the TVertex
  };

typedef TRecordsNav0 <TVertex0, TVertex0*> TVertexNav;

extern TVertexNav *VertexNav_default;
TVertexNav EXPORTPROC *Create_VertexNav ();

class EXPORTPROC TMultiLine0 {
//an abstract class for for multi point lines
public:
  virtual ~TMultiLine0 () {}
  virtual TVertexNav *PtNav () = 0; //return the TVertexNav for the multiline
  virtual bool Closed () = 0; //returns true if the multiline closes, i.e. the last pt connects to the first pt
  virtual void set_Closed (bool) = 0; //set true if the multiline closes, i.e. the last pt connects to the first pt
  virtual TVertex0 *Create_Vertex (TPtParam) = 0; //return a new TVertex0 using the xy data in the 1st param
  virtual TVertex0 *Create_Vertex (TPointPtr, bool = true) = 0;
    //return a new TVertex0 using the TPointXY instance in the first param.
    //if the 2nd param is true, the TVertex0 instance takes ownership of the TPointXY instance
  virtual bool AddPt (double, double) = 0; //add a vertex using the x,y data in the params
  virtual bool AddPt (TPtParam) = 0; //add a vertex using the x,y data in the 1st param
  virtual bool AddPt_shared (TPointPtr*) = 0; //add a vertex using the shared TPointXY0 in the 1st param (see TVertex0::Share)
  virtual bool AddVertex (TVertex0*) = 0; //add the vertex specified in the 1st param
  virtual bool AddVertex (TPointPtr, bool=true) = 0; //calls Create_Vertex using the the 2 params and then AddVertex using the new vertex
  virtual void set_PtCreator (TPtCreator*) = 0;
    //allows the TMultiLine0 instance to use a different TPointXY0 than the default of TPointXY
    //by creating a derivative of the class TTdhOGR_PtCreator
  virtual TPointPtr CopyPt (TPointPtr*, bool) = 0;
    //for the current vertex in PtNav(),
    // if the 2nd param is true, copy the 1st param as a shared pt  (see TVertex0::Share)
    // if the 2nd param is false, copy the xy data from the 1st parm
  virtual TMultiLine0 *CopyPts (TMultiLine0* = NULL, unsigned = 0, unsigned = 0, char = 1) = 0;
    // pts are added to the 1st param using data from this PtNav
    // 2nd param is staring at the position within PtNav
    // 3rd param is the number of pts from PtNav
    // 4th param specifies whether the pts are shared, as follows:
      // 0 - pts are never shared, only xy data is used
      // 1 - pt is shared with target if the source pt is shared
      // 2 - all pts are shared
  virtual void CopyPtVals (TMultiLine0*) = 0;
    // for up to the number of pts in this or the number of pts in the 1st param
    // the value of a pt in this copied the pt in the corresponding position of the 1st param
  virtual bool InsertPt (TPtParam, int) = 0; //using the xy data from the 1st param insert a vertex at position specified by 2nd param
  virtual bool InsertPts (TVertexNav*, int) = 0;
    // the verices contained the 1st param are inserted into PtNav starting as position specified by 2nd param
    // 1st param is emptied
  virtual void AddendMultiLine (TVertexNav*) = 0;  //transfer points from param to end of this line, param will lose all points
  virtual void PrependMultiLine (TVertexNav*) = 0; //transfer points from param to beginning of this line, param will lose all points
  virtual void ReversePts () = 0; //reverse the order of PtNav()
  virtual void set_Point (unsigned, TPtParam) = 0; //for the pt in PtNav at position 1st param, set the xy value equal to 2nd param
  virtual TPointPtr get_Point(unsigned) = 0; //return TPointXY0 pointer for the pt at position 1st param of PtNav
  virtual void ResetExtents () = 0; //sets extentsvalid as false, called automatically when the pts change
  virtual bool ExtentsValid () = 0; //if extents have been marked invalid, calculates new extents and return true if the extents exceed near zero in both dimensions
  virtual TCadRect0 *GetExtents () = 0; //calls ExtentsValid() and returns a reference to a TCadRect0 containing the extents for the multiline.
  virtual int CleanVertices (double = -1) = 0; //deletes pt when distance from previous pt is < tolerance. returns number of verticies deleted
  virtual void UnSharePt (unsigned) = 0; //unshare pt at position 1st param in PtNave
  virtual double CalcLength () = 0; //return the length of the  multiline.  if closed, include segment from last pt to first pt
  virtual TPointXY CalcMidPt () = 0;
    //return the midpoint of the multiline, i.e. equal distance along multiline from 1st pt to last pt.
    //if closed, include segment from last pt to first pt
  virtual TVertex0 *NearestVertex (TPtParam) = 0;// return the vertex on the multiline closest to 1st param
  virtual TPointXY NearestPt (TPtParam) = 0; // return the point on the multiline closest to 1st param
  virtual TVertex0 *CurrVertex()  {return PtNav()->GetData();} //return PtNav current vertex
  virtual TPointXY CurrPt() {return CurrVertex()->getPtVal();} //return the xy data used by the current vertex
  virtual TVertex0 *NextPt (TVertex0* = NULL) = 0;
    // return the next vertex after the 1st param
    // if 1st param is NULL, use CurrVertex()
    // if 1st param is last vertex and Closed(), return first vertex
  virtual TVertex0 *PrevPt (TVertex0* = NULL) = 0;
    // return the next vertex before the 1st param
    // if 1st param is NULL, use CurrVertex()
    // if 1st param is last vertex and Closed(), return last vertex
  virtual bool GotoVertex (TPointPtr) = 0; //sets the current vertex to the one using the 1st param, if such a vertex belongs to the multiline
  virtual bool MovePt (TPtParam) = 0; //set the xy values for current vertex to the 1st param
  virtual bool DeleteCurrent () = 0; //delete PtNav current vertex
  };

TMultiLine0 EXPORTPROC *Create_MultiLine (TVertexNav* = NULL, bool = true);
  // create multiline using 1st param as pt navigator and 2nd param owner navigator owner flag
  // if the default parameters are used, a TVertexNav is created


class EXPORTPROC TCadOptions {
// sets options used in geometry calculations
// by default, Tdh geometry is unit agnostic, whatever units the input data refers to are the units output by calculations
// however, if the input data represent longitude/latitude, then the desired output units should be specified using the setDistUnit functions below
public:
  enum DistanceUnits {duMeters, duFeet, duMiles, duKiloMeters, duUnknown, duOther, duLast};
  virtual ~TCadOptions () {}
  virtual void set_LonLat (bool); //sets whether geometry is specified using longitude/latitude (affects calculation of distance and area)
  virtual bool get_LonLat (); //returns whether geometry is specified using longitude/latitude
  virtual void setDistUnitsStr (tdhString); //specify units as either "meters" or "feet"
  virtual void setDistUnits (DistanceUnits); //specify units as one of the DistanceUnit enum
  virtual DistanceUnits getDistUnits (tdhString = ""); //if the 1st param is "", return the current distance units; otherwise, return the unit associated with the string
  virtual tdhString getDistStr (); //return the current distance units as a string
  virtual void set_DistTolerance (double); // sets the distance below which 2 points are considered equal; default is 1e-5 or 1e-8 for long/lat
  virtual double get_DistTolerance (); //return the current distance tolerance
  };

#endif // CadPrimitives0_Header
