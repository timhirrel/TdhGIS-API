/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/

#ifndef RecordsNav0_Header
#define RecordsNav0_Header

// Defines the functionality for a Tdh Records Navigator
// The purpose of navigator is to manage a list of objects of the same type
// Implementations need a method to determine where in the list an object should be placed
   // this can be accomplished with a sortable key value, in which case each key value must be unique
   // in the case of queues and stacks, by default, an object is added to the end or beginning of the list, respectively
// Navigators must have a default object so that some functions are assured of returning a valid object
// Navigators have an object pointer to keep track of navigation
// Navigators may be assigned any number of Notification objects (TNavNotify0), which are called when the object pointer changes, specifying the the type of change
// Navigators may be implemented to optimize
  // key value search (indexed lists)
  // forward and backward navigation (double linked lists)

#include "StringDef.hpp"


template <class objType, class keyType> class EXPORTPROC TRecordsNav0_min {
// an abstract class for the most basic functionality provided by the Tdh Records Navigator
// the use of the object pointer is described in TRecordsNav0
public:
  enum TNavType {ntUnknown, ntTdh};
protected:
  TNavType navType;
public:
  TRecordsNav0_min () {
    navType = ntUnknown;
    }
  virtual ~TRecordsNav0_min () {}
  virtual TNavType NavType () {return navType;}
  virtual bool IsTdhNav () {return NavType() == ntTdh;}

  virtual bool AddRec (objType*, keyType, bool=false) = 0;
    // Add object using the specified key value (2nd param).
    // If the key value matches any existing object the existing object is repolaced only if the 3rd param is true.
    // If the object is successfully added, sets the object pointer to the added object and returns true.
  virtual bool DeleteAll () = 0; //deletes all object (instances) in the navigator
  virtual bool DeleteOne (keyType, bool=false) = 0; //find object with key = 1st param and remove from list, delete object if 2nd param = false
  virtual bool DeleteCount(unsigned pos, unsigned delcount) = 0;
    // deletes the number of objects (2nd parameter) starting at the position of 1st parameter
  virtual objType *GetFirst () = 0; //returns the first object (or NULl) in the navigator
  virtual objType *GetNext (objType*) = 0; //returns the object (or NULL) following the 1st param
  virtual objType *GetLast () = 0; //returns the last object (or NULl) in the navigator
  virtual objType *GetPrev (objType*) = 0; //returns the object (or NULL) preceding the 1st param
  virtual bool GetRec (keyType, objType**) = 0;
    //if found, sets the 2nd param to the object with a key value matching the 1st param and returns true
    //if no matching key found, returns false
  virtual objType *GetItem (unsigned) = 0; //return object pointer in position = 1st param
  virtual unsigned get_Count() = 0; //returns the number of objects in the navigator
  virtual objType *DefaultRec () = 0; //returns a default object
  virtual void set_DefaultRec (objType*) {} //sets the object for the navigator

//functions for queues and stacks
  virtual bool Push (objType*) {return false;}
    //Adds object to a Queue or Stack.
    //If the object is successfully added, sets the object pointer to the added object and returns true.
  virtual objType *Pop () {return DefaultRec();}
    //removes the first object from the navigator and returns it (or NULL)
  virtual bool Insert (objType*, unsigned) {return false;} //adds the 1st param in the 2nd param position
  virtual bool InsertNav (TRecordsNav0_min <objType, keyType> *navParam, unsigned pos) {return false;}
    //inserts the objects contained in the 1st param into this navigator at the 2nd param position
    //the 1st param is emptied
  };


class TNavNotify0;

template <class objType, class keyType> class EXPORTPROC TRecordsNav0 : public TRecordsNav0_min <objType, keyType> {
// an abstract class for expanded functionality
// utilizes an object pointer for navigating the list
private:
protected:
public:
  virtual ~TRecordsNav0 () {}
//  virtual void Destroy () {}
  virtual bool DataExists () = 0; //returns true if the container contains at least one object; otherwise returns false;
  virtual bool GotoFirst() = 0;
    // if the navigator has at least one object, sets the object pointer to the first object and returns true
    // otherwise, returns false
  virtual bool GotoLast() = 0;
    // if the navigator has at least one object, sets the object pointer to the last object and returns true
    // otherwise, returns false
  virtual bool GotoNext() = 0;
    // if the object pointer is not at the last object, sets the object pointer to the next object and returns true
    // otherwise, returns false
  virtual bool GotoPrev() = 0;
    // if the object pointer is not at the last object, sets the object pointer to the next object and returns true
    // otherwise, returns false
  virtual bool GotoRec (keyType) = 0;
    // if such and object exists, sets the object pointer to the object whose key value matches the 1st parameter and returns true
    // otherwise, returns false and the object pointer is not changed
  virtual bool GotoNear (keyType) = 0;
    // sets the object pointer to the object whose key value is closest to but not more than the 1st parameter.
    // returns false only if no objects exist
  virtual bool AtFirst() = 0; // return true if the object pointer is set to the first object
  virtual bool AtLast() = 0; // return true if the object pointer is set to the last object
  virtual unsigned get_RecNum() {return 0;} // returns the position of the current object

  virtual keyType GetKey () = 0; // returns the key value of the current object
  virtual keycomp_result KeyComp (keyType) = 0;//returns the key comparison result for the current object vs. the 1st parameter
  virtual bool SetKey (keyType, bool=false) {return false;}
    // sets the key value of the current object and inserts or moves the object within the container.
    // if there is an existing object with the same key and the 2nd parameter is true, the exiting object is deleted; otherwise the change is rejected
    // returns true if is the key is set
  virtual objType *SetOrGetKey (keyType) = 0;
    // sets the key value of the current object and inserts or moves the object within the container.
    // if there is an existing object with the same key that object becomes the current object
    //return the current object

  virtual objType *GetData () = 0; //returns the object pointer. If no valid object is available, returns DefaultRec().
  virtual bool SetData (objType*) = 0;
    // if the 1st param belongs to the navigator, set the object pointer to 1st param and return true
    // otherwise, return false

  virtual unsigned GetPosition (objType*) = 0; //return the position of the object pointer
  virtual bool GotoPosition (unsigned) = 0;  //set the object pointer

  virtual bool NewData_nokey (objType*) {return false;} // sets current current object to 1st parameter. must be followed by a call to SetKey to add to container
  virtual tdhString KeyToStr () {return "";} //returns a string representation of the key
  virtual bool KeyError () = 0; //indicates whether n key conflict resulted from the previous SetKey operation
  virtual bool KeyUsed (keyType) = 0; // return true if the key is used in the container
  virtual tdhString GetNextAvailableKey (tdhString = "") {return "";}
    // for use with string keys
    // returns the lowest value unused key with the specified prefix (1st param)

  virtual void AddNotify (TNavNotify0*) {}; //adds a notification to the container
  virtual void RemoveNotify (TNavNotify0*) {}; //deletes a notification from the container

  virtual void SetIDs() {} //set the id for all objects accessed by the navigator
//  virtual TRecordsNav0 <objType, keyType> *CopyNav (TRecordsNav0 <objType, keyType>* = NULL, bool = true) {return NULL;}
  virtual void set_Hide (bool) {} //controls whether records marked for hiding are hidden in navigators that allow hiding
  virtual bool Hide () {return false;}
  };




#endif // RecordsNav0_Header
