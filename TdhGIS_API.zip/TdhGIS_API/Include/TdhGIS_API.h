/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/

#ifndef TDHGIS_API_H_INCLUDED
#define TDHGIS_API_H_INCLUDED

#include "TdhSpatial_Intf.h"
#include "TdhGisGroups.h"

// The TTdhGIS_API0 class provides a relatively low overhead method
// for storing and retrieving data used in the TdhGIS API, as compared to the TTdhOGR_API0 class.
// This class reads and writes data to a TdhGIS_Data.sqlite database, as done in the TdhGIS app
// The only supporting libraries required are Sqlite, TdhCommon and TdhSpatial

class EXPORTPROC TTdhGIS_API0 {
public:
  enum TFileTypes {ftUnknown = -1, ftTdhCad, ftTdhGIS, ftTdhGISnet, ftTdhNet, ftOther, ftOSM, ftAPI};

  virtual ~TTdhGIS_API0 () {}

//the following functions are used to import and export data to and from the TdhGIS_API
  virtual TPtGroup_gis *PtGroup () = 0; //used to access results from an import and provide data for an export
  virtual TPolyGroup_gis *PolyGroup () = 0; //used to access results from an import and provide data for an export
  virtual TMultiLineGroup_gis *LineGroup () = 0; //used to access results from an import and provide data for an export
  virtual void set_PtGroup (TPtGroup_gis*) = 0; //allows use of a PtGroup other than the default
  virtual void set_PolyGroup (TPolyGroup_gis*) = 0; //allows use of a PolyGroup other than the default
  virtual void set_LineGroup (TMultiLineGroup_gis*) = 0; //allows use of a MultiLineGroup other than the default

  virtual bool ReadGroup (tdhString, GisDataTypes, tdhString, bool) = 0;
    //used to import data into the TdhGIS_API from a TdhGIS database, returns true if no faults detected
    //1st parqm specifies the dir containing a TdhGIS database file (TdhGIS_Data.sqlite)
    //2nd param specifies the data type to be imported
    //3rd param specifies the name of the group within the database to be imported
    //4th param specifies whether the group to contain the imported data is emptied before the import process begins
  virtual bool WriteGroup(tdhString, GisDataTypes) = 0;
    //used to export data from the TdhGIS_API to a TdhGIS database, returns true if no faults detected
    //1st parqm specifies the dir containing the Tdh database file
    //2nd param specifies the data type to be exported
    //3rd param specifies the name for the new group (must be unique within the database)
  virtual bool DeleteGroup(tdhString, GisDataTypes, tdhString) = 0;
    //used to delete a group from a TdhGIS database, returns true if no faults detected
    //1st parqm specifies the dir containing a TdhGIS database file (TdhGIS_Data.sqlite)
    //2nd param specifies the data type to be deleted
    //3rd param specifies the name of the group within the database to be deleted
  };

TTdhGIS_API0 EXPORTPROC *Create_TdhGisApi (); //creates and returns an implementation of TTdhGIS_API0

#endif // TDHGIS_API_H_INCLUDED
