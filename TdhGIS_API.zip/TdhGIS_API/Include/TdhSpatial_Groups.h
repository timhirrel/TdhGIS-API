/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/

#ifndef TdhSpatialGroups_Header
#define TdhSpatialGroups_Header

#include "TdhSpatial_Intf.h"

class EXPORTPROC TPtGroup {
// a named collection of TPtData0 data
protected:
  tdhString id;
  tdhString description, allocatedTo;
  tdhString crsStr;
  TPtNav *ptNav;
  TPtCreator *ptCreator;
public:
  TPtGroup ();
  virtual ~TPtGroup ();
  virtual void Reset (); //deletes all pt data in the group and sets allocateto to blank
  virtual TPtNav *PtNav () {return ptNav;}
  virtual tdhString get_id () {return id;}
  virtual void set_id (tdhString);
  virtual TPtData0 *AddPt (tdhString, TPtParam);
    //create a TPtData0 instance and add it to the group
    //return the TPtData0 instance if successful, otherwise return NULL
    //1st param = the TPtData0 id, fails if the id is not unique within the group
    //2nd param = the TPtData0 x,y values
  virtual void CopyOptions (TPtGroup*); //copies options from this to 1st param
  virtual TPtGroup *Copy (TPtGroup* = NULL, bool=true); //copies pt data and options from this to 1st param
  virtual bool DeleteAll (); //deletes all pt data in the group
  virtual void set_PtCreator (TPtCreator*);
    //allows the TPtGroup instance to use a different TPointXY0 than the default of TPointXY
    //by creating a derivative of the class TPtCreator
  virtual TPtCreator *PtCreator() {return ptCreator;}

  virtual tdhString Description () {return description;} //return a user provided description of the group
  virtual void set_Description (tdhString val) {description = val;} //set a user provided description of the group
  virtual tdhString AllocatedTo() {return allocatedTo;} //return the polygon group to which the pts have allocated
  virtual void set_AllocatedTo (tdhString val) {allocatedTo = val;} //set the polygon group to which the pts have allocated
  virtual void set_CRSstr (tdhString strParam) {crsStr = strParam;}
  virtual tdhString get_CRSdescription () {return crsStr;}
  virtual void add_CRSstr (tdhString);
  virtual tdhString get_CRSstr ();
//  virtual TPtGroup *Copy (TPtGroup* = NULL, bool=true);
  };

//typedef TPtGroup TPtGroup_gis;

class EXPORTPROC TPolyGroup {
// a named collection of polygons
protected:
  tdhString id; //, crsStr, crsInfo;
  tdhString Create_Op;
  GisDataTypes datatype;
  TPolyNav *polyNav;
  bool navOwner;
public:
  tdhString parent1, parent2;
  tdhString description;
  tdhString crsStr;
  TPolyGroup (GisDataTypes typeParam, TPolyNav* = NULL, bool = false);
    //1st pararm specifies data type
    //2nd param specifies the polyNav; if NULL, a polyNav is created
    //3rd param specifies whether the the PolyGroup owns the 2nd param, if provided
  virtual ~TPolyGroup();
  virtual TPolyNav *PolyNav() {return polyNav;}
  virtual tdhString GroupID() {return id;}
  virtual void set_id (tdhString);
  virtual void Set_DataType (GisDataTypes typeParam) {datatype = typeParam;}
  virtual GisDataTypes DataType () {return datatype;}
  virtual TGisPolygon0 *Create_Polygon (TVertexNav_cw* = NULL, bool ownParam = true);
    //returns Create_GisPolygon from TdhSpatial_Intf.h, by default
    //override this function to return TGisPolygon0 instances with a custom PtCreator

  virtual TPolyGroup *CopyGroup (TPolyGroup* = NULL);
  virtual void CopyOptions (TPolyGroup*); //copy options from this to 1st param
  virtual void Reset (); //set id to blank and delete all polys
  virtual void ReCalc (); //recalculate area and perimeter for all polygons in the group

  virtual void set_CRSstr (tdhString strParam) {crsStr = strParam;}
  virtual tdhString get_CRSdescription () {return crsStr;}
  virtual void add_CRSstr (tdhString); //add to CRS description
  virtual tdhString get_CRSstr (); //return CRS description
  virtual tdhString get_CreateOp () {return Create_Op;}
  virtual void set_CreateOp (tdhString); //set create op string and, if currently blank, create description
  virtual void set_Parent (int, tdhString); //set the 1st param parent string
  virtual tdhString Parent (int); //return the 1st param parent string
  virtual void AddPoly (TGisPolygon0*, tdhString);
  };

typedef TPolyGroup TMultiLineGroup;


#endif // TdhSpatialGroups_Header
