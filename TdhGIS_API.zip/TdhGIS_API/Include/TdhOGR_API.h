/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/

#ifndef TDHOGR_API_H_INCLUDED
#define TDHOGR_API_H_INCLUDED

/*
This header provides access to the functionality in TdhOGR
knowledge of the use of TdhOGR will be helpful when using this API
This API can be used in 2 broad scenarios:
  1. importing and exporting data into and from the TdhGIS_API
  2. translating vector data from one file type to another
In addition to the file types accessed through OGR, this api can use Tdh data files and OSM data files (source only)
This api facilitates coordinate transformation during the translation process

The libraries required for this API include:
  TdhCommmon
  TdhCairo
  TdhPath
  TdhSpatial
  Sqlite3
  gdal
  proj
*/

#include "TdhSpatial_Intf.h"
#include "TdhGisGroups.h"

const int optLimitOGR = 10;

class EXPORTPROC TTdhOGR_API0 {
//this class provides access the functionality in TdhOGR
public:
  enum TFileTypes {ftUnknown = -1, ftTdhCad, ftTdhGIS, ftTdhGISnet, ftTdhNet, ftOther, ftOSM, ftAPI};

  virtual ~TTdhOGR_API0 () {}

//the following functions are used to import and export data to and from the TdhGIS_API
  virtual TPtGroup_gis *PtGroup () = 0; //used to access results from an import and provide data for an export
  virtual TPolyGroup_gis *PolyGroup () = 0; //used to access results from an import and provide data for an export
  virtual void set_PtGroup (TPtGroup_gis*) = 0; //allows use of a PtGroup other than the default
  virtual void set_PolyGroup (TPolyGroup_gis*) = 0; //allows use of a PolyGroup other than the default
  virtual bool ReadTdhData (TFileTypes, tdhString, GisDataTypes, bool) = 0;
    //used to import data into the TdhGIS_API, returns true if no faults detected
    //1st param specifies the TFileType for the imported data
    //2nd parqm specifies the path for the data file. if the filetype is of Tdh, this should specify the dir containing the Tdh database file
    //3rd param specifies the data type to be imported
    //4th param specifies whether the group to contain the imported data is emptied before the import process begins
  virtual bool WriteTdhData (TFileTypes, tdhString, GisDataTypes) = 0;
    //used to export data from the TdhGIS_API, returns true if no faults detected
    //1st param specifies the TFileType for the exported data
    //2nd parqm specifies the path for the data file. if the filetype is of Tdh, this should specify the dir containing the Tdh database file
    //3rd param specifies the data type to be exported

//the following functions specify information needed for specific TFiletypes
  virtual void SetDriverStr (tdhString) = 0;
    //if file type is ftOther, this must be called before ReadTdhData, WirteTdhData,
    //set_SourceFile or set_TargetFile, specifying the OGR driver string
  virtual void add_OptionStr (tdhString, bool) = 0;
    //if file type is ftOther, this is used to specify any OGR options.
    //If the 2nd param is true, any previous options are erased
  virtual void add_TagRequired (tdhString, bool) = 0;
    //used with OSM sources to specify require <tag, value> combinations.
    //If the 2nd param is true, any previous options are erased
  virtual void add_TagExclude (tdhString, bool) = 0;
    //used with OSM sources to specify excluded <tag, value> combinations.
    // If the 2nd param is true, any previous options are erased
  virtual void set_OsmSource (tdhString) = 0; //set osm source as "Ways" or "Relations"
  virtual void set_IdField (tdhString) = 0; //used with TdhGIS targets to specify the ID field name. the default is "ID"
  virtual void set_ValueField (tdhString) = 0; //used with TdhGIS targets to specify the Value field name. the default is "Value"

//the following functions specify information needed for coordinate transformation
  virtual void set_TransformFlag (bool) = 0; //sets coordinate transformation on or off, default is off
  virtual void set_SourceCRS (tdhString) = 0; //set the coordinate reference system for the source, to be used for coordinate transformation
  virtual void set_targetCRS (tdhString) = 0; //set the coordinate reference system for the target, to be used for coordinate transformation

// the following functions are used to convert data from a source FileType to a target FileType
// ftAPI should not be used as filetype in these functions
// immediately before filetype ftOther is used for source or target, SetDriverStr() and, optionally, add_OptionStr, must be called
// ftOSM should be used only for a source
  virtual void set_DataType (GisDataTypes) = 0; //specifies the data type to be converted
  virtual bool set_SourceFile (TFileTypes, tdhString) = 0;
    // returns false if problem detected
    // 1st param specifies the filetype for the source
    // 2nd parm specifies the path for the source data file. if the filetype is of TdH, this specifies the directory containing the Tdh databae file
    // if the source file contains OSM data, add_TagRequired() and, optionally, add_TagExclude, must be called before Translate()
  virtual bool set_TargetFile (TFileTypes, tdhString) = 0;
    // returns false if problem detected
    // 1st param specifies the filetype for the targer
    // 2nd parm specifies the path for the target data file. if the filetype is of TdH, this specifies the directory containing the Tdh databae file
  virtual bool Translate() = 0; //called to proceed with the data conversion process. return true if no faults detected
  };

TTdhOGR_API0 EXPORTPROC *Create_TdhOgrApi (); //returns an implementation of TTdhOGR_API0

#endif // TDHOGR_API_H_INCLUDED
