/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/

#ifndef TDHGISGROUPS_H_INCLUDED
#define TDHGISGROUPS_H_INCLUDED

#include "TdhSpatial_Groups.h"

class EXPORTPROC TPtGroup_gis : public TPtGroup {
// extends TPtGroup to include data needed for display and I/O
protected:
  unsigned int color;
  int groupCode;
public:
  TPtGroup_gis () {
    color = colorBlack;
    groupCode = -1;
    }
  virtual unsigned Color () {return color;} //return the user defined color for the group
  virtual void set_Color (unsigned val) {color = val;} //set    the user defined color for the group
  virtual void CopyOptions_gis (TPtGroup_gis*); //copies options from this to 1st param
  virtual void set_GroupCode (int val) {groupCode = val;}
  virtual int GroupCode () {return groupCode;}
  };

class EXPORTPROC TPolyGroup_gis : public TPolyGroup {
// extends TPolyGroup to include data needed for display and I/O
protected:
  unsigned int color;
  bool fill;
  double labelsize;
  tdhString keyVal_save;
  TGisPolygon0 *highPoly;
  double highArea;
  int keyVal_count, groupCode;
//  virtual void FinishMultiPart (tdhString);
  virtual void AddMultiPoly (TGisPolygon0*, tdhString);
public:
  TPolyGroup_gis (GisDataTypes typeParam, TPolyNav* = NULL, bool = false);
  virtual ~TPolyGroup_gis();
  virtual void StartAdds_parts(); //used to start adding polygons that may have multiple parts
  virtual void FinishAdds_parts(); //used to finish adding polygons that may have multiple parts
  virtual void AddPoly_parts (TGisPolygon0*, tdhString); //used to add polygons that may have multiple parts
  virtual double LabelSize () {return labelsize;}
  virtual void set_LabelSize (double val) {labelsize = val;}
  virtual unsigned int Color () {return color;}
  virtual void set_Color (unsigned int val) {color = val;}
  virtual bool Fill () {return fill;}
  virtual void set_Fill (bool val) {fill = val;}
  virtual void set_GroupCode (int val) {groupCode = val;}
  virtual int GroupCode () {return groupCode;}
  };

typedef TPolyGroup_gis TMultiLineGroup_gis;



#endif // TDHGISGROUPS_H_INCLUDED
