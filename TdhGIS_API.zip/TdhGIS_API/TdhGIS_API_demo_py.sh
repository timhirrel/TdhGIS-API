# script file for running TdhGIS_API_demo_py within linux
#!/bin/bash

python3 -m python.TdhGIS_API_demo_py.TdhGIS_API_demo_Main
