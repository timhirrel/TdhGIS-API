// This file is not normally needed by the TdhGIS_API user
// It is provided in the event there are errors needing correction in the TdhGIS_API_py library
// This file contains code to bind the TdhGIS API to python

#include "TdhGIS_API.h"

TTdhGIS_API0 *TdhGIS_API_py (void *apiParam) {
  return (TTdhGIS_API0*)apiParam;
  }

TPtGroup_gis *PtGroup_py (void *groupParam) {
  return (TPtGroup_gis*)groupParam;
  }

TPolyGroup_gis *PolyGroup_py (void *groupParam) {
  return (TPolyGroup_gis*)groupParam;
  }

EXTERNC {

EXPORTPROC TPtNav *PtGroup_py_PtNav (void *groupParam) {
  return PtGroup_py(groupParam)->PtNav();
  }

EXPORTPROC tdhString_py PtGroup_py_get_id (void *groupParam) {
  return PtGroup_py(groupParam)->get_id().c_str();
  }

EXPORTPROC void PtGroup_py_set_id (void *groupParam, tdhString_py idParam) {
  PtGroup_py(groupParam)->set_id(idParam);
  }

EXPORTPROC TPtData0 *PtGroup_py_AddPt (void *groupParam, tdhString_py idParam, double xParam, double yParam) {
    //create a TPtData0 instance and add it to the group
    //return the TPtData0 instance if successful, otherwise return NULL
    //1st param = the TPtData0 id, fails if the id is not unique within the group
    //2nd param = the TPtData0 x,y values
  TPointXY tempPt (xParam, yParam);
  return PtGroup_py(groupParam)->AddPt(idParam, tempPt);
  }

EXPORTPROC void PtGroup_py_CopyOptions (void *groupParam, void *groupParam2) {
  //copies options from this to 1st param
  PtGroup_py(groupParam)->CopyOptions(PtGroup_py(groupParam2));
  }

EXPORTPROC TPtGroup *PtGroup_py_Copy (void *groupParam, TPtGroup *groupParam2 = NULL, bool resetFlag = true) {
  //copies pt data and options from this to 1st param
  return PtGroup_py(groupParam)->Copy(PtGroup_py(groupParam2), resetFlag);
  }

EXPORTPROC bool PtGroup_py_DeleteAll (void *groupParam) {
  //deletes all pt data in the group
  return PtGroup_py(groupParam)->DeleteAll();
  }

//void PtGroup_py_set_PtCreator (TPtCreator*);
    //allows the TPtGroup instance to use a different TPointXY0 than the default of TPointXY
    //by creating a derivative of the class TPtCreator

//virtual TPtCreator *PtCreator() {return ptCreator;}

EXPORTPROC tdhString_py PtGroup_py_Description (void *groupParam) {
  return PtGroup_py(groupParam)->Description().c_str();
  } //return a user provided description of the group

EXPORTPROC void PtGroup_py_set_Description (void *groupParam, tdhString_py val) {
  PtGroup_py(groupParam)->set_Description(val);
  } //set a user provided description of the group

EXPORTPROC tdhString_py PtGroup_py_AllocatedTo (void *groupParam) {
  return PtGroup_py(groupParam)->AllocatedTo().c_str();
  } //return the polygon group to which the pts have allocated

EXPORTPROC void PtGroup_py_set_AllocatedTo (void *groupParam, tdhString_py val) {
  PtGroup_py(groupParam)->set_AllocatedTo(val);
  } //set the polygon group to which the pts have allocated

EXPORTPROC void PtGroup_py_set_CRSstr (void *groupParam, tdhString_py strParam) {
  PtGroup_py(groupParam)->set_CRSstr(strParam);
  }

/*
EXPORTPROC tdhString_py PtGroup_py_get_CRSdescription (void *groupParam) {
  return PtGroup_py(groupParam)->get_CRSdescription().c_str();
  }

EXPORTPROC void PtGroup_py_set_CRSdescription (void *groupParam, tdhString strParam) {
  PtGroup_py(groupParam)->set_CRSdescription(strParam);
  }
*/

EXPORTPROC tdhString_py PtGroup_py_get_CRSstr (void *groupParam) {
  return PtGroup_py(groupParam)->get_CRSstr().c_str();
  }

EXPORTPROC unsigned PtGroup_py_Color (void *groupParam) {
  return PtGroup_py(groupParam)->Color();
  } //return the user defined color for the group

EXPORTPROC void PtGroup_py_set_Color (void *groupParam, unsigned val) {
  PtGroup_py(groupParam)->set_Color(val);
  } //set    the user defined color for the group

EXPORTPROC void PtGroup_py_CopyOptions_gis (void *groupParam, void *groupParam2) {
  PtGroup_py(groupParam)->CopyOptions_gis(PtGroup_py(groupParam2));
  }; //copies options from this to 1st param



//typedef TPtGroup TPtGroup_gis;

EXPORTPROC void *PolyGroup_py_PolyNav (void *groupParam) {
  return PolyGroup_py(groupParam)->PolyNav();
  }

EXPORTPROC tdhString_py PolyGroup_py_GroupID (void *groupParam) {
  return PolyGroup_py(groupParam)->GroupID().c_str();
  }

EXPORTPROC void PolyGroup_py_set_id (void *groupParam, tdhString_py idParam) {
  PolyGroup_py(groupParam)->set_id(idParam);
  }

EXPORTPROC void PolyGroup_py_Set_DataType (void *groupParam, int typeParam) {
  PolyGroup_py(groupParam)->Set_DataType((GisDataTypes)typeParam);
  }

EXPORTPROC int PolyGroup_py_DataType (void *groupParam) {
  return PolyGroup_py(groupParam)->DataType();
  }

EXPORTPROC void *PolyGroup_py_Create_Polygon (void *groupParam, void *navParam = NULL, bool ownParam = true) {
  return PolyGroup_py(groupParam)->Create_Polygon((TVertexNav_cw*)navParam, ownParam);
  }
    //returns Create_GisPolygon from TdhSpatial_Intf.h, by default
    //override this function to return TGisPolygon0 instances with a custom PtCreator

EXPORTPROC void *PolyGroup_py_CopyGroup (void *groupParam, void *groupParam2 = NULL) {
  return PolyGroup_py(groupParam)->CopyGroup((TPolyGroup*)groupParam2);
  }

EXPORTPROC void PolyGroup_py_CopyOptions (void *groupParam, void *groupParam2) {
  PolyGroup_py(groupParam)->CopyOptions((TPolyGroup*)groupParam2);
  } //copy options from this to 1st param

EXPORTPROC void PolyGroup_py_Reset (void *groupParam) {
  PolyGroup_py(groupParam)->Reset();
  } //set id to blank and delete all polys

EXPORTPROC void PolyGroup_py_ReCalc (void *groupParam) {
  PolyGroup_py(groupParam)->ReCalc();
  } //recalculate area and perimeter for all polygons in the group

EXPORTPROC void PolyGroup_py_set_CRSstr (void *groupParam, tdhString_py strParam) {
  PolyGroup_py(groupParam)->set_CRSstr(strParam);
  }

/*
EXPORTPROC tdhString_py PolyGroup_py_get_CRSdescription (void *groupParam) {
  return PolyGroup_py(groupParam)->get_CRSdescription().c_str();
  }

EXPORTPROC void PolyGroup_py_add_CRSstr (void *groupParam, tdhString_py strParam) {
   PolyGroup_py(groupParam)->add_CRSstr(strParam);
   } //add to CRS description
*/

EXPORTPROC tdhString_py PolyGroup_py_get_CRSstr (void *groupParam) {
  return PolyGroup_py(groupParam)->get_CRSstr().c_str();
  } //return CRS description

EXPORTPROC tdhString_py PolyGroup_py_get_CreateOp (void *groupParam) {
  return PolyGroup_py(groupParam)->get_CreateOp().c_str();
  }

EXPORTPROC void PolyGroup_py_set_CreateOp (void *groupParam, tdhString_py strParam) {
  PolyGroup_py(groupParam)->set_CreateOp(strParam);
  } //set create op string and, if currently blank, create description

EXPORTPROC void PolyGroup_py_set_Parent (void *groupParam, int pos, tdhString_py strParam) {
  PolyGroup_py(groupParam)->set_Parent(pos, strParam);
  } //set the 1st param parent string

EXPORTPROC tdhString_py PolyGroup_py_Parent (void *groupParam, int pos) {
  return PolyGroup_py(groupParam)->Parent(pos).c_str();
  } //return the 1st param parent string

EXPORTPROC void PolyGroup_py_AddPoly (void *groupParam, void *polyParam, tdhString_py idParam) {
  PolyGroup_py(groupParam)->AddPoly((TGisPolygon0*)polyParam, idParam);
  }

EXPORTPROC void PolyGroup_py_StartAdds_parts (void *groupParam) {
  PolyGroup_py(groupParam)->StartAdds_parts();
  } //used to start adding polygons that may have multiple parts

EXPORTPROC void PolyGroup_py_FinishAdds_parts (void *groupParam) {
  PolyGroup_py(groupParam)->FinishAdds_parts();
  } //used to finish adding polygons that may have multiple parts

EXPORTPROC void PolyGroup_py_AddPoly_parts (void *groupParam, void *polyParam, tdhString_py idParam) {
  PolyGroup_py(groupParam)->AddPoly_parts  ((TGisPolygon0*)polyParam, idParam);
  } //used to add polygons that may have multiple parts

EXPORTPROC double PolyGroup_py_LabelSize (void *groupParam) {
  return PolyGroup_py(groupParam)->LabelSize();
  }

EXPORTPROC void PolyGroup_py_set_LabelSize (void *groupParam, double val) {
  PolyGroup_py(groupParam)->set_LabelSize(val);
  }

EXPORTPROC unsigned int PolyGroup_py_Color (void *groupParam) {
  return PolyGroup_py(groupParam)->Color();
  }

EXPORTPROC void PolyGroup_py_set_Color (void *groupParam, unsigned int val) {
  PolyGroup_py(groupParam)->set_Color(val);
  }

EXPORTPROC bool PolyGroup_py_Fill (void *groupParam) {
  return PolyGroup_py(groupParam)->Fill();
  }

EXPORTPROC void PolyGroup_py_set_Fill (void *groupParam, bool val) {
  PolyGroup_py(groupParam)->set_Fill(val);
  }



//the following functions are used to import and export data to and from the TdhGIS_API
TPtGroup_gis EXPORTPROC *TdhGIS_API_py_PtGroup (void *apiParam) {
  //used to access results from an import and provide data for an export
  return TdhGIS_API_py(apiParam)->PtGroup ();
  }

TPolyGroup_gis EXPORTPROC *TdhGIS_API_py_PolyGroup (void *apiParam) {
  //used to access results from an import and provide data for an export
  return TdhGIS_API_py(apiParam)->PolyGroup();
  }

TMultiLineGroup_gis EXPORTPROC *TdhGIS_API_py_LineGroup (void *apiParam) {
  //used to access results from an import and provide data for an export
  return TdhGIS_API_py(apiParam)->LineGroup();
  }

void EXPORTPROC TdhGIS_API_py_set_PtGroup (void *apiParam, void *groupParam) {
  //allows use of a PtGroup other than the default
  TdhGIS_API_py(apiParam)->set_PtGroup((TPtGroup_gis*)groupParam);
  }

void EXPORTPROC TdhGIS_API_py_set_PolyGroup (void *apiParam, void *groupParam) {
  //allows use of a PolyGroup other than the default
  TdhGIS_API_py(apiParam)->set_PolyGroup((TPolyGroup_gis*)groupParam);
  }

void EXPORTPROC TdhGIS_API_py_set_LineGroup (void *apiParam, void *groupParam) {
  //allows use of a MultiLineGroup other than the default
  TdhGIS_API_py(apiParam)->set_LineGroup((TMultiLineGroup_gis*)groupParam);
  }

bool EXPORTPROC TdhGIS_API_py_ReadGroup (void *apiParam, tdhString_py dirParam, int typeParam, tdhString_py nameParam, bool resetFlag) {
  //used to import data into the TdhGIS_API from a TdhGIS database, returns true if no faults detected
  //1st parqm specifies the dir containing a TdhGIS database file (TdhGIS_Data.sqlite)
  //2nd param specifies the data type to be imported
  //3rd param specifies the name of the group within the database to be imported
  //4th param specifies whether the group to contain the imported data is emptied before the import process begins
  return TdhGIS_API_py(apiParam)->ReadGroup(dirParam, (GisDataTypes)typeParam, nameParam, resetFlag);
  }

bool EXPORTPROC TdhGIS_API_py_WriteGroup (void *apiParam, tdhString_py dirParam, int typeParam) {
  //used to export data from the TdhGIS_API to a TdhGIS database, returns true if no faults detected
  //1st parqm specifies the dir containing the Tdh database file
  //2nd param specifies the data type to be exported
  //3rd param specifies the name for the new group (must be unique within the database)
  return TdhGIS_API_py(apiParam)->WriteGroup (dirParam, (GisDataTypes)typeParam);
  }

bool EXPORTPROC TdhGIS_API_py_DeleteGroup (void *apiParam,  tdhString_py dirParam, int typeParam, tdhString_py nameParam) {
  //used to delete a group from a TdhGIS database, returns true if no faults detected
  //1st parqm specifies the dir containing a TdhGIS database file (TdhGIS_Data.sqlite)
  //2nd param specifies the data type to be deleted
  //3rd param specifies the name of the group within the database to be deleted
  return TdhGIS_API_py(apiParam)->DeleteGroup(dirParam, (GisDataTypes)typeParam, nameParam);
  }


TTdhGIS_API0 EXPORTPROC *Create_TdhGisAPI_py () {
  //creates and returns an implementation of TTdhGIS_API0
  return Create_TdhGisApi();
  }

TPolyGroup_gis EXPORTPROC *Create_PolyGroup_py (TPolyNav *navParam, bool ownParam) {
  //used to access results from an import and provide data for an export
  return Create_PolyGroup_gis (navParam, ownParam);
  }

TMultiLineGroup_gis EXPORTPROC *Create_LineGroup_py (TPolyNav *navParam, bool ownParam) {
  //used to access results from an import and provide data for an export
  return Create_LineGroup_gis (navParam, ownParam);
  }

TPtGroup EXPORTPROC *Create_PtGroup_py (TPtNav *navParam, bool ownParam) {
  //allows use of a PtGroup other than the default
  return Create_PtGroup_gis (navParam, ownParam);
  }

}
