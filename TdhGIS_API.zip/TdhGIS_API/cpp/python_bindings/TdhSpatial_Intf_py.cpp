// This file is not normally needed by the TdhGIS_API user
// It is provided in the event there are errors needing correction in the TdhSpatial_py library
// This file contains code to bind the TdhGIS API to python

#include "TdhSpatial_Intf.h"
#include "StringDef.hpp"
#include "PolygonFuncs.h"

/*
class EXPORTPROC TPtData_py : public TPtData1 {
  protected:
    void *pyPtr;
  public:
    TPtData_py (void *pyParam) : TPtData1 () {
      pyPtr = pyParam;
      }
    virtual void *PyPtr () {return pyPtr;}
  };
*/

EXTERNC {

TPtNav *PtNav_py (void *ptNav) {
  return (TPtNav*)ptNav;
  }

TPtData0 EXPORTPROC *Create_PtData_py () {
// creates and returns an instance of TPtData0
  return Create_PtData();
//  return new TPtData_py (pyParam);
  }

//void *PtData_py_PyPtr (void *objParam) {
//  return ((TPtData_py*)objParam)->PyPtr();  }

TPtData0 *PtData_py (void *objParam) {
  return (TPtData0*)objParam;
  }


EXPORTPROC tdhString_py PtData_py_ID (void *objParam) {
  return TdhString_toPy(PtData_py(objParam)->ID());
  }

EXPORTPROC void PtData_py_set_ID (void *objParam, tdhString_py strParam) {
//if instance belongs to a TPtGroup, ID can only be changed by using TPtGroup::PtNav()->SetKey()
  std::string tdhStr = strParam;
  PtData_py(objParam)->set_ID(tdhStr);
  }

EXPORTPROC TPointPtr PtData_py_Pt (void *objParam) {
  return PtData_py(objParam)->Pt();
  }

//EXPORTPROC TPointXY PtData_py_PtVal (void *objParam) {
//  return PtData_py(objParam)->
//  }

EXPORTPROC double PtData_py_Value (void *objParam) {
//return a user define value
  return PtData_py(objParam)->Value();
  }

EXPORTPROC void PtData_py_set_Value (void *objParam, double valParam) {
//set a user defined value
  PtData_py(objParam)->set_Value(valParam);
  }

EXPORTPROC void PtData_py_setX (void *objParam, double xParam) {
  PtData_py(objParam)->setX(xParam);
  }

EXPORTPROC void PtData_py_setY (void *objParam, double yParam) {
  PtData_py(objParam)->setY (yParam);
  }

EXPORTPROC double PtData_py_getX (void *objParam) {
  return PtData_py(objParam)->getX();
  }

EXPORTPROC double PtData_py_getY (void *objParam) {
  return PtData_py(objParam)->getY();
  }

EXPORTPROC void PtData_py_SetXY (void *objParam, double xParam, double yParam) {
  PtData_py(objParam)->SetXY(xParam, yParam);
  }

EXPORTPROC TPtData0 *PtData_py_Copy (void *objParam, TPtData0 *ptParam = NULL) {
//copies this to the 1st param, creates and returns a new TPtData0 if 1st param is NULL
  return PtData_py(objParam)->Copy(ptParam);
  }

EXPORTPROC void PtData_py_incr_Value (void *objParam, double valParam) {
//increment this value
  PtData_py(objParam)->incr_Value(valParam);
  }

EXPORTPROC tdhString_py PtData_py_AllocatedTo (void *objParam) {
//return the id of the polygon to which this has been allocated
  return TdhString_toPy(PtData_py(objParam)->AllocatedTo());
  }

EXPORTPROC void PtData_py_set_AllocatedTo (void *objParam, tdhString_py strParam) {
//save the id of the polygon to which this has been allocated
  return PtData_py(objParam)->set_AllocatedTo(strParam);
  }

EXPORTPROC bool PtData_py_Allocated (void *objParam) {
//return true if this has been allocated to a polygon
  return PtData_py(objParam)->Allocated();
  }

EXPORTPROC void PtData_py_set_Allocated (void *objParam, bool boolParam) {
//set to true if this has been allocated to a polygon
  PtData_py(objParam)->set_Allocated(boolParam);
  }

EXPORTPROC double PtData_py_Weight (void *objParam) {
//returns the weight of this for functionality using weighting
  return PtData_py(objParam)->Weight();
  }

EXPORTPROC void PtData_py_set_Weight (void *objParam, double valParam) {
//sets the weight of this for functionality using weighting
  PtData_py(objParam)->set_Weight(valParam);
  }

EXPORTPROC void PtData_py_incr_Weight (void *objParam, double valParam) {
//increments the weight of this for functionality using weighting
  PtData_py(objParam)->incr_Weight(valParam);
  }


TPtNav EXPORTPROC *Create_PtNav_py () {
// creates abd returns an instance of TPtNav
  return Create_PtNav();
  }


TPtFuncs0 EXPORTPROC *Create_PtFuncs_py () {
  return Create_PtFuncs();
  }

TPtFuncs0 *PtFuncs_py (void *ptFuncs) {
  return (TPtFuncs0*)ptFuncs;
  }

EXPORTPROC TPtData0* PtFuncs_py_FindNearPt (void *ptFuncs, void *ptData, void *ptNav) {
//return the TPtData in the 2nd param nearest to the 1st param
  return PtFuncs_py(ptFuncs)->FindNearPt (PtData_py(ptData), PtNav_py(ptNav));
  }

EXPORTPROC void PtFuncs_py_ReducePts(void *ptFuncs, void *ptNav, double valParam) {
// eliminates pts in 1st param that are within 2nd param distance of an adjacent pt, averaging the values
  PtFuncs_py(ptFuncs)->ReducePts(PtNav_py(ptNav), valParam);
  }

EXPORTPROC void PtFuncs_py_CombinePts (void *ptFuncs, void *ptData1, void *ptData2, void *ptNav) {
    // computes the average of 2 points (1st and 2nd params), both belonging to the 3rd param
    // modifies the 1st point to equal the average and deletes the 2nd point
    // weights the averaging such that a combined pt has a higher weighting when combined again.
  PtFuncs_py(ptFuncs)->CombinePts (PtData_py(ptData1), PtData_py(ptData2), PtNav_py(ptNav));
  }


TGisPolygon0 *GisPolygon_py (void *polyParam) {
  return (TGisPolygon0*)polyParam;
  }

TMultiLine0* MultiLine_fromPoly(void* polyParam) {
    return (TMultiLine0*)GisPolygon_py(polyParam);
  }

typedef TMultiLine0* (*TMultiLineProc) (void*);

EXPORTPROC TMultiLineProc get_TMultiLine_fromPoly_Proc() {
    return MultiLine_fromPoly;
}


TVertexNav_cw *VertexNav_py (void *navParam) {
  return (TVertexNav_cw*)navParam;
  }

EXPORTPROC GisDataTypes GisPolygon_py_DataType (void *polyParam) {
// returns either dtGisPolygon or dtGisMultiLine
  return GisPolygon_py(polyParam)->DataType();
  }

//EXPORTPROC TGisPolygon *GisPolygon_py_GisPolygon (void *polyParam) {
//used internally by the TdhGIS API
//  return GisPolygon_py(polyParam)->
//  }

EXPORTPROC tdhString_py GisPolygon_py_PolyID (void *polyParam) {
// returns the polygon ID, unique within a polygon group
    return TdhString_toPy(GisPolygon_py(polyParam)->PolyID());
  }

EXPORTPROC void GisPolygon_py_set_PolyID (void *polyParam, tdhString_py strParam) {
//set the polygon ID
    GisPolygon_py(polyParam)->set_PolyID(strParam);
//    GisPolygon_py(polyParam)->set_PolyID(stringify(strParam));
  }

EXPORTPROC TVertexNav_cw *GisPolygon_py_PtNavCW (void *polyParam) {
//returns the vertex navigator for the polygon
  return GisPolygon_py(polyParam)->PtNavCW();
  }

EXPORTPROC TVertexNav* GisPolygon_py_PtNav(void* polyParam) {
    //returns the vertex navigator for the polygon
    return GisPolygon_py(polyParam)->PtNav();
}

EXPORTPROC double GisPolygon_py_CalcLength(void* lineParam) {
    return GisPolygon_py(lineParam)->CalcLength();
}

EXPORTPROC TPolyNav *GisPolygon_py_ExcludePolys (void *polyParam) {
//use this to navigate the exclusion polygons of a given polygon
  return GisPolygon_py(polyParam)->ExcludePolys();
  }

EXPORTPROC void GisPolygon_py_Reset (void *polyParam, bool exclFlag = true) {
//delete all pts, set all data to default values; if 1st param is true, exclusion polys will be deleted
  GisPolygon_py(polyParam)->Reset(exclFlag);
  }

EXPORTPROC void GisPolygon_py_DeletePts (void *polyParam) {
//delete all pts for polygon
  GisPolygon_py(polyParam)->DeletePts();
  }

EXPORTPROC TCadRect0 *GisPolygon_py_GetExtents (void *polyParam) {
//returns the extents of the polygon
  return GisPolygon_py(polyParam)->GetExtents();
  }

EXPORTPROC void GisPolygon_py_SetCW (void *polyParam, bool val) {
//determine whether the pts are in clockwise order and set cw variable
  GisPolygon_py(polyParam)->SetCW(val);
  }

EXPORTPROC void GisPolygon_py_ResetCW (void *polyParam) {
//reset flag that tells whether clockwise variable has been set
  GisPolygon_py(polyParam)->ResetCW();
  }

EXPORTPROC bool GisPolygon_py_CWSet (void *polyParam) {
//return flag  that tells whether clockwise variable has been set
  return GisPolygon_py(polyParam)->CWSet();
  }

EXPORTPROC bool GisPolygon_py_IsCW (void *polyParam) {
//return variable that tells whether pts are clockwise
  return GisPolygon_py(polyParam)->IsCW();
  }

EXPORTPROC void GisPolygon_py_AddExcludePoly (void *polyParam, void *exclParam, tdhString_py idParam) {
//add an exclusion polygon, i.e. a hole
  GisPolygon_py(polyParam)->AddExcludePoly(GisPolygon_py(exclParam), idParam);
  }

EXPORTPROC TGisPolygon0 *GisPolygon_py_Copy (void *polyParam, void *targetParam) {
//copy this polygon and return result. copy to 1st param if not NULL; otherwise,copy to new polygon
  return GisPolygon_py(polyParam)->Copy(GisPolygon_py(targetParam));
  }

EXPORTPROC void GisPolygon_py_CopyParams (void *polyParam, void *targetParam) {
//copy polygon variable to 1st param
  GisPolygon_py(polyParam)->CopyParams(GisPolygon_py(targetParam));
  }

EXPORTPROC bool GisPolygon_py_CalcCentroid (void *polyParam, void *ptParam) {
//return the centroid for the polygon
  TPointXY tempPt;
  bool result = GisPolygon_py(polyParam)->CalcCentroid(&tempPt);
  tempPt.CopyXY((TPointPtr)ptParam);
  return result;
  }

EXPORTPROC void GisPolygon_py_set_Centroid(void *polyParam, double xParam, double yParam) {
//set the centroid, will be resets if pts change
  TPointXY tempPt (xParam, yParam);
  GisPolygon_py(polyParam)->set_Centroid(tempPt);
  }

EXPORTPROC double GisPolygon_py_CalcArea (void *polyParam) {
//returns the area of the polygon. substracts the area of any exclusion polygon
  return GisPolygon_py(polyParam)->CalcArea();
  }

EXPORTPROC void GisPolygon_py_set_Area (void *polyParam, double valParam) {
//set the area, resets if pts change
  GisPolygon_py(polyParam)->set_Area(valParam);
  }

EXPORTPROC double GisPolygon_py_CalcPerimeter (void *polyParam) {
//return the perimeter of the polygon, including the perimeter of any exclusion polygon
  return GisPolygon_py(polyParam)->CalcPerimeter();
  }

EXPORTPROC void GisPolygon_py_set_Perimeter(void *polyParam, double valParam) {
//set the perimeter, resets if pts change
  GisPolygon_py(polyParam)->set_Perimeter(valParam);
  }

EXPORTPROC void GisPolygon_py_ReCalc (void *polyParam) {
// recalculates area and perimeter of polygon
  GisPolygon_py(polyParam)->ReCalc();
  }

EXPORTPROC bool GisPolygon_py_ContainsPt (void *polyParam, double xParam, double yParam) {
  TPointXY tempPt(xParam, yParam);
  return GisPolygon_py(polyParam)->ContainsPt(tempPt);
  }

EXPORTPROC bool GisPolygon_py_ContainsPoly (void *polyParam, void *navParam, char inclFlag) {
  return GisPolygon_py(polyParam)->ContainsPoly((TVertexNav*)navParam, inclFlag);
  }

EXPORTPROC double GisPolygon_py_Value (void *polyParam) {
  return GisPolygon_py(polyParam)->Value();
  }

EXPORTPROC void GisPolygon_py_set_Value (void *polyParam, double valParam) {
  GisPolygon_py(polyParam)->set_Value(valParam);
  }

EXPORTPROC void GisPolygon_py_incr_Value (void *polyParam, double valParam) {
  GisPolygon_py(polyParam)->incr_Value(valParam);
  }

EXPORTPROC void GisPolygon_py_set_Parent (void *polyParam, tdhString_py strParam, int posParam) {
  GisPolygon_py(polyParam)->set_Parent(strParam, posParam);
  }

EXPORTPROC tdhString_py GisPolygon_py_Parent (void *polyParam, int posParam) {
  return TdhString_toPy(GisPolygon_py(polyParam)->Parent(posParam));
  }

EXPORTPROC void GisPolygon_py_set_AllocateFactor (void *polyParam, double valParam, int posParam) {
  GisPolygon_py(polyParam)->set_AllocateFactor(valParam, posParam);
  }

EXPORTPROC double GisPolygon_py_AllocateFactor (void *polyParam, int posParam) {
  return GisPolygon_py(polyParam)->AllocateFactor(posParam);
  }

EXPORTPROC void GisPolygon_py_set_Color (void *polyParam, unsigned int colorParam) {
  GisPolygon_py(polyParam)->set_Color(colorParam);
  }

EXPORTPROC unsigned int GisPolygon_py_Color (void *polyParam) {
  return GisPolygon_py(polyParam)->Color();
  }

EXPORTPROC void GisPolygon_py_set_ColorFlag (void *polyParam, bool flagParam) {
  GisPolygon_py(polyParam)->set_ColorFlag(flagParam);
  }

EXPORTPROC bool GisPolygon_py_ColorFlag (void *polyParam) {
  return GisPolygon_py(polyParam)->ColorFlag();
  }

EXPORTPROC void GisPolygon_py_set_Width (void *polyParam, float widthParam) {
  GisPolygon_py(polyParam)->set_Width(widthParam);
  }

EXPORTPROC float GisPolygon_py_Width (void *polyParam) {
  return GisPolygon_py(polyParam)->Width();
  }

EXPORTPROC void GisPolygon_py_set_Major (void *polyParam,  char flagParam) {
  GisPolygon_py(polyParam)->set_Major(flagParam);
  }

EXPORTPROC char GisPolygon_py_Major (void *polyParam) {
  return GisPolygon_py(polyParam)->Major();
  }

TPolyNav *PolyNav_py (void *navParam) {
  return (TPolyNav*)navParam;
  }

TGisPolygon0 EXPORTPROC *Create_GisPolygon_py (void* navParam = NULL, bool ownParam = true) {
  return Create_GisPolygon (VertexNav_py(navParam), ownParam);
  }

TGisPolygon0 EXPORTPROC *Create_GisMultiLine_py (void *navParam = NULL, bool ownParam = true) {
  return Create_GisPolygon (VertexNav_py(navParam), ownParam);
  }

TPolyNav EXPORTPROC *Create_PolyNav_py () {
  return Create_PolyNav();
  } //create and return a TPolyNav

TPolyNav EXPORTPROC *Create_ExcludPolyNav_py (void *navParam) {
  return Create_ExcludPolyNav(PolyNav_py(navParam));
  } //use this to navigate the exclusion polygons of the current polygon for the navigator passed as 1st param

void EXPORTPROC Copy_Polygons_py (void *source, void *target) {
  Copy_Polygons(PolyNav_py(source), PolyNav_py(target));
  } // copy polygons in 1st param to 2nd param


TThiessen0 *Thiessen_py (void *thiesParam) {
  return (TThiessen0*)thiesParam;
  }

EXPORTPROC TPolyNav *Thiessen_py_PolyNav (void *thiesParam) {
  return Thiessen_py(thiesParam)->PolyNav();
  }
    // a navigator containing the generated polygons

EXPORTPROC void Thiessen_py_AddPtData (void *thiesParam, void *ptParam) {
  Thiessen_py(thiesParam)->AddPtData(PtData_py(ptParam));
  }
    //add a single pt to the pt list

EXPORTPROC void Thiessen_py_AddPtList (void *thiesParam, void *navParam, bool resetFlag) {
  Thiessen_py(thiesParam)->AddPtList(PtNav_py(navParam), resetFlag);
  }
    // add an entire pt list.
    // if 2nd param is true, reset pt list, otherwise add to existing pts

EXPORTPROC void Thiessen_py_MakePolygons (void *thiesParam, void *polyParam, bool resetFlag) {
  Thiessen_py(thiesParam)->MakePolygons(GisPolygon_py(polyParam), resetFlag);
  }
    // make polygons from the current pt list, using the 1st parameter as a boundary.
    // if 2nd param is true, add polygons to existing polygons, otherwise, start with reset of polygon list.

EXPORTPROC TGisPolygon0 *Thiessen_py_AutoBoundary(void *thiesParam, void *polyParam) {
  return Thiessen_py(thiesParam)->AutoBoundary(GisPolygon_py(polyParam));
  }
    //create and return the minimum polygon containing all the pts in the pt list.
    // if the 1st param is not NULL, that pointer will contain the result..

EXPORTPROC void Thiessen_py_Reset (void *thiesParam) {
  return Thiessen_py(thiesParam)->Reset();
  }
    //empty the pt list.

EXPORTPROC bool Thiessen_py_HasData (void *thiesParam) {
  return Thiessen_py(thiesParam)->HasData();
  }
    // returns true is the pt list has at least one pt, otherwise returns false.


TThiessen0 EXPORTPROC *Create_Thiessen_py () {
  return Create_Thiessen();
  }

void EXPORTPROC Delete_Thiessen_py (TThiessen0 *ptrParam) {
  delete ptrParam;
  }


typedef TGisPolygon0 TGisContour0; // currently, there is no difference between TGisPolygon0 and TGisContour0, but that may change in the future
typedef TRecordsNav0 <TGisContour0, tdhString>  TContourNav;


TContour0 *Contour_py (void *contourParam) {
  return (TContour0*)contourParam;
  }

EXPORTPROC void Contour_py_MakeContours (void *contourParam, void *navParam, double intvParam, void *boundary, unsigned colorCode, bool resetFlag) {
  Contour_py(contourParam)->MakeContours(PtNav_py(navParam), intvParam, GisPolygon_py(boundary), colorCode, resetFlag);
  }

EXPORTPROC TPolyNav *Contour_py_ContourNav (void *contourParam) {
  return Contour_py(contourParam)->ContourNav();
  }

EXPORTPROC void Contour_py_set_MajorStep (void *contourParam, int val) {
  Contour_py(contourParam)->set_MajorStep(val);
  }

EXPORTPROC void Contour_py_set_MinSet (void *contourParam, bool val) {
  Contour_py(contourParam)->set_MinSet(val);
  }

EXPORTPROC void Contour_py_set_MaxSet (void *contourParam, bool val) {
  Contour_py(contourParam)->set_MaxSet(val);
  }

EXPORTPROC void Contour_py_set_Minimum (void *contourParam, double val) {
  Contour_py(contourParam)->set_Minimum(val);
  }

EXPORTPROC void Contour_py_set_Maximum (void *contourParam, double val) {
  Contour_py(contourParam)->set_Maximum(val);
  }

TContour0 EXPORTPROC *Create_Contour_py () {
  return Create_Contour();
  }


TContourPoly0 *ContourPoly_py (void *contourParam) {
  return (TContourPoly0*)contourParam;
  }

EXPORTPROC void ContourPoly_py_MakeContourPolygons (void *contourParam, void *navParam, void *boundary, double val, bool valFlag) {
  ContourPoly_py(contourParam)->MakeContourPolygons(PtNav_py(navParam), GisPolygon_py(boundary), val, valFlag);
  }

EXPORTPROC TPolyNav *ContourPoly_py_PolyNav (void *contourParam) {
  return ContourPoly_py(contourParam)->PolyNav();
  }

TContourPoly0 EXPORTPROC *Create_ContourPoly_py () {
  return Create_ContourPoly();
  }


TPolyIntersect0 *PolyIntersect_py (void *intersectParam) {
  return (TPolyIntersect0*)intersectParam;
  }

EXPORTPROC TPolyNav *PolyIntersect_py_PolyNav (void *intersectParam) {
  return PolyIntersect_py(intersectParam)->PolyNav();
  }

EXPORTPROC bool PolyIntersect_py_Execute (void *intersectParam, void *poly1, void *poly2, bool resetFlag) {
  return PolyIntersect_py(intersectParam)->Execute(GisPolygon_py(poly1), GisPolygon_py(poly2), resetFlag);
  }

EXPORTPROC void PolyIntersect_py_ExecutePolyListToPoly (void *intersectParam, void *navParam, void *polyParam, bool resetFlag) {
  PolyIntersect_py(intersectParam)->ExecutePolyListToPoly(PolyNav_py(navParam), GisPolygon_py(polyParam), resetFlag);
  }

EXPORTPROC void PolyIntersect_py_ExecutePolyListToPolyList (void *intersectParam, void *nav1, void *nav2, bool resetFlag) {
  PolyIntersect_py(intersectParam)->ExecutePolyListToPolyList (PolyNav_py(nav1), PolyNav_py(nav2), resetFlag);
  }

EXPORTPROC void PolyIntersect_py_AllocatePtsToPolyList (void *intersectParam, void *ptNav, void *polyNav, bool resetFlag) {
  PolyIntersect_py(intersectParam)->AllocatePtsToPolyList(PtNav_py(ptNav), PolyNav_py(polyNav), resetFlag);
  }

EXPORTPROC void PolyIntersect_py_AllocatePolyListToPolyList (void *intersectParam, void *nav1, void *nav2, bool resetFlag) {
  PolyIntersect_py(intersectParam)->AllocatePolyListToPolyList (PolyNav_py(nav1), PolyNav_py(nav2), resetFlag);
  }


TPolyIntersect0 EXPORTPROC *Create_PolyIntersect_py() {
  return Create_PolyIntersect();
  }
  // returns an implementation of TPolyIntersect0 that performs polygon intersection operations

TPolyIntersect0 EXPORTPROC *Create_PolyMerge_py() {
  return Create_PolyMerge();
  }
  // returns an implementation of TPolyIntersect0 that performs polygon merge operations

TPolyIntersect0 EXPORTPROC *Create_PolySubtract_py() {
  return Create_PolySplit();
  }
  // returns an implementation of TPolyIntersect0 that performs polygon subtraction operations (the 2nd param is subtracted from the 1st param)

TPolyIntersect0 EXPORTPROC *Create_PolyTrim_py () {
  return Create_PolyTrim();
  }
  // returns an implementation of TPolyIntersect0 that trims a multiline (1st param) to fit within a polygon (2nd param)

TPolyIntersect0 EXPORTPROC *Create_PolySplit_py () {
  return Create_PolySplit();
  }
  // returns an implementation of TPolyIntersect0 that splits a polygon (1st param) along a multiline (2nd param)


TDissolve0 *Dissolve_py (void *dissolveParam) {
  return (TDissolve0*)dissolveParam;
  }

EXPORTPROC TPolyNav *Dissolve_py_NewPolys (void *dissolveParam)  {
  return Dissolve_py(dissolveParam)->NewPolys();
  }

EXPORTPROC bool Dissolve_py_Dissolve (void *dissolveParam, void *navParam) {
  return Dissolve_py(dissolveParam)->Dissolve(PolyNav_py(navParam));
  }

TDissolve0 EXPORTPROC *Create_Dissolve_py () {
  return Create_Dissolve();
  }


}
