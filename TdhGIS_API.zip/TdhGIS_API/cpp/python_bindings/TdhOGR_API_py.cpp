// This file is not normally needed by the TdhGIS_API user
// It is provided in the event there are errors needing correction in the TdhOGR_API_py library
// This file contains code to bind the TdhGIS API to python

#include "TdhOGR_API.h"

TTdhOGR_API0 *TdhOGR_API_py (void *apiParam) {
  return (TTdhOGR_API0*)apiParam;
  }

EXTERNC {

EXPORTPROC TPtGroup_gis *TdhOGR_API_py_PtGroup (void *apiParam) {
  //used to access results from an import and provide data for an export
  return TdhOGR_API_py(apiParam)->PtGroup();
  }

EXPORTPROC TPolyGroup_gis *TdhOGR_API_py_PolyGroup (void *apiParam) {
  //used to access results from an import and provide data for an export
  return TdhOGR_API_py(apiParam)->PolyGroup();
  }

EXPORTPROC TMultiLineGroup_gis *TdhOGR_API_py_LineGroup (void *apiParam) {
  //used to access results from an import and provide data for an export
  return TdhOGR_API_py(apiParam)->PolyGroup();
  }

EXPORTPROC void TdhOGR_API_py_set_PtGroup (void *apiParam, void *groupParam) {
  //allows use of a PtGroup other than the default
  TdhOGR_API_py(apiParam)->set_PtGroup((TPtGroup_gis*)groupParam);
  }

EXPORTPROC void TdhOGR_API_py_set_PolyGroup (void *apiParam, void *groupParam) {
  //allows use of a PolyGroup other than the default
  TdhOGR_API_py(apiParam)->set_PolyGroup((TPolyGroup_gis*)groupParam);
  }

EXPORTPROC void TdhOGR_API_py_set_LineGroup (void *apiParam, void *groupParam) {
  //allows use of a PolyGroup other than the default
  TdhOGR_API_py(apiParam)->set_LineGroup((TMultiLineGroup_gis*)groupParam);
  }

EXPORTPROC bool TdhOGR_API_py_ReadTdhData (void *apiParam, int fileType, tdhString_py pathStr, int dataType, bool reset) {
  //used to import data into the TdhGIS_API, returns true if no faults detected
  //1st param specifies the TFileType for the imported data
  //2nd parqm specifies the path for the data file. if the filetype is of Tdh, this should specify the dir containing the Tdh database file
  //3rd param specifies the data type to be imported
  //4th param specifies whether the group to contain the imported data is emptied before the import process begins
  return TdhOGR_API_py(apiParam)->ReadTdhData ((TTdhOGR_API0::TFileTypes)fileType, pathStr, (GisDataTypes)dataType, reset);
  }


EXPORTPROC bool TdhOGR_API_py_WriteTdhData (void *apiParam, int fileType, tdhString_py pathStr, int dataType) {
  //used to export data from the TdhGIS_API, returns true if no faults detected
  //1st param specifies the TFileType for the exported data
  //2nd parqm specifies the path for the data file. if the filetype is of Tdh, this should specify the dir containing the Tdh database file
  //3rd param specifies the data type to be exported
  return TdhOGR_API_py(apiParam)->WriteTdhData ((TTdhOGR_API0::TFileTypes)fileType, pathStr, (GisDataTypes)dataType);
  }

//the following functions specify information needed for specific TFiletypes
EXPORTPROC void TdhOGR_API_py_SetDriverStr (void *apiParam, tdhString_py driverStr) {
  //if file type is ftOther, this must be called before ReadTdhData, WirteTdhData,
  //set_SourceFile or set_TargetFile, specifying the OGR driver string
  TdhOGR_API_py(apiParam)->SetDriverStr(driverStr);
  }

EXPORTPROC void TdhOGR_API_py_add_OptionStr (void *apiParam, tdhString_py optStr, bool reset ) {
  //if file type is ftOther, this is used to specify any OGR options.
  //If the 2nd param is true, any previous options are erased
  TdhOGR_API_py(apiParam)->add_OptionStr (optStr, reset);
  }

EXPORTPROC void TdhOGR_API_py_add_TagRequired (void *apiParam, tdhString_py tagStr, bool reset) {
  //used with OSM sources to specify require <tag, value> combinations.
  //If the 2nd param is true, any previous options are erased
  TdhOGR_API_py(apiParam)->add_TagRequired (tagStr, reset);
  }

EXPORTPROC void TdhOGR_API_py_add_TagExclude (void *apiParam, tdhString_py tagStr, bool reset) {
  //used with OSM sources to specify excluded <tag, value> combinations.
  // If the 2nd param is true, any previous options are erased
  TdhOGR_API_py(apiParam)->add_TagExclude (tagStr, reset);
  }

EXPORTPROC void TdhOGR_API_py_set_OsmSource (void *apiParam, tdhString_py sourceStr) {
  //set osm source as "Ways" or "Relations"
  TdhOGR_API_py(apiParam)->set_OsmSource (sourceStr);
  }

EXPORTPROC void TdhOGR_API_py_set_IdField (void *apiParam, tdhString_py fieldStr) {
  //used with TdhGIS targets to specify the ID field name. the default is "ID"
  TdhOGR_API_py(apiParam)->set_IdField (fieldStr);
  }

EXPORTPROC void TdhOGR_API_py_set_ValueField (void *apiParam, tdhString_py fieldStr) {
  //used with TdhGIS targets to specify the Value field name. the default is "Value"
  TdhOGR_API_py(apiParam)->set_ValueField (fieldStr);
  }

//the following functions specify information needed for coordinate transformation
EXPORTPROC void TdhOGR_API_py_set_TransformFlag (void *apiParam, bool transformFlag) {
  //sets coordinate transformation on or off, default is off
  TdhOGR_API_py(apiParam)->set_TransformFlag (transformFlag);
  }

EXPORTPROC void TdhOGR_API_py_set_SourceCRS (void *apiParam, tdhString_py crsStr, bool order) {
  //set the coordinate reference system for the source, to be used for coordinate transformation
  TdhOGR_API_py(apiParam)->set_SourceCRS (crsStr, order);
  }

EXPORTPROC void TdhOGR_API_py_set_TargetCRS (void *apiParam, tdhString_py crsStr, bool order) {
  //set the coordinate reference system for the target, to be used for coordinate transformation
  TdhOGR_API_py(apiParam)->set_TargetCRS (crsStr, order);
  }

// the following functions are used to convert data from a source FileType to a target FileType
// ftAPI should not be used as filetype in these functions
// immediately before filetype ftOther is used for source or target, SetDriverStr() and, optionally, add_OptionStr, must be called
// ftOSM should be used only for a source
EXPORTPROC void TdhOGR_API_py_set_DataType (void *apiParam, int dataType) {
  //specifies the data type to be converted
  TdhOGR_API_py(apiParam)->set_DataType((GisDataTypes)dataType);
  }

EXPORTPROC bool TdhOGR_API_py_set_SourceFile (void *apiParam, int fileType, tdhString_py pathStr) {
  // returns false if problem detected
  // 1st param specifies the filetype for the source
  // 2nd parm specifies the path for the source data file. if the filetype is of TdH, this specifies the directory containing the Tdh databae file
  // if the source file contains OSM data, add_TagRequired() and, optionally, add_TagExclude, must be called before Translate()
  return TdhOGR_API_py(apiParam)->set_SourceFile ((TTdhOGR_API0::TFileTypes)fileType, pathStr);
  }

EXPORTPROC bool TdhOGR_API_py_set_TargetFile (void *apiParam, int fileType, tdhString_py pathStr) {
  // returns false if problem detected
  // 1st param specifies the filetype for the targer
  // 2nd parm specifies the path for the target data file. if the filetype is of TdH, this specifies the directory containing the Tdh databae file
  return TdhOGR_API_py(apiParam)->set_TargetFile ((TTdhOGR_API0::TFileTypes)fileType, pathStr);
  }

EXPORTPROC bool TdhOGR_API_py_Translate (void *apiParam) {
  //called to proceed with the data conversion process. return true if no faults detected
  return TdhOGR_API_py(apiParam)->Translate();
  }

TTdhOGR_API0 EXPORTPROC *Create_TdhOgrApi_py () {
  //returns an implementation of TTdhOGR_API0
  return Create_TdhOgrApi();
  }

}

