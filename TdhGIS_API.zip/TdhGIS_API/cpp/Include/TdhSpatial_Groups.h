/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/

#ifndef TdhSpatialGroups_Header
#define TdhSpatialGroups_Header

#include "TdhSpatial_Intf.h"

class EXPORTPROC TPtGroup {
// this class provides a named collection of TPtData0 data
// and associated attributes
protected:
  tdhString id;
  tdhString description, allocatedTo;
  tdhString crsStr; //, crsDeescription;
  TPtNav *ptNav;
  bool navOwner;
  TPtCreator *ptCreator;
public:
  TPtGroup (TPtNav* = NULL, bool = false);
  virtual ~TPtGroup ();
  virtual void Reset (); //deletes all pt data in the group and sets allocateto to blank
  virtual TPtNav *PtNav () {return ptNav;} //returns a navigator for the TPtDate0 data within the this group
  virtual tdhString get_id () {return id;} // returns the id for the group
  virtual void set_id (tdhString); // sets the id for the group
  virtual TPtData0 *AddPt (tdhString, TPtParam);
    //create a TPtData0 instance and add it to the group
    //return the TPtData0 instance if successful, otherwise return NULL
    //1st param = the TPtData0 id, fails if the id is not unique within the group
    //2nd param = the TPtData0 x,y values
  virtual void CopyOptions (TPtGroup*); //copies options from this to 1st param
  virtual TPtGroup *Copy (TPtGroup* = NULL, bool=true); //copies pt data and options from this to 1st param
  virtual bool DeleteAll (); //deletes all pt data in the group
  virtual void set_PtCreator (TPtCreator*);
    //allows the TPtGroup instance to use a different TPointXY0 than the default of TPointXY
    //by creating a derivative of the class TPtCreator
  virtual TPtCreator *PtCreator() {return ptCreator;}

  virtual tdhString Description () {return description;} //return a user provided description of the group
  virtual void set_Description (tdhString val) {description = val;} //set a user provided description of the group
  virtual tdhString AllocatedTo() {return allocatedTo;} //return the polygon group to which the pts have allocated
  virtual void set_AllocatedTo (tdhString val) {allocatedTo = val;} //set the polygon group to which the pts have allocated
  virtual void set_CRSstr (tdhString strParam) {crsStr = strParam;} //sets a string defining the coordinate reference system associated with the group
  virtual tdhString get_CRSstr () {return crsStr;} //returns a string defining the coordinate reference system associated with the group
//  virtual tdhString get_CRSdescription () {return crsDeescription;}
//  virtual void set_CRSdescription (tdhString strParam) {crsDescription = strParam;}
//  virtual TPtGroup *Copy (TPtGroup* = NULL, bool=true);
  };

EXPORTPROC TPtGroup *Create_PtGroup (TPtNav* = NULL, bool = false);

class EXPORTPROC TPolyGroup {
// a named collection of polygons
protected:
  tdhString id; //, crsStr, crsInfo;
  tdhString Create_Op;
  GisDataTypes datatype;
  TPolyNav *polyNav;
  bool navOwner;
public:
  tdhString parent1, parent2;
  tdhString description;
  tdhString crsStr;
  TPolyGroup (GisDataTypes typeParam, TPolyNav* = NULL, bool = false);
    //1st pararm specifies data type
    //2nd param specifies the polyNav; if NULL, a polyNav is created
    //3rd param specifies whether the the PolyGroup owns the 2nd param, if provided
  virtual ~TPolyGroup();
  virtual TPolyNav *PolyNav() {return polyNav;} // returns a navigator for the TGisPolygon data within the this group
  virtual tdhString GroupID() {return id;} //returns the id for the group
  virtual void set_id (tdhString); //sets the id for the group
  virtual void Set_DataType (GisDataTypes typeParam) {datatype = typeParam;} // sets the data type for the group (dtGidPolygon or dtGisMultiLine)
  virtual GisDataTypes DataType () {return datatype;} // returns the data type for the group (dtGidPolygon or dtGisMultiLine)
  virtual TGisPolygon0 *Create_Polygon (TVertexNav_cw* = NULL, bool ownParam = true); // creates and returns a TGisPolygon compatible with the implementation of this class

  virtual TPolyGroup *CopyGroup (TPolyGroup* = NULL); // returns a copy of this instance. if 1st param is not NULL,it is used and the target, otherwise a new TPolyGroup is created
  virtual void CopyOptions (TPolyGroup*); //copy options from this to 1st param
  virtual void Reset (); //set id to blank and delete all polys
  virtual void ReCalc (); //recalculate area and perimeter for all polygons in the group

  virtual void set_CRSstr (tdhString strParam) {crsStr = strParam;} //sets a string defining the coordinated reference system used for the group
  virtual tdhString get_CRSstr() {return crsStr;} //returns a string defining the coordinated reference system used for the group
  virtual tdhString get_CreateOp () {return Create_Op;}
  virtual void set_CreateOp (tdhString); //set create op string and, if currently blank, create description
  virtual void set_Parent (int, tdhString); // sets a string naming a parent (1 or 2 depending on 1st param) used to create the group,
  virtual tdhString Parent (int); // returns a string naming a parent (1 or 2 depending on 1st param) used to create the group,
  virtual void AddPoly (TGisPolygon0*, tdhString); // adds a polygon (1st param) to the group, using the specified id (2nd param)

  };

EXPORTPROC TPolyGroup *Create_PolyGroup (TPolyNav* = NULL, bool = false);

typedef TPolyGroup TMultiLineGroup;

EXPORTPROC TMultiLineGroup *Create_LineGroup (TPolyNav* = NULL, bool = false);

#endif // TdhSpatialGroups_Header
