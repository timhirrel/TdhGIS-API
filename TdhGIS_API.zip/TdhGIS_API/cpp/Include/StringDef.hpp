// defines the tdhString data type
// defines a class for messaging within code
// defines stringify functions for string output for various data types

#ifndef STRINGDEF_HPP_INCLUDED
#define STRINGDEF_HPP_INCLUDED

#include "ExportDef.hpp"

#include <string.h>
#include <vector>
#include <iostream>

#ifndef tdh_stdString
  #define tdh_stdString
#endif // tdh_stdString


#ifdef tdh_VCL
  #include <Classes.hpp>
#else
  #ifdef tdh_stdString
    #define tdhString std::string
    #define TStringVector std::vector <tdhString>
    #define TStringIt TStringVector::iterator
  #endif
#endif

#ifndef tdhString
  #define tdhString char*
  #endif


//typedef char (*messageproc) (std::string);

class EXPORTPROC TMessenger0 {
// as abstract class for providing messaging with Tdh code
public:
  virtual char Message (std::string, std::string = "") = 0;
  virtual char Message_confirm (std::string, std::string = "") = 0;
  };

class EXPORTPROC TMessenger_none : public TMessenger0 {
// a TMessenger0 class that does nothing
public:
  virtual char Message (std::string, std::string = "") {return 0;}
  virtual char Message_confirm (std::string, std::string = "") {return 0;}
  };

extern TMessenger_none EXPORT_common NoMessenger;
TMessenger0 EXPORTPROC *NoMessProc ();

class TMessenger_console : public TMessenger0 {
// a TMessenger0 class that provides console output
public:
  virtual char Message (std::string lineStr, std::string = "") {
    std::cout << lineStr << std::endl;
    return 0;
    }
  virtual char Message_confirm (std::string, std::string = "") {return 0;}
  };
extern TMessenger_console EXPORT_common messenger_console;

EXTERNC TMessenger0 EXPORTPROC *Messenger_Console ();

EXPORTPROC inline TMessenger0 *MessProc_py() {
  return Messenger_Console();
  }

EXPORTPROC inline TMessenger0 *Messenger_py (void *messParam) {
  return (TMessenger0*)messParam;
  }


#ifdef tdh_Windows
  #define newlineStr "\n"
  #define stricmp _stricmp
#else
  #define newlineStr "\r\n"
  #define stricmp strcasecmp
#endif

#include <iostream>
#include <sstream>
#include <typeinfo>
#include <stdexcept>
#include <math.h>

#include "ExportDef.hpp"

// these stringify functions provide string output for various data type


#ifdef _GLIBCXX_STDEXCEPT
class BadConversion : public std::runtime_error {
 public:
   BadConversion(std::string const& s)
     : std::runtime_error(s)
     { }
 };
#else
class BadConversion  {};
#endif

template<typename T>
inline std::string EXPORTPROC stringify2(T const& x)  {
   std::ostringstream o;
   if (!(o << x))
     return "";
//     throw BadConversion(std::string("stringify(")
//                         + typeid(x).name() + ")");
   return o.str();
 }

template<typename T>
inline std::string EXPORTPROC stringify(T const& x) {
  return stringify2(x); }

inline std::string EXPORTPROC stringify(unsigned const char* x) {
  if (x == NULL)
    return "";
  return stringify2(x);
  }

inline std::string EXPORTPROC stringify(std::string x) {
  return x;  }

inline std::string EXPORTPROC stringify(char x) {
  return stringify((int)x);  }

inline std::string EXPORTPROC stringify(unsigned char x) {
  return stringify((unsigned)x);  }

inline std::string EXPORTPROC stringify(double x, double minParam = 1e-20) {
  if (fabs(x) < minParam)
    return "0";
  return stringify2(x);
  }

template<typename T>
 inline void convert(std::string const& s, T& x,
                     bool failIfLeftoverChars = true)
 {
   std::istringstream i(s);
   char c;
   if (!(i >> x) || (failIfLeftoverChars && i.get(c)))
     return;
//     throw BadConversion(s);
 }

 template<typename T>
 inline T convertTo(std::string const& s,
                    bool failIfLeftoverChars = true)
 {
   T x;
   convert(s, x, failIfLeftoverChars);
   return x;
 }


typedef const char* tdhString_py;

const int StrBufSize = 65;
inline tdhString_py TdhString_toPy (tdhString strParam) {
  static char strBuf [StrBufSize+1];
  strncpy (strBuf, strParam.c_str(), StrBufSize);
  return strBuf;
  }

#endif // STRINGDEF_HPP_INCLUDED
