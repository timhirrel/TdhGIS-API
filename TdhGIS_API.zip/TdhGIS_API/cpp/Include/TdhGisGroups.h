/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/

#ifndef TDHGISGROUPS_H_INCLUDED
#define TDHGISGROUPS_H_INCLUDED

#include "TdhSpatial_Groups.h"

class EXPORTPROC TPtGroup_gis : public TPtGroup {
// extends TPtGroup to include data needed for display and I/O
protected:
  unsigned int color;
  int groupCode;
public:
  TPtGroup_gis (TPtNav *navParam = NULL, bool ownParam = false) :
  TPtGroup (navParam, ownParam) {
    color = colorBlack;
    groupCode = -1;
    }
  virtual unsigned Color () {return color;} //return the user defined color for the group
  virtual void set_Color (unsigned val) {color = val;} //set    the user defined color for the group
  virtual void CopyOptions_gis (TPtGroup_gis*); //copies options from this to 1st param
  virtual void set_GroupCode (int val) {groupCode = val;} //used during i/o operations
  virtual int GroupCode () {return groupCode;} //used during i/o operations
  };

class EXPORTPROC TPolyGroup_gis : public TPolyGroup {
// extends TPolyGroup to include data needed for display and I/O
protected:
  unsigned int color;
  bool fill;
  double labelsize;
  tdhString keyVal_save;
  TGisPolygon0 *highPoly;
  double highArea;
  int keyVal_count, groupCode;
//  virtual void FinishMultiPart (tdhString);
  virtual void AddMultiPoly (TGisPolygon0*, tdhString);
public:
  TPolyGroup_gis (GisDataTypes typeParam, TPolyNav* = NULL, bool = false);
  virtual ~TPolyGroup_gis();
  virtual void StartAdds_parts(); //used to start adding polygons that may have multiple parts
  virtual void FinishAdds_parts(); //used to finish adding polygons that may have multiple parts
  virtual void AddPoly_parts (TGisPolygon0*, tdhString); //used to add polygons that may have multiple parts
  virtual double LabelSize () {return labelsize;} //returns a value defining the size used for drawing polygon ids
  virtual void set_LabelSize (double val) {labelsize = val;} //sets a value defining the size used for drawing polygon ids
  virtual unsigned int Color () {return color;} // returns a value defining the color used for drawing polygons
  virtual void set_Color (unsigned int val) {color = val;} // sets a value defining the color used for drawing polygons
  virtual bool Fill () {return fill;} // returns a value (bool) defining whether the polygon should be drawn as filled
  virtual void set_Fill (bool val) {fill = val;} // sets a value (bool) defining whether the ploygon should be drawn as filled
  virtual void set_GroupCode (int val) {groupCode = val;} //used during i/o operations
  virtual int GroupCode () {return groupCode;} //used during i/o operations
  };

typedef TPolyGroup_gis TMultiLineGroup_gis;

EXPORTPROC TPtGroup_gis *Create_PtGroup_gis (TPtNav* = NULL, bool = false);
    // create and return a TPtGroup_gis
    // if the 1st param is not None, use it as the TPtDataNav for the group. Otherwise, create a TPtDataNav
    // if the 2nd param is true, the TPtGroup takes ownership of the TPtDataNav

EXPORTPROC TPolyGroup_gis *Create_PolyGroup_gis (TPolyNav* = NULL, bool = false);
    // create and return a TPolyGroup_gis
    // if the 1st param is not None, use it as the TPolyNav for the group. Otherwise, create a TPtDataNav
    // if the 2nd param is true, the TPtGroup takes ownership of the TPtDataNav

EXPORTPROC TMultiLineGroup_gis *Create_LineGroup_gis (TPolyNav* = NULL, bool = false);
    // create and return a TMultiLineGroup_gis
    // if the 1st param is not None, use it as the TPolyNav for the group. Otherwise, create a TPtDataNav
    // if the 2nd param is true, the TPtGroup takes ownership of the TPtDataNav


#endif // TDHGISGROUPS_H_INCLUDED
