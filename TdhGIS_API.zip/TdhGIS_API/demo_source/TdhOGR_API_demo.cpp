#include "TdhOGR_API.h"
#include "TdhOGR_API_demo.h"

TTdhOGR_api_demo::TTdhOGR_api_demo () {
  ogrAPI = Create_TdhOgrApi();
  spatialAPI = new TTdhSpatial_api_demo;
  }

TTdhOGR_api_demo::~TTdhOGR_api_demo () {
  delete ogrAPI;
  delete spatialAPI;
  }

void TTdhOGR_api_demo::Main(tdhString dirParam) {
  dataDir = dirParam;
  GetOGRdata_shp(); //get polygon data from a shapefile
  GetOGRdata_osm(); //get polygon data from a OpenStreetMap file
  ExportPolys_shp(); //export polygon data to a shapefile
  ExportPolys_gis(); //export polygon data to a TdhGIS database
  }

void TTdhOGR_api_demo::GetOGRdata_shp () {
  ogrAPI->SetDriverStr("ESRI Shapefile");
  ogrAPI->ReadTdhData (TTdhOGR_API0::ftOther, dataDir + "/Polygons.shp", dtGisPolygon, true); //read the polygons from a shapefile into the default polygon group
  spatialAPI->WritePolygons(ogrAPI->PolyGroup()->PolyNav()); //output the polygons to console
  }

void TTdhOGR_api_demo::GetOGRdata_osm () {
  ogrAPI->add_TagRequired("landuse, meadow", true); // the tags used for OSM data import
  ogrAPI->set_OsmSource("Ways");
  bool save_LonLat = CadOptions()->get_LonLat();
  CadOptions()->set_LonLat(true);  //notify API that geometry data is long/lat so that area calculation is correct

  ogrAPI->ReadTdhData (TTdhOGR_API0::ftOSM, dataDir + "/JuneLake.osm", dtGisPolygon, true); //import data from an OSM data file
  spatialAPI->WritePolygons(ogrAPI->PolyGroup()->PolyNav()); //output the polygons to console
  CadOptions()->set_LonLat(save_LonLat);
  }

void TTdhOGR_api_demo::ExportPolys_shp () {
  ogrAPI->PolyGroup()->PolyNav()->DeleteAll();
  ogrAPI->PolyGroup()->set_id("Test1");
  ogrAPI->PolyGroup()->AddPoly(spatialAPI->ReadPolygon(), "1"); //add a polygon to the default polygon group
  ogrAPI->SetDriverStr("ESRI Shapefile");
  ogrAPI->WriteTdhData (TTdhOGR_API0::ftOther, dataDir + "/API.shp", dtGisPolygon); //write the default polygon group to a shapefile
  }

void TTdhOGR_api_demo::ExportPolys_gis () {
  ogrAPI->PolyGroup()->PolyNav()->DeleteAll();
  ogrAPI->PolyGroup()->set_id("API");
  ogrAPI->PolyGroup()->AddPoly(spatialAPI->ReadPolygon(), "1"); //add a polygon to the default polygon group
  ogrAPI->WriteTdhData (TTdhOGR_API0::ftTdhGIS, dataDir, dtGisPolygon); //write the default polygon group to a TdhGIS database
  }
