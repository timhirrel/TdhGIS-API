#ifndef TdhGisApiDemo_Header
#define TdhGisApiDemo_Header

#include "TdhSpatial_API_demo.h"

class TTdhGIS_API0;

class TTdhGIS_api_demo {
protected:
  TTdhGIS_API0 *gisAPI;
  TTdhSpatial_api_demo *spatialAPI;
  tdhString dataDir;
public:
  TTdhGIS_api_demo ();
  virtual ~TTdhGIS_api_demo ();
  virtual void Main (tdhString);
  virtual void ReadPolyGroup();
  virtual void WritePolyGroup();
  };

#endif // TdhGisApiDemo_Header
