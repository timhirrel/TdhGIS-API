#include "TdhSpatial_API_demo.h"

typedef double Tpt [3];

const int numPts = 5;

Tpt pts [numPts] = {
  {10,40,10},
  {20,60,23},
  {37,58,22},
  {40,40,32},
  {30,20,16}
  };

class TPointXY_custom : public TPointXY0 {
// an alternative implementation of TPointXY0 that avoids copying x,y data
protected:
  Tpt *pt;
public:
  TPointXY_custom (Tpt *ptParam) {
    pt = ptParam;
    }
  virtual void setX (double val) {(*pt)[0] = val;}
  virtual void setY (double val)  {(*pt)[1] = val;}
  virtual double getX () {return (*pt)[0];}
  virtual double getY ()  {return (*pt)[1];}
  };

TTdhSpatial_api_demo::TTdhSpatial_api_demo() {
  cadOptions = new TCadOptions;
  }

TTdhSpatial_api_demo::~TTdhSpatial_api_demo() {
  delete cadOptions;
  }

void TTdhSpatial_api_demo::Main() {
  TPtNav *ptNav = GetPts(); //read point data into a TPtNav
  WriteThiessens(ptNav); //create thiessen polygons from the ptNav. write polygon data to console
  MakeContours(ptNav); //create contours from the ptNav. write contour data to console
  delete ptNav;

  // here are 2 different methods to create a polygon from data
  TGisPolygon0 *poly1 = MakePolygon(); // this method uses a custom data structure, TPointXY_custom, to reference the data
  poly1->set_PolyID("poly1");
  TGisPolygon0 *poly2 = ReadPolygon(); // this method copies the data into a data structure provided by the TdhGIS_API
  poly2->set_PolyID("poly2");
  WriteOnePoly(poly1);
  WriteOnePoly(poly2);

  // an important difference between the 2 methods is demonstrated here
  // the original data is changed and the change is reflected using the 1st method but not the 2nd method
  pts[1][0] = 25;
  poly1->ResetExtents();
  poly2->ResetExtents();
  WriteOnePoly(poly1);
  WriteOnePoly(poly2);
  }

TPtNav *TTdhSpatial_api_demo::GetPts () { //copy x,y data from the array pts into a TPtNav structure using the default TPointXY
  TPtData0 *ptData = Create_PtData();
  TPtNav *ptNav = Create_PtNav();
//  ptGroup->set_id("Test");
  for (int i=0; i<numPts; i++) {
    ptData = Create_PtData();
    ptNav->AddRec(ptData, stringify(i));
    ptData->setX(pts[i][0]);
    ptData->setY(pts[i][1]);
    ptData->set_Value(pts[i][2]);
    }
  return ptNav;
  }

void TTdhSpatial_api_demo::WriteVertexNav (TVertexNav *vertexNav) { //output points to console
  TPointXY pt;
  std::cout << "  Points:" << std::endl;
  bool goFlag = vertexNav->GotoFirst();
  while (goFlag) {
    pt = vertexNav->GetData()->getPtVal();
    std::cout << "    " + stringify(pt.getX()) + "," + stringify(pt.getY()) << std::endl;
    goFlag = vertexNav->GotoNext();
    }
  }

void TTdhSpatial_api_demo::WriteOnePoly (TGisPolygon0 *poly) { //output one polygon to console
  std::cout << "Polygon: " + poly->PolyID() << std::endl;
  std::cout << "  Area: " + stringify(poly->CalcArea()) << std::endl;
  std::cout << "  Perimeter: " + stringify(poly->CalcPerimeter()) << std::endl;
  WriteVertexNav(poly->PtNav());
  }

void TTdhSpatial_api_demo::WritePolygons (TPolyNav *polyNav) { //output a collection of polygons to console
  bool goFlag = polyNav->GotoFirst();
  while (goFlag) {
    WriteOnePoly(polyNav->GetData());
    goFlag = polyNav->GotoNext();
    }
  }

void TTdhSpatial_api_demo::WriteOneContour (TGisContour0 *line) { //write one contour line to console
  std::cout << "Contour Value: " + stringify(line->Value()) << std::endl;
  std::string majorStr = "no";
  if (line->Major())
    majorStr = "yes";
  std::cout << "  Major: " + majorStr << std::endl;
  WriteVertexNav(line->PtNav());
  }

void TTdhSpatial_api_demo::WriteContours (TContourNav *polyNav) { //write a collection of contour lines to console
  bool goFlag = polyNav->GotoFirst();
  while (goFlag) {
    WriteOneContour(polyNav->GetData());
    goFlag = polyNav->GotoNext();
    }
  }

void TTdhSpatial_api_demo::MakeThiessens (TThiessen0 *thies, TPtNav *ptNav) { //create thiessen polygons from the points in ptNav
  thies->AddPtList(ptNav, true);  //thies is set to use ptNav, removing any previous points
  TGisPolygon0 *boundary = thies->AutoBoundary();
  thies->MakePolygons (boundary); //makes thiessen polygon using the specified boundary
  delete boundary;
  }

void TTdhSpatial_api_demo::WriteThiessens (TPtNav *ptNav) { //create thiessen polygons and output to console
  TThiessen0 *thies = Create_Thiessen();
  MakeThiessens(thies, ptNav);  //thiessen polygons are created from the points in ptNav
  WritePolygons (thies->PolyNav());  //output the polygons to console
  delete thies;
  }

void TTdhSpatial_api_demo::MakeContours (TPtNav *ptNav) { //create contour lines and output to console
  TContour0 *contour = Create_Contour();
  contour->set_MajorStep(5);
  contour->MakeContours(ptNav, 5, NULL, colorBlack, false); //contour lines are created from the points in ptNav
  WriteContours(contour->ContourNav()); //output the polygons to console
  delete contour;
  }


TGisPolygon0 *TTdhSpatial_api_demo::MakePolygon () { //create a polygon using TPointXY_custom for x,y data
  TVertex0 *newVertex;
  TPointXY_custom *newPt;
  TGisPolygon0 *newPoly = Create_GisPolygon();
  for (int i=0; i<numPts; i++) {
    newPt = new TPointXY_custom(&pts[i]); // x,y data is referenced, not copied
    newVertex = newPoly->Create_Vertex(newPt, true);
    newPoly->AddVertex(newVertex);
    }
  return newPoly;
  }

TGisPolygon0 *TTdhSpatial_api_demo::ReadPolygon () { //create a polygon using the default TPointXY for x,y data
  TGisPolygon0 *newPoly = Create_GisPolygon();
  for (int i=0; i<numPts; i++)
    newPoly->AddPt(pts[i][0], pts[i][1]); // x,y data is copied into the default TPointXY class
  return newPoly;
  }

