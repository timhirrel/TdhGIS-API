#ifndef TdhSpatialAPIdemo_Header
#define TdhSpatialAPIdemo_Header

#include "TdhSpatial_Intf.h"

class TTdhSpatial_api_demo {
protected:
  TCadOptions *cadOptions;
public:
  TTdhSpatial_api_demo();
  virtual ~TTdhSpatial_api_demo();
  virtual void Main();
  virtual TPtNav *GetPts ();
  virtual void WriteVertexNav (TVertexNav*);
  virtual void WriteOnePoly (TGisPolygon0*);
  virtual void WritePolygons (TPolyNav*);
  virtual void MakeThiessens (TThiessen0*, TPtNav*);
  virtual void WriteOneContour (TGisContour0 *line);
  virtual void WriteContours (TContourNav*);
  virtual void WriteThiessens (TPtNav*);
  virtual void MakeContours (TPtNav*);
  virtual TGisPolygon0 *MakePolygon ();
  virtual TGisPolygon0 *ReadPolygon ();
  virtual TCadOptions *CadOptions() {return cadOptions;}
  };



#endif // TdhSpatialAPIdemo_Header
