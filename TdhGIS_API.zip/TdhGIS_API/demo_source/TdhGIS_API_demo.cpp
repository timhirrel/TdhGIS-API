#include "TdhGIS_API.h"
#include "TdhGIS_API_demo.h"


TTdhGIS_api_demo::TTdhGIS_api_demo () {
  gisAPI = Create_TdhGisApi();
  spatialAPI = new TTdhSpatial_api_demo;
  }

TTdhGIS_api_demo::~TTdhGIS_api_demo () {
  delete gisAPI;
  delete spatialAPI;
  }

void TTdhGIS_api_demo::Main (tdhString dirParam) {
  dataDir = dirParam;
  WritePolyGroup();
  ReadPolyGroup();
  }

void TTdhGIS_api_demo::WritePolyGroup () {
  TPtNav *ptNav = spatialAPI->GetPts();
  TThiessen0 *thies = Create_Thiessen();
  spatialAPI->MakeThiessens(thies, ptNav); //create thiessen polygosn from the the points in ptNav
  TPolyGroup_gis *polyGroup = new TPolyGroup_gis (dtGisPolygon, thies->PolyNav(), false); //create a polygon group using the thies polygon navigator
  polyGroup->set_id("polygons_export"); //name the polygon group
  gisAPI->set_PolyGroup(polyGroup); //gisAPI->PolyGroup() will return polyGroup
  gisAPI->WriteGroup(dataDir, dtGisPolygon); // write the polygon group to the TdhGIS database
  gisAPI->set_PolyGroup(NULL); //gisAPI->PolyGroup() will return the default PolyGroup
  delete polyGroup;
  delete thies;
  delete ptNav;
  }

void TTdhGIS_api_demo::ReadPolyGroup () {
  gisAPI->ReadGroup(dataDir, dtGisPolygon, "polygons_export", true); //read the polygon group that was previously written to the TdhGIS database
  spatialAPI->WritePolygons(gisAPI->PolyGroup()->PolyNav()); //output the polygons to console
  }


