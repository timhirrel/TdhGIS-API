#include <iostream>
#include "TdhSpatial_Intf.h"

//The following 3 classes demonstrate some capabilities within the TdhGIS API
//The classes are intended to be used within a console app
//The supporting libraries required increase with each class

// The use of navigators (TRecordsNav0 in RecordsNav0.h) is integral for TdhGIS_API.
// Within these demo functions the use of navigators is simple, but navigators provide much more functionality
// See the navigator tutorial and examples

//The example classes can be used or ignored by commenting/uncommenting the associated lines


// The first class demonstrates some capabilities for performing spatial operations
// i.e. making thiessen polygons from a set of points and making contours from a set of points
// This class requires only 2 supporting libraries, TdhCommon and TdhSpatial
#include "TdhSpatial_API_demo.h"

// The second class demonstrates the capability to store and retrieve
// data used within the TdhGIS API using a TdhGIS database
// This class requires the Sqlite library in addition to the TdhCommon and TdhSpatial libraries
// The dataDir variable must be set to the location of Data directory included with the TdhGIS API package
#include "TdhGIS_API_demo.h"

// The third class demonstrates the capability to store and retrieve
// data used within the TdhGIS API using the GDAL/OGR libraries and the TdhOGR_API library
// The GDAL package must be available. The TdhCairo and TdhPath libraries must be available
// The dataDir variable must be set to the location of Data directory included with the TdhGIS API package

#include "TdhOGR_API_demo.h"

int main() {
  tdhString dataDir= "TdhGIS_API_demo/Data"; //set this to the location of the TdhGIS_API_demo Data directory
  TTdhSpatial_api_demo *spatialAPI = new TTdhSpatial_api_demo;
  spatialAPI->Main();
  TTdhGIS_api_demo *gisAPI = new TTdhGIS_api_demo;
//  gisAPI->Main(dataDir);
  TTdhOGR_api_demo *ogrAPI = new TTdhOGR_api_demo;
//  ogrAPI->Main(dataDir);
  return 0;
  }
