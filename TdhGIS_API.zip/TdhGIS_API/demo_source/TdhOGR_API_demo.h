#ifndef TdhOgrApiDemo_Header
#define TdhOgrApiDemo_Header

#include "TdhSpatial_API_demo.h"

class TTdhOGR_API0;

class TTdhOGR_api_demo {
protected:
  TTdhOGR_API0 *ogrAPI;
  TTdhSpatial_api_demo *spatialAPI;
  tdhString dataDir;
public:
  TTdhOGR_api_demo ();
  virtual ~TTdhOGR_api_demo ();
  virtual void Main (tdhString);
  virtual void GetOGRdata_shp ();
  virtual void GetOGRdata_osm ();
  virtual void ExportPolys_shp ();
  virtual void ExportPolys_gis ();
  virtual TCadOptions *CadOptions() {return spatialAPI->CadOptions();}
  };


#endif // TdhOgrApiDemo_Header
