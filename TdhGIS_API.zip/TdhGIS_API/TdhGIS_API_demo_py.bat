# script file for running TdhGIS_API_demo_py within ms windows

python3 -m python.TdhGIS_API_demo_py.TdhGIS_API_demo_Main
